"""Part B scenarios, hotspot-filter evaluation and rule evaluation (all offline)."""
import json

from wildfire_mas.config import load_settings
from wildfire_mas.evaluation import live_eval as le
from wildfire_mas.evaluation.scenarios import Generator, Spec, destination, load_scenarios, write_partb
from wildfire_mas.live.firms import parse_firms_csv
from wildfire_mas.live.geo import haversine_km


def _scenarios(settings, n=12, seed=3):
    return Generator(seed, Spec.from_settings(settings)).generate(n)


def test_destination_matches_haversine():
    lat, lon = destination(7.29, 80.63, 123.0, 9.94)
    assert abs(haversine_km(7.29, 80.63, lat, lon) - 9.94) < 0.001


def test_generator_is_deterministic_and_writes_partb(settings, tmp_path):
    a = [s.to_json() for s in _scenarios(settings)]
    b = [s.to_json() for s in _scenarios(settings)]
    assert a == b
    info = write_partb(_scenarios(settings), tmp_path, Spec.from_settings(settings))
    assert info["scenarios"] == 66 and info["gold_hazards"] > 0
    qs = [json.loads(x) for x in (tmp_path / "golden_partB.jsonl").read_text().splitlines()]
    assert {"L1", "L6", "L9", "L10"} <= {q["qtype"] for q in qs}
    assert all(q["split"] in ("dev", "test") and q["gold_intent"] for q in qs)
    assert len(load_scenarios(tmp_path / "golden_partB_scenarios.jsonl")) == 66


def test_filter_and_rules_meet_the_specification(settings, tmp_path):
    scs = _scenarios(settings, 20)
    f = le.eval_filter_scenarios(settings, scs, tmp_path / "f")["summary"]
    assert f["errors"] == 0 and f["binary_wildfire"]["f1"] == 1.0
    r = le.eval_rules(settings, scs, out_dir=tmp_path / "r")["summary"]["modes"]
    assert r["oracle"]["micro"]["f1"] == 1.0 and r["pipeline"]["micro"]["f1"] == 1.0
    # without the filter, decoy heat sources trigger false R09/R11 alarms
    assert r["nofilter"]["per_rule"]["R09"]["fp"] > 0
    assert (tmp_path / "r" / "summary.md").read_text().count("| oracle |") == 6   # 4 rules + micro + summary row


def test_evaluation_catches_a_wrong_threshold(settings, tmp_path):
    """Mutation check: the engine runs with R09 = 9 km and persistence = 6 days, the gold says 10 km / 8 days."""
    scs = _scenarios(settings, 20)
    bad = load_settings(settings.root)
    bad.raw["rules"]["R09_near_km"] = 9.0
    bad.raw["hotspot_filter"]["persistence_min_days"] = 6
    r = le.eval_rules(bad, scs, ("oracle",), tmp_path / "r")["summary"]["modes"]["oracle"]
    assert r["per_rule"]["R09"]["fn"] > 0
    f = le.eval_filter_scenarios(bad, scs, tmp_path / "f")["summary"]
    assert f["errors"] > 0


def test_filter_on_firms_type_labels(settings, fixtures, tmp_path):
    hs = parse_firms_csv((fixtures / "firms_modis_sp.csv").read_text(), "MODIS_SP")
    s = le.eval_filter_firms(settings, hs, out_dir=tmp_path)["summary"]
    # types [1, 0, 2, 0]; the type-blind classifier calls the two static ones fire (no history, no list)
    # and the MODIS confidence-12 vegetation fire low confidence
    assert s["gold_counts"] == {"volcanic": 1, "likely_vegetation_fire": 2, "static_land_source": 1}
    assert s["binary_wildfire"]["tp"] == 1 and s["binary_wildfire"]["fp"] == 2 and s["binary_wildfire"]["fn"] == 1
    assert s["binary_excluding_low_confidence"]["fn"] == 0


def _sp(lat, lon, day, ftype, conf="n"):
    from datetime import datetime, timedelta, timezone
    from wildfire_mas.live.firms import Hotspot
    t = datetime(2026, 5, 1, 7, 40, tzinfo=timezone.utc) + timedelta(days=day)
    return Hotspot("VIIRS_SNPP_SP", lat, lon, t, "N", "VIIRS", conf, 0.6, 5.0, None, None, "D", fire_type=ftype)


def test_filter_firms_warmup_land_mask_and_sweep(settings, tmp_path):
    import json as _json
    from datetime import date
    # a gas flare seen every 3rd day for 45 days, an offshore platform, and one fire per day elsewhere
    hs = [_sp(5.0, 6.0, d, 2) for d in range(0, 45, 3)] + [_sp(4.2, 7.9, d, 3) for d in range(30, 45, 2)]
    hs += [_sp(5.5 + d * 0.01, 6.5, d, 0) for d in range(45)]
    land = tmp_path / "land.geojson"
    land.write_text(_json.dumps({"type": "Polygon", "coordinates": [[[5, 4.5], [9, 4.5], [9, 7], [5, 7], [5, 4.5]]]}))
    cold = le.eval_filter_firms(settings, hs, out_dir=tmp_path / "a", score_from=date(2026, 5, 1))["summary"]
    warm = le.eval_filter_firms(settings, hs, out_dir=tmp_path / "b", score_from=date(2026, 5, 31),
                                land_mask=str(land), sweep=[4, 8])["summary"]
    assert cold["non_wildfire_flagged_share"]["static_land_source"] < warm["non_wildfire_flagged_share"]["static_land_source"]
    assert warm["history_warmup_days"] == 30 and warm["non_wildfire_flagged_share"]["offshore"] == 1.0
    assert warm["binary_wildfire"]["recall"] == 1.0
    assert [r["persistence_min_days"] for r in warm["persistence_sweep"]] == [4, 8]


def test_filter_firms_rejects_missing_land_mask_and_applies_overrides(settings, tmp_path):
    import pytest
    hs = [_sp(5.0, 6.0, d, 0, conf="l") for d in range(3)]
    with pytest.raises(FileNotFoundError):
        le.eval_filter_firms(settings, hs, out_dir=tmp_path / "a", land_mask=str(tmp_path / "nope.geojson"))
    weak = le.eval_filter_firms(settings, hs, out_dir=tmp_path / "b")["summary"]
    kept = le.eval_filter_firms(settings, hs, out_dir=tmp_path / "c",
                                overrides={"viirs_low_confidence_is_weak": False})["summary"]
    assert weak["binary_wildfire"]["recall"] == 0.0 and kept["binary_wildfire"]["recall"] == 1.0
