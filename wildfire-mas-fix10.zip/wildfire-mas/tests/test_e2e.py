"""End-to-end runner: scoring, scenario world, and a full run with a scripted model (no GraphDB, no GPU)."""
import asyncio
import json
from datetime import timedelta

from fakes import RoutingStore

from wildfire_mas.evaluation import e2e
from wildfire_mas.evaluation.scenarios import Generator, Spec, questions_for
from wildfire_mas.evaluation.world import ScenarioFirms, ScenarioWeather, ScenarioWorld, T0
from wildfire_mas.llm import ScriptedLLM


def _item(qtype, **facts):
    return {"id": "q", "qtype": qtype, "question": "?", "place": "Kandy", "gold_facts": facts, "gold_hazards": []}


def test_rule_checks_per_question_type():
    assert e2e.rule_check(_item("L1", fire_nearby=True), "Yes. Two likely wildfires are burning 3.4 km east of Kandy.")
    assert e2e.rule_check(_item("L1", fire_nearby=False), "No active fires were detected within 10 km of Kandy.")
    assert not e2e.rule_check(_item("L1", fire_nearby=False), "A wildfire is burning 4 km from Kandy.")
    assert e2e.rule_check(_item("L2", nearest_km=6.2), "The closest fire is 6.0 km away.")
    assert not e2e.rule_check(_item("L2", nearest_km=6.2), "The closest fire is 9 km away.")
    assert e2e.rule_check(_item("L6", danger="High"), "Fire danger is high today.")
    assert not e2e.rule_check(_item("L6", danger="High"), "Fire danger is very high today.")
    assert e2e.rule_check(_item("L6", danger="VeryHigh"), "Fire danger is Very High.")
    assert e2e.rule_check(_item("L11", direction="up"), "Danger has been rising all week.")
    assert e2e.rule_check(_item("L8", conflict=False), "The image and the satellite agree.")
    assert e2e.rule_check(_item("L10"), "Please specify a location.")
    it = {**_item("L9"), "gold_hazards": ["NearbyActiveFire", "SpreadingFire"]}
    assert e2e.hazard_recall_text(it, "An active fire is 3 km away.") == 0.5
    assert "spreading" in e2e.reference({**_item("L5", spreading=True)})


def test_scenario_world_replays_firms_and_weather(settings):
    sc = Generator(5, Spec.from_settings(settings)).filter()
    shift = timedelta(days=200)
    firms = ScenarioFirms(sc, shift)
    s = sc.sites[0]
    box = (s["lon"] - 0.3, s["lat"] - 0.3, s["lon"] + 0.3, s["lat"] + 0.3)
    now = firms.get_area(box, days=2).hotspots
    assert len(now) == len(sc.hotspots) and all(h.acq_datetime > T0 + shift - timedelta(days=2) for h in now)
    hist = firms.get_area(box, days=30).hotspots
    assert len(hist) == len(sc.hotspots) + sum(len(h.history_days) for h in sc.hotspots)
    assert firms.get_area((0.0, 0.0, 1.0, 1.0), days=2).hotspots == []
    w = ScenarioWeather(sc, shift).fwi(s["lat"], s["lon"])
    assert w.danger == sc.fwi["S1"][-1]["danger"] and len(w.trend) == 5
    assert ScenarioWeather(sc, shift).geocode(s["label"])[0]["lat"] == s["lat"]


def _scripted(settings):
    def planner(msgs):
        q = msgs[-1]["content"].rsplit("Question:", 1)[1]
        intent = "trend" if "spreading" in q or "rising" in q else \
            "hazard_advice" if ("hazards" in q or "raised" in q or "contradict" in q) else "situational_awareness"
        return json.dumps({"intent": intent, "urgency": "normal", "topic": q})

    def synth(msgs):
        sys = msgs[0]["content"]
        if "with tools" in sys:                                    # single-agent baseline
            return json.dumps({"answer": "No active fires were detected near the location."})
        return json.dumps({"sections": [{"title": "Situation", "sentences": [
            {"text": "No active fires were detected within 10 km.", "cites": ["LIVE1"]}]}]})

    def judge(msgs):
        return json.dumps({"grade": "correct" if "No likely wildfire" in msgs[-1]["content"] else "wrong", "why": "t"})

    llm = ScriptedLLM(settings, {"planner": planner, "synthesizer": synth, "judge": judge,
                                 "rag_grader": lambda m: json.dumps({"grades": [], "rewrite": None})})
    return llm


def test_full_runner_with_baselines_and_ablation(settings, tmp_path):
    gen = Generator(9, Spec.from_settings(settings))
    scs = [gen.r09(), gen.r11(), gen.decoy()]
    items = [q for sc in scs for q in questions_for(sc) if q["qtype"] in ("L1", "L9")]
    for i, q in enumerate(items):
        q["id"] = f"T{i}"
    world = ScenarioWorld(settings, store=RoutingStore([]))
    systems = ["mas", "llm_only", "single_agent", "mas-no_verifier"]
    rows = asyncio.run(e2e.run_partb(settings, systems, items, {s.id: s for s in scs}, _scripted(settings),
                                     True, world, log=lambda *_: None))
    assert len(rows) == len(items) * len(systems)
    assert not [r for r in rows if r["error"]], [r["error"] for r in rows if r["error"]][:2]
    mas = [r for r in rows if r["system"] == "mas"]
    assert all(r["intent"] for r in mas) and all(r["judge_grade"] in ("correct", "wrong") for r in mas)
    assert all(r["answer"] for r in mas) and all(r["grounded_rate"] == 1.0 for r in mas)
    assert any(r.get("attribution") for r in mas if not r["correct"])
    md, _ = e2e.summarize(rows, systems, "B", True)
    assert "McNemar" in md and "| L1 |" in md and "Error attribution" in md
    e2e.write_outputs(tmp_path, rows, md, True, "B")
    sheet = (tmp_path / "human_check.csv").read_text().splitlines()
    assert sheet[0].startswith("id,system,question,reference,answer,judge_grade,human_grade") and len(sheet) > 1


def test_ablation_settings_and_judge_agreement(settings, tmp_path):
    s = e2e.settings_for(settings, "mas-no_rules")
    assert s.get("ablation.rules") is False and settings.get("ablation.rules") is True
    f = tmp_path / "h.csv"
    f.write_text("id,system,question,reference,answer,judge_grade,human_grade\n"
                 "1,mas,q,r,a,correct,correct\n2,mas,q,r,a,wrong,wrong\n3,mas,q,r,a,correct,partial\n4,mas,q,r,a,wrong,\n")
    a = e2e.judge_agreement(f)
    assert a["n"] == 3 and abs(a["agreement"] - 2 / 3) < 1e-9


def test_stratified_limit(tmp_path):
    p = tmp_path / "b.jsonl"
    p.write_text("".join(json.dumps({"id": i, "qtype": f"L{1 + i % 3}", "split": "test"}) + "\n" for i in range(30)))
    got = e2e.load_items(p, "test", 9)
    assert len(got) == 9 and {g["qtype"] for g in got} == {"L1", "L2", "L3"}


def test_live_data_lookup_uses_the_live_pipeline(settings):
    from wildfire_mas.agents.planner import Planner
    from wildfire_mas.agents.state import Request
    from wildfire_mas.kg.cq import CQCatalog

    p = Planner(None, CQCatalog.load(settings), settings)
    cls = {"intent": "data_lookup", "urgency": "normal", "cq": None, "topic": "danger today"}
    plan = p.template("data_lookup", cls, Request("What is the fire danger at Ella today?", lat=6.87, lon=81.05))
    assert {"live_data", "risk"} <= {s.agent for s in plan.steps}
    rec = p.template("data_lookup", {**cls, "cq": "CQ08"}, Request("Weather on that day?", record="urn:x"))
    assert "live_data" not in {s.agent for s in rec.steps} and rec.steps[-1].agent == "kg"


def test_attribution_and_eval_repo_guard(settings):
    import pytest
    item = {"qtype": "L6", "gold_intent": "situational_awareness", "gold_hazards": []}
    out = {"intent": "data_lookup", "derived_hazards": [], "cited_hazards": [],
           "trace": {"plan_steps": [("kg", "CQ08")], "steps": [], "live": []}}
    assert e2e.attribute(item, out).startswith("planner (plan misses live_data")
    out["trace"]["plan_steps"] = [("resolve", None), ("live_data", None)]
    assert e2e.attribute(item, out) == "synthesizer"
    with pytest.raises(SystemExit):
        ScenarioWorld(settings, kind="graphdb", repository=settings.get("graphdb.repository") or "ffonto")


def test_fwi_tool_ignores_a_site_that_is_not_an_iri(settings):
    from wildfire_mas.evaluation.world import ScenarioWorld
    sc = Generator(4, Spec.from_settings(settings)).r11()
    store = RoutingStore([])
    tk = ScenarioWorld(settings, store=store).enter(sc)
    tk.weather_fwi(sc.sites[0]["lat"], sc.sites[0]["lon"], site="Polonnaruwa")
    assert "ffo:atSite" not in store.inserted[-1][1]
    tk.weather_fwi(sc.sites[0]["lat"], sc.sites[0]["lon"], site="http://purl.org/ffonto/data/querysite/x")
    assert "ffo:atSite <http://purl.org/ffonto/data/querysite/x>" in store.inserted[-1][1]


def test_place_lookup_keeps_the_chosen_cq(settings):
    from wildfire_mas.agents.planner import Planner
    from wildfire_mas.agents.state import Request
    from wildfire_mas.kg.cq import CQCatalog
    p = Planner(None, CQCatalog.load(settings), settings)
    plan = p.template("data_lookup", {"intent": "data_lookup", "cq": "CQL03", "topic": "t"},
                      Request("FWI trend at Ella?", place="Ella"))
    assert "live_data" in {s.agent for s in plan.steps} and any(s.params.get("cq") == "CQL03" for s in plan.steps)
