"""Per-agent evaluation of the live path: hotspot filter and rules R09-R12.

    wfmas eval-filter                                   # synthetic Part B scenarios
    wfmas eval-filter --firms-csv sp_srilanka.csv ...   # real FIRMS standard-processing data (type column = gold)
    wfmas eval-rules                                    # R09-R12 in three input modes

Rule input modes
  oracle    only the gold vegetation-fire hotspots reach the rules (tests the rules alone)
  pipeline  hotspots pass through the real classifier first (filter + rules, as deployed)
  nofilter  every thermal anomaly reaches the rules (ablation: what the filter is worth)

Outputs: runs/<time>_<name>/summary.md, summary.json, errors.jsonl
"""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from ..config import Settings
from ..kg.rules_live import LiveRuleEngine, RuleRun
from ..live.classify import CATEGORIES, HotspotClassifier, StaticSource
from ..live.firms import Hotspot, _conf_score, parse_firms_csv
from ..live.geo import wkt_point
from .metrics import bootstrap_ci
from .scenarios import Scenario, load_scenarios

POS = "likely_vegetation_fire"
RULES = ("R09", "R10", "R11", "R12")


# ------------------------------------------------------------------------------- helpers
@dataclass
class PRF:
    tp: int = 0
    fp: int = 0
    fn: int = 0
    tn: int = 0

    def add(self, gold: bool, pred: bool) -> None:
        if gold and pred:
            self.tp += 1
        elif pred:
            self.fp += 1
        elif gold:
            self.fn += 1
        else:
            self.tn += 1

    @property
    def p(self) -> float | None:
        return self.tp / (self.tp + self.fp) if self.tp + self.fp else None

    @property
    def r(self) -> float | None:
        return self.tp / (self.tp + self.fn) if self.tp + self.fn else None

    @property
    def f1(self) -> float | None:
        p, r = self.p, self.r
        if p is None or r is None:
            return None
        return 2 * p * r / (p + r) if p + r else 0.0

    def row(self) -> dict:
        return {"tp": self.tp, "fp": self.fp, "fn": self.fn, "tn": self.tn,
                "precision": self.p, "recall": self.r, "f1": self.f1}


def _f(v) -> str:
    return "-" if v is None else f"{v:.3f}" if isinstance(v, float) else str(v)


def _out_dir(settings: Settings, name: str, out_dir: Path | None) -> Path:
    d = out_dir or settings.root / settings.get("paths.runs_dir", "runs") / f"{datetime.now():%Y%m%d_%H%M%S}_{name}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def to_hotspot(h, conf_override: str | None = None) -> Hotspot:
    """Scenario hotspot -> live Hotspot (same object the FIRMS parser produces)."""
    t = datetime.fromisoformat(h.t)
    conf = conf_override or h.confidence
    return Hotspot(source=h.product, latitude=h.lat, longitude=h.lon, acq_datetime=t, satellite=None,
                   instrument=h.instrument, confidence_raw=conf, confidence_score=_conf_score(conf, h.instrument),
                   frp=h.frp, brightness=None, brightness_2=None, daynight="D", fire_type=h.fire_type)


def scenario_history(sc: Scenario) -> list[Hotspot]:
    """30-day history as the toolkit fetches it: today's detections plus the earlier ones."""
    hist = []
    for h in sc.hotspots:
        hist.append(to_hotspot(h))
        for d in h.history_days:
            x = to_hotspot(h)
            x.acq_datetime = datetime.fromisoformat(d).replace(hour=7, minute=40, tzinfo=timezone.utc)
            hist.append(x)
    return hist


def classify_scenario(settings: Settings, sc: Scenario) -> dict[str, str]:
    clf = HotspotClassifier(settings.get("hotspot_filter"),
                            [StaticSource(s["name"], s["lat"], s["lon"], s["kind"]) for s in sc.static_sources])
    hs = [to_hotspot(h) for h in sc.hotspots]
    clf.classify(hs, history=scenario_history(sc))
    return {h.id: x.category for h, x in zip(sc.hotspots, hs)}


# ------------------------------------------------------------------------------- filter: synthetic
def eval_filter_scenarios(settings: Settings, scenarios: list[Scenario], out_dir: Path | None = None) -> dict:
    cats = list(CATEGORIES)
    conf = defaultdict(Counter)            # gold -> pred -> n
    binary, binary_edge = PRF(), PRF()
    errors = []
    for sc in scenarios:
        pred = classify_scenario(settings, sc)
        for h in sc.hotspots:
            p = pred[h.id]
            conf[h.gold_category][p] += 1
            binary.add(h.gold_category == POS, p == POS)
            if sc.near_edge:
                binary_edge.add(h.gold_category == POS, p == POS)
            if p != h.gold_category:
                errors.append({"scenario": sc.id, "hotspot": h.id, "gold": h.gold_category, "pred": p,
                               "note": h.note, "confidence": h.confidence, "fire_type": h.fire_type})
    per_cat = {}
    for c in cats:
        x = PRF(tp=conf[c][c], fp=sum(conf[g][c] for g in cats if g != c),
                fn=sum(n for p, n in conf[c].items() if p != c))
        per_cat[c] = {**x.row(), "support": sum(conf[c].values())}
    present = [c for c in cats if per_cat[c]["support"]]
    macro = sum(per_cat[c]["f1"] or 0.0 for c in present) / max(1, len(present))
    n = sum(sum(v.values()) for v in conf.values())
    acc = sum(conf[c][c] for c in cats) / max(1, n)
    summary = {"n_hotspots": n, "accuracy": acc, "macro_f1": macro, "binary_wildfire": binary.row(),
               "binary_wildfire_near_edge": binary_edge.row(), "per_category": per_cat,
               "confusion": {g: dict(conf[g]) for g in cats if conf[g]}, "errors": len(errors)}
    d = _out_dir(settings, "filter", out_dir)
    _write(d, summary, errors, _filter_md("Hotspot filter on Part B scenarios", summary, cats))
    return {"out_dir": str(d), "summary": summary}


def _filter_md(title: str, s: dict, cats: list[str]) -> str:
    b = s["binary_wildfire"]
    lines = [f"# {title}", "",
             f"{s['n_hotspots']} detections · accuracy {_f(s['accuracy'])} · macro-F1 {_f(s['macro_f1'])} · "
             f"errors {s['errors']}", "",
             "## Wildfire vs not (positive = likely_vegetation_fire)", "",
             "| set | TP | FP | FN | TN | precision | recall | F1 |", "|---|---|---|---|---|---|---|---|"]
    for name, x in (("all", b), ("near a threshold", s.get("binary_wildfire_near_edge"))):
        if x and (x["tp"] + x["fp"] + x["fn"] + x["tn"]):
            lines.append(f"| {name} | {x['tp']} | {x['fp']} | {x['fn']} | {x['tn']} | {_f(x['precision'])} | "
                         f"{_f(x['recall'])} | {_f(x['f1'])} |")
    lines += ["", "## Per category", "", "| category | support | precision | recall | F1 |", "|---|---|---|---|---|"]
    for c in cats:
        x = s["per_category"][c]
        if x["support"] or x["fp"]:
            lines.append(f"| {c} | {x['support']} | {_f(x['precision'])} | {_f(x['recall'])} | {_f(x['f1'])} |")
    lines += ["", "## Confusion (rows gold, columns predicted)", "",
              "| gold \\ pred | " + " | ".join(cats) + " |", "|" + "---|" * (len(cats) + 1)]
    for g in cats:
        if g in s["confusion"]:
            lines.append(f"| {g} | " + " | ".join(str(s["confusion"][g].get(p, 0)) for p in cats) + " |")
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------------------- filter: real FIRMS SP data
GOLD_TYPE = {0: POS, 1: "volcanic", 2: "static_land_source", 3: "offshore"}


def _blind(h: Hotspot) -> Hotspot:
    return Hotspot(**{**h.__dict__, "fire_type": None, "category": None, "reasons": []})


def _classify_days(clf: HotspotClassifier, by_day: dict, days: list, scored: list, window: int) -> dict[int, str]:
    """Classify every scored day with the 30-day history before it (as the live toolkit does)."""
    pred: dict[int, str] = {}
    for d in scored:
        hist = [_blind(h) for dd in days if d - timedelta(days=window - 1) <= dd <= d for h in by_day[dd]]
        today = by_day[d]
        blind = [_blind(h) for h in today]
        clf.classify(blind, history=hist)
        for h, b in zip(today, blind):
            pred[id(h)] = b.category
    return pred


def eval_filter_firms(settings: Settings, hotspots: list[Hotspot], use_static: bool = False,
                      out_dir: Path | None = None, label: str = "", score_from: date | None = None,
                      land_mask: str | None = None, sweep: list[int] | None = None) -> dict:
    """Gold = FIRMS `type` (standard processing). The classifier runs WITHOUT the type column, as on NRT
    data. Days before `score_from` are history only (warm-up), so every scored day has a full 30-day
    history, as in the live system."""
    from ..live.classify import load_land_polygons, load_static_sources

    typed = [h for h in hotspots if h.fire_type is not None]
    if not typed:
        raise ValueError("no `type` column in this data: use a standard-processing (SP) product, "
                         "e.g. VIIRS_SNPP_SP or MODIS_SP, or a FIRMS archive download")
    cfg = dict(settings.get("hotspot_filter"))
    window = int(cfg.get("persistence_window_days", 30))
    static = load_static_sources(settings.path(cfg.get("static_sources_file"))) if use_static else []
    land = load_land_polygons(Path(land_mask)) if land_mask else []
    by_day: dict[date, list[Hotspot]] = defaultdict(list)
    for h in typed:
        by_day[h.acq_datetime.date()].append(h)
    days = sorted(by_day)
    scored = [d for d in days if score_from is None or d >= score_from]
    if not scored:
        raise ValueError(f"no detections on or after {score_from}")
    warm = (scored[0] - days[0]).days
    gold = {id(h): GOLD_TYPE.get(h.fire_type, f"type{h.fire_type}") for d in scored for h in by_day[d]}

    def score(pred):
        strict, lenient, conf = PRF(), PRF(), defaultdict(Counter)
        for k, g in gold.items():
            p = pred[k]
            conf[g][p] += 1
            strict.add(g == POS, p == POS)
            if p != "low_confidence":
                lenient.add(g == POS, p == POS)
        return strict, lenient, conf

    clf = HotspotClassifier(cfg, static, land)
    strict, lenient, conf = score(_classify_days(clf, by_day, days, scored, window))
    sweep_rows = []
    for v in sweep or []:
        st, _, cf = score(_classify_days(HotspotClassifier({**cfg, "persistence_min_days": v}, static, land),
                                         by_day, days, scored, window))
        sweep_rows.append({"persistence_min_days": v, **st.row(),
                           "static_flagged": _share_flagged(cf, "static_land_source")})
    n = len(gold)
    neg_recall = {g: _share_flagged(conf, g) for g in conf if g != POS}
    summary = {"label": label, "n_hotspots": n, "scored_days": len(scored),
               "first_day": scored[0].isoformat(), "last_day": scored[-1].isoformat(),
               "history_warmup_days": warm, "land_mask": bool(land), "static_sources": len(static),
               "persistence_min_days": cfg.get("persistence_min_days"),
               "gold_counts": {g: sum(v.values()) for g, v in conf.items()},
               "binary_wildfire": strict.row(), "binary_excluding_low_confidence": lenient.row(),
               "non_wildfire_flagged_share": neg_recall, "confusion": {g: dict(v) for g, v in conf.items()},
               "persistence_sweep": sweep_rows,
               "note": "FIRMS type 0 means 'presumed vegetation fire' and also contains agricultural burning; "
                       "low-confidence detections are not part of the gold, so both scorings are reported."}
    lines = [f"# Hotspot filter on FIRMS standard-processing data {label}", "",
             f"{n} detections scored over {len(scored)} days ({summary['first_day']} to {summary['last_day']}); "
             f"history warm-up {warm} days; land mask {'on' if land else 'off'}; "
             f"static-source list {len(static)} entries; persistence >= {cfg.get('persistence_min_days')} days.", ""]
    if warm < window - 1:
        lines += [f"Warning: only {warm} days of history before the first scored day (the live system uses "
                  f"{window}); persistence is under-detected. Use --warmup {window}.", ""]
    lines += ["| scoring | TP | FP | FN | TN | precision | recall | F1 |", "|---|---|---|---|---|---|---|---|"]
    for name, x in (("low confidence counts as not-wildfire", strict.row()),
                    ("low-confidence detections excluded", lenient.row())):
        lines.append(f"| {name} | {x['tp']} | {x['fp']} | {x['fn']} | {x['tn']} | {_f(x['precision'])} | "
                     f"{_f(x['recall'])} | {_f(x['f1'])} |")
    lines += ["", "| FIRMS type (gold) | detections | flagged as not wildfire |", "|---|---|---|"]
    for g, k in sorted(summary["gold_counts"].items()):
        lines.append(f"| {g} | {k} | {'-' if g == POS else _f(neg_recall[g])} |")
    lines += ["", "Predicted categories per gold type:", ""]
    for g, v in conf.items():
        lines.append(f"- {g}: " + ", ".join(f"{p} {k}" for p, k in v.most_common()))
    if sweep_rows:
        lines += ["", "## Persistence threshold sweep (choose on a tuning period, report on a different one)", "",
                  "| min days | precision | recall | F1 | static sources flagged |", "|---|---|---|---|---|"]
        for r in sweep_rows:
            lines.append(f"| {r['persistence_min_days']} | {_f(r['precision'])} | {_f(r['recall'])} | {_f(r['f1'])} | "
                         f"{_f(r['static_flagged'])} |")
    d = _out_dir(settings, "filter_firms", out_dir)
    _write(d, summary, [], "\n".join(lines) + "\n")
    return {"out_dir": str(d), "summary": summary}


def _share_flagged(conf, g) -> float | None:
    tot = sum(conf[g].values()) if g in conf else 0
    return (sum(n for p, n in conf[g].items() if p != POS) / tot) if tot else None


def load_firms_files(paths: list[str], source: str | None = None) -> list[Hotspot]:
    out = []
    for p in paths:
        text = Path(p).read_text()
        src = source or next((s for s in ("VIIRS_SNPP_SP", "VIIRS_NOAA20_SP", "MODIS_SP")
                              if s.lower() in Path(p).name.lower()), "VIIRS_SNPP_SP")
        out += parse_firms_csv(text, src)
    return out


# ------------------------------------------------------------------------------- rules
class ScenarioRuleEngine(LiveRuleEngine):
    """The deployed rule engine with its graph inputs replaced by a scenario (no GraphDB needed)."""

    def __init__(self, settings: Settings, sc: Scenario, hotspot_ids: set[str]):
        super().__init__(settings, store=None)  # type: ignore[arg-type]  # write=False: store unused
        self.sc = sc
        self.ids = hotspot_ids

    def iri(self, kind: str, local: str) -> str:
        return f"{self.data}{kind}/{local}"

    def _sites(self):
        return [{"site": self.iri("site", s["id"]), "label": s["label"], "lat": s["lat"], "lon": s["lon"]}
                for s in self.sc.sites]

    def _hotspots(self):
        return [{"h": self.iri("hotspot", h.id), "lat": h.lat, "lon": h.lon,
                 "t": datetime.fromisoformat(h.t), "frp": h.frp, "product": h.product}
                for h in self.sc.hotspots if h.id in self.ids]

    def _latest_fwi(self):
        out = {}
        for sid, series in self.sc.fwi.items():
            last = series[-1]
            out[self.iri("site", sid)] = {"a": self.iri("weather", f"{self.sc.id}-{sid}-{last['date']}"),
                                          "date": last["date"], "fwi": last["fwi"], "danger": last["danger"]}
        return out

    def _q(self, name: str):
        if name == "inputs_images.rq":
            return [{"rec": self.iri("image", i["rec"]), "wkt": wkt_point(i["lat"], i["lon"]),
                     "t": i["t"], "score": i["score"], "threshold": i["threshold"],
                     "event": self.iri("event", i["event"])} for i in self.sc.images]
        raise KeyError(name)


def hazard_keys(sc: Scenario, run: RuleRun) -> set[tuple[str, str]]:
    """Predicted hazards as (rule, target) in the same terms as the gold labels."""
    group = {h.id: h.group for h in sc.hotspots}
    out = set()
    for hz in run.hazards:
        rule = hz["rule"]
        if rule in ("R09", "R11"):
            out.add((rule, (hz["site"] or "").rsplit("/", 1)[-1]))
        elif rule == "R10":
            gs = Counter(group.get(x.rsplit("/", 1)[-1]) for x in hz["supported_by"])
            out.add((rule, gs.most_common(1)[0][0] or "?"))
        elif rule == "R12":
            out.add((rule, hz["supported_by"][0].rsplit("/", 1)[-1]))
    return out


def eval_rules(settings: Settings, scenarios: list[Scenario], modes: tuple[str, ...] = ("oracle", "pipeline", "nofilter"),
               out_dir: Path | None = None) -> dict:
    res: dict[str, dict] = {}
    errors = []
    for mode in modes:
        per_rule = {r: PRF() for r in RULES}
        per_rule_edge = {r: PRF() for r in RULES}
        per_family: dict[str, PRF] = defaultdict(PRF)
        scen_ok = []
        events_ok = []
        for sc in scenarios:
            if mode == "oracle":
                ids = {h.id for h in sc.hotspots if h.gold_category == "likely_vegetation_fire"}
            elif mode == "pipeline":
                ids = {k for k, c in classify_scenario(settings, sc).items() if c == "likely_vegetation_fire"}
            else:
                ids = {h.id for h in sc.hotspots}
            run = ScenarioRuleEngine(settings, sc, ids).run(write=False)
            pred = hazard_keys(sc, run)
            gold = {(g["rule"], g["target"]) for g in sc.gold_hazards}
            # every (rule, target) the scenario could produce is a decision: TP / FP / FN / TN
            candidates = {("R09", s["id"]) for s in sc.sites} | {("R11", s["id"]) for s in sc.sites} | \
                         {("R12", i["rec"]) for i in sc.images} | \
                         {("R10", g) for g in {h.group for h in sc.hotspots if h.group}} | gold | pred
            for key in candidates:
                per_rule[key[0]].add(key in gold, key in pred)
                per_family[sc.family].add(key in gold, key in pred)
                if sc.near_edge:
                    per_rule_edge[key[0]].add(key in gold, key in pred)
                if (key in gold) != (key in pred):
                    errors.append({"mode": mode, "scenario": sc.id, "family": sc.family, "rule": key[0],
                                   "target": key[1], "error": "missed" if key in gold else "false alarm",
                                   "params": sc.params, "near_edge": sc.near_edge})
            scen_ok.append(float(pred == gold))
            if sc.gold_events is not None:
                ids_in_groups = {h.id for h in sc.hotspots if h.group} & ids
                if ids_in_groups == {h.id for h in sc.hotspots if h.group}:
                    events_ok.append(float(run.derived.get("R10_event", 0) == sc.gold_events))
        all_ = PRF(*(sum(getattr(x, a) for x in per_rule.values()) for a in ("tp", "fp", "fn", "tn")))
        m, lo, hi = bootstrap_ci(scen_ok)
        res[mode] = {"per_rule": {r: x.row() for r, x in per_rule.items()},
                     "per_rule_near_edge": {r: x.row() for r, x in per_rule_edge.items()},
                     "per_family": {f: x.row() for f, x in per_family.items()},
                     "micro": all_.row(),
                     "macro_f1": _mean([per_rule[r].f1 for r in RULES if per_rule[r].tp + per_rule[r].fn]),
                     "scenario_exact_match": {"mean": m, "ci95": [lo, hi]},
                     "r10_event_count_accuracy": (sum(events_ok) / len(events_ok)) if events_ok else None}
    summary = {"n_scenarios": len(scenarios), "modes": res,
               "gold_hazards": dict(Counter(g["rule"] for sc in scenarios for g in sc.gold_hazards))}
    d = _out_dir(settings, "rules", out_dir)
    _write(d, summary, errors, _rules_md(summary))
    return {"out_dir": str(d), "summary": summary}


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return sum(xs) / len(xs) if xs else None


def _rules_md(s: dict) -> str:
    lines = ["# Rules R09-R12 on Part B scenarios", "",
             f"{s['n_scenarios']} scenarios · gold hazards per rule: "
             + ", ".join(f"{k} {v}" for k, v in sorted(s["gold_hazards"].items())), "",
             "Modes: **oracle** = only gold vegetation fires reach the rules; **pipeline** = real hotspot filter "
             "first (as deployed); **nofilter** = every thermal anomaly reaches the rules.", "",
             "| mode | rule | TP | FP | FN | precision | recall | F1 |", "|---|---|---|---|---|---|---|---|"]
    for mode, r in s["modes"].items():
        for rule in RULES:
            x = r["per_rule"][rule]
            lines.append(f"| {mode} | {rule} | {x['tp']} | {x['fp']} | {x['fn']} | {_f(x['precision'])} | "
                         f"{_f(x['recall'])} | {_f(x['f1'])} |")
        x = r["micro"]
        lines.append(f"| {mode} | **all (micro)** | {x['tp']} | {x['fp']} | {x['fn']} | {_f(x['precision'])} | "
                     f"{_f(x['recall'])} | {_f(x['f1'])} |")
    lines += ["", "| mode | macro-F1 | scenarios fully correct [95% CI] | R10 event count accuracy |",
              "|---|---|---|---|"]
    for mode, r in s["modes"].items():
        e = r["scenario_exact_match"]
        lines.append(f"| {mode} | {_f(r['macro_f1'])} | {_f(e['mean'])} [{_f(e['ci95'][0])}-{_f(e['ci95'][1])}] | "
                     f"{_f(r['r10_event_count_accuracy'])} |")
    lines += ["", "Near-threshold scenarios only (oracle mode):", "", "| rule | precision | recall | F1 |", "|---|---|---|---|"]
    if "oracle" in s["modes"]:
        for rule in RULES:
            x = s["modes"]["oracle"]["per_rule_near_edge"][rule]
            if x["tp"] + x["fp"] + x["fn"]:
                lines.append(f"| {rule} | {_f(x['precision'])} | {_f(x['recall'])} | {_f(x['f1'])} |")
    return "\n".join(lines) + "\n"


def _write(d: Path, summary: dict, errors: list[dict], md: str) -> None:
    (d / "summary.json").write_text(json.dumps(summary, indent=2, default=str))
    (d / "errors.jsonl").write_text("".join(json.dumps(e, default=str) + "\n" for e in errors))
    (d / "summary.md").write_text(md)


def scenarios_or_default(settings: Settings, path: str | None) -> list[Scenario]:
    p = Path(path) if path else settings.root / "eval" / "datasets" / "golden_partB_scenarios.jsonl"
    if not p.exists():
        raise FileNotFoundError(f"{p} not found: run `wfmas golden-partb` first")
    return load_scenarios(p)
