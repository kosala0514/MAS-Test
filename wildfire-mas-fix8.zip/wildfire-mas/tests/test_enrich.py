"""Hotspot enrichment: protected area / forest, district, nearest place, land cover, fire context."""
import csv
import json
from datetime import datetime, timezone

from fakes import RoutingStore

from wildfire_mas.evaluation import live_eval as le
from wildfire_mas.evaluation.metrics import cohen_kappa
from wildfire_mas.live.enrich import HotspotEnricher, PlaceIndex, PolygonLayer
from wildfire_mas.live.firms import FirmsResult, Hotspot
from wildfire_mas.live.lift import LiveLifter
from wildfire_mas.tools.toolkit import Toolkit


def box(w, s, e, n, holes=()):
    return [[[w, s], [e, s], [e, n], [w, n], [w, s]], *holes]


def fc(*feats):
    return {"type": "FeatureCollection", "features": [
        {"type": "Feature", "properties": p, "geometry": {"type": "Polygon", "coordinates": g}} for p, g in feats]}


def layers(tmp_path):
    """A district, a forest reserve (with a village enclave hole) and land-cover polygons around Ella."""
    files = {
        "admin": fc(({"NAME_1": "Badulla", "NAME_2": "Ella"}, box(80.9, 6.7, 81.3, 7.1))),
        "pa": fc(({"NAME": "Test Forest Reserve", "DESIG_ENG": "Forest Reserve"},
                  box(81.00, 6.85, 81.10, 6.95, holes=[box(81.04, 6.89, 81.06, 6.91)[0]]))),
        "lc": fc(({"landuse": "forest"}, box(81.00, 6.80, 81.10, 7.00)),
                 ({"landuse": "farmland"}, box(81.15, 6.80, 81.25, 7.00)),
                 ({"landuse": "residential"}, box(81.10, 6.80, 81.15, 7.00))),
    }
    paths = {}
    for k, v in files.items():
        paths[k] = tmp_path / f"{k}.geojson"
        paths[k].write_text(json.dumps(v))
    paths["places"] = tmp_path / "places.csv"
    paths["places"].write_text("name,lat,lon,population\nElla,6.8667,81.0466,45000\nBandarawela,6.8295,80.9875,30000\n")
    return paths


def configure(settings, tmp_path):
    p = layers(tmp_path)
    settings.raw["enrichment"].update(protected_areas=str(p["pa"]), admin=str(p["admin"]), places=str(p["places"]),
                                      land_cover=str(p["lc"]))
    return HotspotEnricher.from_settings(settings)


def hs(lat, lon, cat="likely_vegetation_fire"):
    h = Hotspot("VIIRS_NOAA20_NRT", lat, lon, datetime(2026, 3, 10, 7, 48, tzinfo=timezone.utc), "N20", "VIIRS",
                "n", 0.6, 12.0, 330.0, 290.0, "D")
    h.category, h.wildfire_evidence, h.reasons = cat, cat == "likely_vegetation_fire", ["test"]
    return h


def test_polygon_layer_prefers_specific_feature_and_respects_holes(tmp_path):
    p = layers(tmp_path)
    pa = PolygonLayer.load(p["pa"])
    assert pa.find(6.87, 81.02)["NAME"] == "Test Forest Reserve"
    assert pa.find(6.90, 81.05) is None              # village enclave (hole)
    assert pa.find(7.20, 81.02) is None


def test_places_csv_and_geonames(tmp_path):
    p = layers(tmp_path)
    n = PlaceIndex.load(p["places"]).nearest(6.90, 81.07)
    assert n["name"] == "Ella" and n["direction"] == "NE" and n["text"].endswith("NE of Ella")
    g = tmp_path / "LK.txt"
    g.write_text("1\tElla\tElla\t\t6.8667\t81.0466\tP\tPPL\tLK\t\t\t\t\t\t45000\t\t\t\t\n"
                 "2\tElla Rock\tElla Rock\t\t6.85\t81.04\tT\tMT\tLK\t\t\t\t\t\t0\t\t\t\t\n")
    assert PlaceIndex.load(g).nearest(6.85, 81.04)["name"] == "Ella"   # mountains (class T) are not places


def test_fire_context_from_land_cover_and_protected_area(settings, tmp_path):
    enr = configure(settings, tmp_path)
    forest = enr.enrich(hs(6.87, 81.02))
    assert forest["context"] == "wildfire_likely" and forest["protected_area"]["name"] == "Test Forest Reserve"
    assert forest["admin"] == {"district": "Badulla", "division": "Ella", "province": "Uva Province"}
    assert forest["place"]["name"] == "Ella"
    assert "Test Forest Reserve" in forest["summary"] and "±375 m" in forest["summary"]
    assert enr.enrich(hs(6.90, 81.20))["context"] == "agricultural_burning_likely"
    assert enr.enrich(hs(6.90, 81.125))["context"] == "settlement_fire_likely"
    assert enr.enrich(hs(6.87, 81.02, "persistent_static_source"))["context"] == "not_vegetation_fire"
    assert enr.enrich(hs(7.50, 80.50))["context"] == "unknown_land_cover"


def test_enrichment_is_lifted_and_reported_by_the_toolkit(settings, tmp_path):
    enr = configure(settings, tmp_path)
    h = hs(6.87, 81.02)
    enr.enrich(h)
    doc = LiveLifter(settings).doc()
    LiveLifter(settings).hotspot(doc, h, "urn:act")
    ttl = doc.serialize()
    for term in ("ffo:withinProtectedArea", "ffo:ProtectedArea", "ffo:inDistrict", "ffo:fireContext",
                 "FireContext_wildfire_likely", "ffo:locationDescription", "LandCover_tree_cover"):
        assert term in ttl, term

    class FakeFirms:
        default_sources = ["VIIRS_NOAA20_NRT"]

        def get_area(self, area, days, sources=None, end=None):
            return FirmsResult([hs(6.87, 81.02, None), hs(6.90, 81.20, None)], ["VIIRS_NOAA20_NRT"], "x", days,
                               None, "2026-03-10T08:00:00Z", [], False)

    store = RoutingStore([])
    tk = Toolkit(settings, store=store, firms=FakeFirms())
    out = tk.firms_get_hotspots(lat=6.88, lon=81.05, radius_km=25, persistence=False)
    assert out["by_context"] == {"wildfire_likely": 1, "agricultural_burning_likely": 1}
    assert "Test Forest Reserve" in json.dumps(out["hotspots"])
    where = tk.geo_describe(6.87, 81.02)
    assert where["protected_area"]["name"] == "Test Forest Reserve" and where["layers_configured"]


def test_missing_layer_is_a_warning_not_a_crash(settings):
    settings.raw["enrichment"]["admin"] = "data/does_not_exist.geojson"
    enr = HotspotEnricher.from_settings(settings)
    assert not enr.configured and any("not found" in w for w in enr.warnings)


def test_labelling_sheet_and_scoring(settings, tmp_path):
    configure(settings, tmp_path)
    sheet = tmp_path / "labels.csv"
    info = le.enrich_sample(settings, [hs(6.87, 81.02), hs(6.90, 81.20), hs(6.90, 81.125), hs(6.86, 81.01)], 10, sheet)
    assert info["written"] == 4
    rows = list(csv.DictReader(sheet.open()))
    assert rows[0]["map_link"].startswith("https://www.google.com/maps/@") and rows[0]["gold_context"] == ""
    by_pred = {"wildfire_likely": "wildfire", "agricultural_burning_likely": "wildfire",   # one disagreement
               "settlement_fire_likely": "settlement"}
    for r in rows:
        r["gold_context"] = by_pred[r["predicted_context"]]
        r["gold_context_2"] = r["gold_context"]
    with sheet.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    s = le.eval_enrich(settings, sheet, tmp_path / "out")["summary"]
    assert s["labelled"] == 4 and s["accuracy"] == 0.75
    assert s["wildfire_likely"]["fn"] == 1 and s["inter_annotator_kappa"] == 1.0


def test_cohen_kappa():
    assert cohen_kappa(["a", "b", "a", "b"], ["a", "b", "a", "b"]) == 1.0
    assert abs(cohen_kappa(["a", "a", "b", "b"], ["a", "b", "a", "b"])) < 1e-9
