"""A Part B scenario as the system's world: FIRMS, weather and the knowledge graph are replaced by the
scenario, everything else (planner, orchestrator, agents, rules, synthesizer, verifier) is the real code.

  * FIRMS returns the scenario's hotspots (and their 30-day history for the persistence check);
  * weather / FWI returns the scenario's 5-day danger series; geocoding knows the scenario's sites;
  * the graph store is an in-memory store with the ontology loaded, so GraphDB data is never touched;
  * all scenario times are shifted so that "now" is the moment of the run (time windows still work).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from ..config import Settings
from ..kg.turtle import Lit, TurtleDoc
from ..live.classify import HotspotClassifier, StaticSource
from ..live.firms import FirmsResult, Hotspot, _conf_score
from ..live.fwi import FWIDay
from ..live.geo import haversine_km, in_bbox, parse_bbox, wkt_point
from ..live.weather import FWIReport, WeatherNow
from .scenarios import Scenario

XSD_DT = "http://www.w3.org/2001/XMLSchema#dateTime"
XSD_DBL = "http://www.w3.org/2001/XMLSchema#double"
T0 = datetime(2026, 3, 15, 7, 45, tzinfo=timezone.utc)   # scenario reference time (scenarios.Generator.t0)


def time_shift(now: datetime | None = None) -> timedelta:
    now = (now or datetime.now(timezone.utc)).replace(minute=45, second=0, microsecond=0)
    if now > datetime.now(timezone.utc):
        now -= timedelta(hours=1)
    return now - T0


class ScenarioFirms:
    default_sources = ["VIIRS_NOAA20_NRT"]

    def __init__(self, sc: Scenario, shift: timedelta):
        self.sc, self.shift = sc, shift
        self.now = T0 + shift

    def _hs(self, h, when: datetime) -> Hotspot:
        return Hotspot(h.product, h.lat, h.lon, when, None, h.instrument, h.confidence,
                       _conf_score(h.confidence, h.instrument), h.frp, None, None, "D", fire_type=h.fire_type)

    def _result(self, hs: list[Hotspot], label: str, days: int) -> FirmsResult:
        return FirmsResult(sorted(hs, key=lambda h: h.acq_datetime), ["SCENARIO"], label, days, None,
                           self.now.isoformat(), [f"scenario:{self.sc.id}"], False)

    def get_area(self, area, days: int = 1, sources=None, end=None) -> FirmsResult:
        bbox = None if area == "world" else (area if isinstance(area, tuple) else parse_bbox(area))
        inside = (lambda la, lo: True) if bbox is None else (lambda la, lo: in_bbox(la, lo, bbox))
        since = self.now - timedelta(days=int(days))
        out = []
        for h in self.sc.hotspots:
            if not inside(h.lat, h.lon):
                continue
            t = datetime.fromisoformat(h.t) + self.shift
            if t >= since:
                out.append(self._hs(h, t))
            if int(days) > 5:            # a history request (persistence check): earlier detections too
                for d in h.history_days:
                    out.append(self._hs(h, datetime.fromisoformat(d).replace(hour=7, minute=40, tzinfo=timezone.utc)
                                        + self.shift))
        return self._result(out, str(area), int(days))

    def get_country(self, country: str, days: int = 1, sources=None, end=None) -> FirmsResult:
        return self.get_area("world", days, sources, end)

    def key_status(self) -> dict:
        return {"scenario": self.sc.id}


class ScenarioWeather:
    def __init__(self, sc: Scenario, shift: timedelta):
        self.sc, self.shift = sc, shift

    def _site(self, lat: float, lon: float) -> dict:
        return min(self.sc.sites, key=lambda s: haversine_km(lat, lon, s["lat"], s["lon"]))

    def fwi(self, lat: float, lon: float) -> FWIReport:
        site = self._site(lat, lon)
        series = self.sc.fwi.get(site["id"]) or [{"date": T0.date().isoformat(), "fwi": 8.0, "danger": "Low"}]
        days = []
        for x in series:
            date = (datetime.fromisoformat(x["date"]).date() + timedelta(days=self.shift.days)).isoformat()
            days.append(FWIDay(date, 31.0, 45.0, 12.0, 0.0, 88.0, 30.0, 300.0, 0.0, 0.0, float(x["fwi"]), 0.0))
        return FWIReport(lat, lon, days[-1], series[-1]["danger"], days, 0, "scenario FWI series")

    def current(self, lat: float, lon: float) -> WeatherNow:
        return WeatherNow(lat, lon, (T0 + self.shift).isoformat(), "UTC", 31.0, 45.0, 12.0, 0.0, "scenario")

    def geocode(self, name: str, count: int = 3) -> list[dict]:
        n = name.lower().strip()
        return [{"name": s["label"], "lat": s["lat"], "lon": s["lon"], "admin1": None, "country": None}
                for s in self.sc.sites if s["label"].lower() in n or n in s["label"].lower()][:count]


class _NoEnrichment:
    configured = False
    warnings: list = []

    def describe_point(self, lat, lon, instrument=None):
        return {"lat": lat, "lon": lon, "uncertainty_m": 375}

    def context(self, e, category):
        return "unknown_land_cover", []

    def summary(self, e):
        return ""


def image_record_iri(settings: Settings, rec: str) -> str:
    return f"{settings.ns['data']}image/{rec}"


def image_turtle(settings: Settings, sc: Scenario, shift: timedelta) -> str:
    """FFOnto image records (centerWKT, captureTime, Fire observation with its threshold) for R12 / L8."""
    d = TurtleDoc({"ffo": settings.ns["ffo"], "ffv": settings.ns["ffv"], "data": settings.ns["data"]})
    for i in sc.images:
        rec = image_record_iri(settings, i["rec"])
        obs, th = f"{rec}/obs/fire", f"{rec}/threshold/fire"
        d.add_iri(rec, "a", "ffo:ImageRecord")
        d.add(rec, "ffo:centerWKT", wkt_point(i["lat"], i["lon"]))
        if i.get("t"):
            d.add(rec, "ffo:captureTime", Lit((datetime.fromisoformat(i["t"]) + shift).isoformat(), XSD_DT))
        d.add_iri(rec, "ffo:aboutEvent", f"{settings.ns['data']}event/{i['event']}")
        d.add_iri(rec, "ffo:hasObservation", obs)
        d.add_iri(obs, "ffo:predictedClass", "ffv:Fire")
        d.add(obs, "ffo:confidence", Lit(repr(float(i["score"])), XSD_DBL))
        d.add_iri(obs, "ffo:usedThreshold", th)
        d.add(th, "ffo:thresholdValue", Lit(repr(float(i["threshold"])), XSD_DBL))
    return d.serialize()


class ScenarioWorld:
    """Owns one in-memory store for a whole run; `enter(sc)` resets it to one scenario."""

    def __init__(self, settings: Settings, store=None):
        from ..kg.store import make_store

        self.s = settings
        if store is None:
            mem = Settings({**settings.raw, "graphdb": {**(settings.raw.get("graphdb") or {}), "backend": "memory"}},
                           settings.models, settings.root)
            store = make_store(mem)            # needs rdflib; GraphDB is never touched
        self.store = store

    def enter(self, sc: Scenario, llm=None, shift: timedelta | None = None, settings: Settings | None = None):
        from ..tools.toolkit import Toolkit

        s = settings or self.s
        shift = shift or time_shift()
        for g in ("live", "inferred_live"):
            self.store.clear_graph(self.s.graph(g))
        if sc.images:
            self.store.insert_turtle(image_turtle(self.s, sc, shift), self.s.graph("live"))
        tk = Toolkit(s, store=self.store, firms=ScenarioFirms(sc, shift), weather=ScenarioWeather(sc, shift),
                     llm=llm)
        tk.__dict__["classifier"] = HotspotClassifier(
            s.get("hotspot_filter"), [StaticSource(x["name"], x["lat"], x["lon"], x["kind"]) for x in sc.static_sources])
        tk.__dict__["enricher"] = _NoEnrichment()
        return tk
