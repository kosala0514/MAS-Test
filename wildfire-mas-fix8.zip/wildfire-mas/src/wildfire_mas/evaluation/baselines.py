"""Baselines for the end-to-end comparison.

  B1 single_agent  one LLM with the SAME tools as the multi-agent system (FIRMS, weather/FWI, rules,
                   live CQs, documents), choosing tool calls itself in a loop (ReAct-style JSON).
                   It has no planner, no fixed plan, no CRM schema, no verifier.
  B2 llm_only      the same LLM with no tools at all (closed book). Shows what the model alone does with
                   live questions: guessing or saying it cannot know.
  B0 ffonto        the original ffonto-v2 QA pipeline (Part A only; called through the bridge in e2e.py).

All baselines use the synthesizer slot's model, so the comparison is about the architecture, not the model.
"""
from __future__ import annotations

import json
import time

from ..llm import LLMClient, start_call_log

SINGLE_AGENT_SYSTEM = """You are a wildfire screening assistant with tools. Today's live data comes only from the tools.
Call one tool at a time. Reply with JSON only:
  {{"tool": "<name>", "args": {{...}}}}     to call a tool, or
  {{"answer": "<final answer for the user>"}}  when you are done.
Use at most {max_steps} tool calls. Never invent data that a tool did not return.

Tools:
- weather.geocode {{"name": str}}: coordinates of a place
- firms.get_hotspots {{"lat": float, "lon": float, "radius_km": float, "days": int}}: NASA FIRMS hotspots, each
  with a category (only "likely_vegetation_fire" is wildfire evidence)
- weather.fwi {{"lat": float, "lon": float, "site": str|null}}: fire weather index and danger class
- kg.register_site {{"label": str, "lat": float, "lon": float}}: register a location so the rules can use it
- kg.run_rules {{}}: rules R09-R12 -> hazards (nearby fire, spreading fire, raised danger, satellite/image conflict)
- kg.run_cq {{"cq_id": str, "params": {{...}}}}: run a competency question; available: {cqs}
- rag.search {{"query": str}}: passages from wildfire documents
"""

LLM_ONLY_SYSTEM = """You are a wildfire assistant. You have no access to live satellite data, weather data or databases.
Answer the question as well as you can; if it needs data you do not have, say so plainly."""


def _trim(out, n: int = 2500) -> str:
    if isinstance(out, dict) and isinstance(out.get("hotspots"), list):
        out = {**out, "hotspots": [{k: h.get(k) for k in ("latitude", "longitude", "acq_datetime", "category",
                                                           "frp", "confidence_raw")} for h in out["hotspots"][:8]]}
    if isinstance(out, dict) and isinstance(out.get("hazards"), list):
        out = {**out, "hazards": [{k: h.get(k) for k in ("rule", "type", "site", "explanation")} for h in out["hazards"][:10]]}
    s = json.dumps(out, default=str)
    return s[:n] + ("…" if len(s) > n else "")


async def single_agent(question: str, bus, llm: LLMClient, cq_menu: str, context: str = "",
                       max_steps: int = 8) -> dict:
    log = start_call_log()
    t0 = time.perf_counter()
    system = SINGLE_AGENT_SYSTEM.format(max_steps=max_steps, cqs=cq_menu)
    transcript = f"Question: {question}" + (f"\nContext: {context}" if context else "")
    calls, issues, answer = [], [], ""
    for _ in range(max_steps + 1):
        try:
            out = await llm.chat_json("synthesizer", system, transcript)
        except Exception as e:  # noqa: BLE001
            issues.append(f"LLM failed: {e.__class__.__name__}")
            break
        if "answer" in out:
            answer = str(out["answer"])
            break
        tool, args = out.get("tool"), out.get("args") or {}
        if not tool or len(calls) >= max_steps:
            issues.append("no final answer within the step budget")
            break
        try:
            res = await bus.call(tool, args)
            calls.append({"tool": tool, "args": args, "ok": True})
        except Exception as e:  # noqa: BLE001
            res = {"error": f"{e.__class__.__name__}: {e}"}
            calls.append({"tool": tool, "args": args, "ok": False})
        transcript += f"\n\nCALL {tool} {json.dumps(args, default=str)}\nRESULT {_trim(res)}"
    if not answer:
        try:
            answer = await llm.chat("synthesizer", "Write the final answer from the tool results so far. Plain text.",
                                    transcript, json_mode=False)
        except Exception as e:  # noqa: BLE001
            issues.append(f"final answer failed: {e.__class__.__name__}")
    return {"answer": answer, "intent": None, "cited_hazards": None, "derived_hazards": None, "grounded_rate": None,
            "tool_calls": len(calls), "llm_calls": len(log), "issues": issues,
            "latency_s": round(time.perf_counter() - t0, 2),
            "tokens": sum((c.prompt_tokens or 0) + (c.completion_tokens or 0) for c in log),
            "trace": {"calls": calls}}


async def llm_only(question: str, llm: LLMClient, context: str = "") -> dict:
    log = start_call_log()
    t0 = time.perf_counter()
    issues = []
    try:
        answer = await llm.chat("synthesizer", LLM_ONLY_SYSTEM,
                                question + (f"\nContext: {context}" if context else ""), json_mode=False)
    except Exception as e:  # noqa: BLE001
        answer, issues = "", [f"LLM failed: {e.__class__.__name__}"]
    return {"answer": answer, "intent": None, "cited_hazards": None, "derived_hazards": None, "grounded_rate": None,
            "tool_calls": 0, "llm_calls": len(log), "issues": issues, "latency_s": round(time.perf_counter() - t0, 2),
            "tokens": sum((c.prompt_tokens or 0) + (c.completion_tokens or 0) for c in log), "trace": {}}
