"""Command line: wfmas ask | hotspots | fwi | rules | test-cqs | shacl | key-status | ontology |
golden-import | golden-partb | eval-filter | eval-rules"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .config import get_settings


def _print(obj) -> None:
    print(json.dumps(obj, indent=2, default=str))


def cmd_ask(a) -> int:
    from .agents.state import Request
    from .orchestrator import build

    orch = build(transport=a.transport)
    req = Request(a.question, record=a.record, lat=a.lat, lon=a.lon, place=a.place, area=a.area, role=a.role)

    async def go():
        try:
            return await orch.ask(req)
        finally:
            await orch.bus.aclose()

    res = asyncio.run(go())
    print(res.answer_markdown or "(no answer)")
    print(f"\n-- intent {res.intent} | urgency {res.urgency} | {res.timings.get('total', 0):.1f}s | "
          f"{len(res.tool_calls)} tool calls | {len(res.llm_calls)} LLM calls")
    for e in res.evidence:
        print(f"[{e['id']}] {e['source']}")
    for i in res.issues:
        print(f"! {i}")
    if a.json:
        with open(a.json, "w") as f:
            f.write(res.to_json())
        print(f"full trace written to {a.json}")
    return 0


def cmd_hotspots(a) -> int:
    from .tools.toolkit import Toolkit

    out = Toolkit().firms_get_hotspots(area=a.area, lat=a.lat, lon=a.lon, radius_km=a.radius_km, days=a.days,
                                       persistence=not a.no_persistence, store=not a.no_store,
                                       max_items=a.max_items)
    if a.brief:
        out = {k: v for k, v in out.items() if k != "hotspots"}
    _print(out)
    return 0


def cmd_fwi(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().weather_fwi(a.lat, a.lon, store=not a.no_store))
    return 0


def cmd_rules(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().kg_run_rules())
    return 0


def cmd_key(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().firms_key_status())
    return 0


def cmd_test_cqs(a) -> int:
    from .tools.toolkit import Toolkit

    tk = Toolkit()
    failed = 0
    tested = 0
    for cq in tk.catalog.by_id.values():
        if not cq.expect:
            continue
        tested += 1
        out = tk.kg_run_cq(cq.id, cq.expect.get("params", {}))
        rows = out.get("rows", [])
        ok = out.get("ok") and len(rows) >= int(cq.expect.get("min_rows", 1))
        for var, needle in (cq.expect.get("contains") or {}).items():
            ok = ok and any(needle in str(r.get(var, "")) for r in rows)
        failed += not ok
        print(f"{'PASS' if ok else 'FAIL'} {cq.id} ({len(rows)} rows){'' if ok else ' ' + str(out.get('errors', ''))}")
    print(f"{tested - failed}/{tested} CQ tests passed")
    return 1 if failed else 0


def cmd_ontology(a) -> int:
    """Load / unload the live-module .ttl files into GraphDB, or clear the live data graphs."""
    from pathlib import Path

    from .kg.store import make_store

    s = get_settings()
    store = make_store(s)
    if a.action == "clear-live":
        for g in ("live", "inferred_live"):
            store.clear_graph(s.graph(g))
            print(f"cleared {s.graph(g)}")
        return 0
    src = Path(a.dir) if a.dir else s.root / "ontology"
    pairs = [(src / "ffonto-live.ttl", s.graph("ontology")), (src / "ffonto-live-vocab.ttl", s.graph("vocab"))]
    for f, graph in pairs:
        if not f.exists():
            print(f"skip {f}: not found")
            continue
        if a.action == "load":
            store.insert_turtle(f.read_text(encoding="utf-8"), graph)
            print(f"loaded {f.name} into {graph}")
            continue
        from rdflib import BNode, Graph

        g = Graph().parse(f, format="turtle")
        triples = [t for t in g if not any(isinstance(x, BNode) for x in t)]
        for i in range(0, len(triples), 500):
            body = "\n".join(f"{t[0].n3()} {t[1].n3()} {t[2].n3()} ." for t in triples[i:i + 500])
            store.update(f"DELETE DATA {{ GRAPH <{graph}> {{\n{body}\n}} }}")
        print(f"removed {len(triples)} triples of {f.name} from {graph}")
    return 0


def cmd_golden_import(a) -> int:
    """Part A of the golden set from ffonto-v2's labelled ForestFire-VQA questions."""
    import random

    from .kg.ffonto_bridge import FfontoBridge

    s = get_settings()
    b = FfontoBridge(s)
    if not b.configured:
        print("set FFONTO_V2_PATH (or ffonto_v2.path) to your ffonto-v2 folder first")
        return 1
    items = b.all_examples()
    rnd = random.Random(a.seed)
    order = list(range(len(items)))
    rnd.shuffle(order)
    n_dev = int(len(items) * a.dev)
    dev = set(order[:n_dev])
    out = s.path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for i, e in enumerate(items):
            oos = (e["label"] or "").upper() == "OOS"
            f.write(json.dumps({
                "id": f"A{i + 1:04d}", "part": "A", "question": e["question"],
                "gold_intent": e["intent"], "gold_cq": None if oos else e["label"],
                "gold_route": "rag" if oos else "kg", "modality": e.get("modality"),
                "gold_answer": e.get("answer") or "", "source": e.get("source") or "",
                "split": "dev" if i in dev else "test"}, ensure_ascii=False) + "\n")
    n_kg = sum(1 for e in items if (e["label"] or "").upper() != "OOS")
    print(f"wrote {len(items)} items ({n_kg} KG, {len(items) - n_kg} general knowledge; "
          f"{n_dev} dev / {len(items) - n_dev} test) to {out}")
    print("labels are silver (keyword rules + review in FFVQA_CQ_mapping.xlsx): review the confusion pairs "
          "after the first run, as docs/EVALUATION.md in ffonto-v2 says")
    return 0


def cmd_golden_partb(a) -> int:
    """Part B of the golden set: synthetic live/geospatial scenarios + end-to-end questions."""
    from .evaluation.scenarios import Generator, Spec, write_partb

    s = get_settings()
    spec = Spec.from_settings(s)
    info = write_partb(Generator(a.seed, spec).generate(a.per_family), s.path(a.out_dir), spec, a.dev)
    _print(info)
    return 0


def cmd_eval_filter(a) -> int:
    from datetime import date as _date, timedelta as _td
    from pathlib import Path

    from .evaluation import live_eval as le

    s = get_settings()
    sweep = [int(x) for x in a.sweep.split(",")] if a.sweep else None
    if a.firms_csv or a.fetch_area:
        sources = (a.source or "VIIRS_SNPP_SP").split(",")
        if a.firms_csv:
            hs = le.load_firms_files(a.firms_csv, a.source)
            label = ", ".join(a.firms_csv)
            first = min(h.acq_datetime.date() for h in hs)
            score_from = _date.fromisoformat(a.score_from) if a.score_from else first + _td(days=a.warmup)
        else:
            from .live.firms import FirmsClient

            end = _date.fromisoformat(a.end)
            res = FirmsClient(s).get_area(a.fetch_area, days=a.days + a.warmup, sources=sources, end=end)
            hs = res.hotspots
            score_from = end - _td(days=a.days - 1)
            label = f"{'+'.join(sources)} {a.fetch_area}, {a.days} days to {a.end}"
        ov = {}
        if a.min_days is not None:
            ov["persistence_min_days"] = a.min_days
        if a.keep_low_confidence:
            ov["viirs_low_confidence_is_weak"] = False
        out = le.eval_filter_firms(s, hs, use_static=a.static, label=label, score_from=score_from,
                                   land_mask=a.land_mask, sweep=sweep, overrides=ov)
    else:
        out = le.eval_filter_scenarios(s, le.scenarios_or_default(s, a.scenarios))
    print((Path(out["out_dir"]) / "summary.md").read_text())
    print(f"results in {out['out_dir']}")
    return 0


def cmd_eval_rules(a) -> int:
    from pathlib import Path

    from .evaluation import live_eval as le

    s = get_settings()
    out = le.eval_rules(s, le.scenarios_or_default(s, a.scenarios), tuple(a.modes.split(",")))
    print((Path(out["out_dir"]) / "summary.md").read_text())
    print(f"results in {out['out_dir']}")
    return 0


def cmd_where(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().geo_describe(a.lat, a.lon, a.instrument))
    return 0


def cmd_enrich_sample(a) -> int:
    from datetime import date as _date
    from pathlib import Path

    from .evaluation import live_eval as le
    from .live.classify import HotspotClassifier
    from .live.firms import FirmsClient

    s = get_settings()
    end = _date.fromisoformat(a.end) if a.end else None
    res = FirmsClient(s).get_area(a.area, days=a.days, sources=a.source.split(",") if a.source else None, end=end)
    HotspotClassifier.from_settings(s).classify(res.hotspots)
    _print(le.enrich_sample(s, res.hotspots, a.n, Path(a.out)))
    return 0


def cmd_eval_enrich(a) -> int:
    from pathlib import Path

    from .evaluation import live_eval as le

    out = le.eval_enrich(get_settings(), Path(a.labels))
    print((Path(out["out_dir"]) / "summary.md").read_text())
    print(f"results in {out['out_dir']}")
    return 0


def cmd_e2e(a) -> int:
    from .evaluation.e2e import main_e2e

    s = get_settings()
    out = main_e2e(s, a.part.upper(), [x.strip() for x in a.systems.split(",")], a.dataset, a.split, a.limit,
                   not a.no_judge, a.include_rag, a.qtypes.split(",") if a.qtypes else None, a.judge_model)
    print((out / "summary.md").read_text())
    print(f"results in {out}")
    return 0


def cmd_e2e_agreement(a) -> int:
    from pathlib import Path

    from .evaluation.e2e import judge_agreement

    _print(judge_agreement(Path(a.file)))
    return 0


def cmd_shacl(a) -> int:
    """Validate the live + inferred-live graphs against ontology/shapes-live.ttl (needs pyshacl)."""
    import requests
    from pyshacl import validate
    from rdflib import Graph

    s = get_settings()
    g = Graph()
    if s.get("graphdb.backend") == "memory":
        print("shacl: memory backend holds no persistent data; use GraphDB")
        return 1
    ep = f"{s.get('graphdb.url').rstrip('/')}/repositories/{s.get('graphdb.repository')}/statements"
    for name in ("live", "inferred_live", "vocab"):
        r = requests.get(ep, params={"context": f"<{s.graph(name)}>"}, headers={"Accept": "text/turtle"}, timeout=120)
        r.raise_for_status()
        g.parse(data=r.text, format="turtle")
    conforms, _, text = validate(g, shacl_graph=str(s.root / "ontology" / "shapes-live.ttl"), inference="none")
    print(text)
    return 0 if conforms else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="wfmas")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("ask", help="ask the multi-agent system a question")
    p.add_argument("question")
    p.add_argument("--record")
    p.add_argument("--lat", type=float)
    p.add_argument("--lon", type=float)
    p.add_argument("--place")
    p.add_argument("--area", help="'w,s,e,n', 'world' or ISO3 country code")
    p.add_argument("--role", default="analyst", choices=["analyst", "incident_commander", "public"])
    p.add_argument("--transport", default="inprocess", choices=["inprocess", "mcp"])
    p.add_argument("--json", help="write the full trace (plan, evidence, calls) to this file")
    p.set_defaults(fn=cmd_ask)

    p = sub.add_parser("hotspots", help="fetch + label FIRMS hotspots (and store them in the live graph)")
    p.add_argument("--area", help="'w,s,e,n', 'world' or ISO3 (default: configured region)")
    p.add_argument("--lat", type=float)
    p.add_argument("--lon", type=float)
    p.add_argument("--radius-km", type=float, default=25)
    p.add_argument("--days", type=int, default=1)
    p.add_argument("--max-items", type=int, default=50)
    p.add_argument("--no-store", action="store_true")
    p.add_argument("--no-persistence", action="store_true")
    p.add_argument("--brief", action="store_true")
    p.set_defaults(fn=cmd_hotspots)

    p = sub.add_parser("fwi", help="compute today's FWI at a point")
    p.add_argument("--lat", type=float, required=True)
    p.add_argument("--lon", type=float, required=True)
    p.add_argument("--no-store", action="store_true")
    p.set_defaults(fn=cmd_fwi)

    sub.add_parser("rules", help="run live rules R09-R12").set_defaults(fn=cmd_rules)
    sub.add_parser("key-status", help="FIRMS MAP_KEY usage").set_defaults(fn=cmd_key)
    sub.add_parser("test-cqs", help="run CQ tests (entries with an expect block)").set_defaults(fn=cmd_test_cqs)
    sub.add_parser("shacl", help="validate live graphs with SHACL").set_defaults(fn=cmd_shacl)

    p = sub.add_parser("ontology", help="load/unload the live-module ontology in GraphDB, or clear live data")
    p.add_argument("action", choices=["load", "unload", "clear-live"])
    p.add_argument("--dir", help="folder with ffonto-live.ttl / ffonto-live-vocab.ttl (default: ontology/)")
    p.set_defaults(fn=cmd_ontology)

    p = sub.add_parser("golden-import", help="build golden Part A from ffonto-v2's labelled questions")
    p.add_argument("--out", default="eval/datasets/golden_partA.jsonl")
    p.add_argument("--dev", type=float, default=0.3, help="share of items in the dev split")
    p.add_argument("--seed", type=int, default=42)
    p.set_defaults(fn=cmd_golden_import)

    p = sub.add_parser("golden-partb", help="build golden Part B: synthetic live scenarios + questions")
    p.add_argument("--out-dir", default="eval/datasets")
    p.add_argument("--per-family", type=int, default=40, help="scenarios per family (decoy gets half)")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--dev", type=float, default=0.3)
    p.set_defaults(fn=cmd_golden_partb)

    p = sub.add_parser("eval-filter", help="evaluate the hotspot filter (Part B, or real FIRMS SP data)")
    p.add_argument("--scenarios", help="default: eval/datasets/golden_partB_scenarios.jsonl")
    p.add_argument("--firms-csv", nargs="+", help="FIRMS standard-processing CSV file(s) with a `type` column")
    p.add_argument("--fetch-area", help="fetch SP data for 'w,s,e,n' instead (uses your MAP_KEY)")
    p.add_argument("--end", help="last day to fetch, YYYY-MM-DD (SP data lags about 2-3 months)")
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--source", help="VIIRS_SNPP_SP (default), VIIRS_NOAA20_SP, MODIS_SP; comma-separate several")
    p.add_argument("--warmup", type=int, default=30, help="extra days fetched before the scored period, used "
                   "only as history for the persistence check (default 30, as in the live system)")
    p.add_argument("--score-from", help="with --firms-csv: first scored day (default: first day + warmup)")
    p.add_argument("--static", action="store_true", help="also use data/static_sources.csv")
    p.add_argument("--land-mask", help="GeoJSON of land polygons (offshore check), e.g. ne_10m_land.geojson")
    p.add_argument("--sweep", help="persistence thresholds to compare, e.g. 3,4,5,6,8")
    p.add_argument("--min-days", type=int, help="persistence threshold for this run (default: settings.yaml)")
    p.add_argument("--keep-low-confidence", action="store_true",
                   help="treat VIIRS low-confidence detections as possible fires (recall over precision)")
    p.set_defaults(fn=cmd_eval_filter)

    p = sub.add_parser("eval-rules", help="evaluate rules R09-R12 on Part B scenarios")
    p.add_argument("--scenarios", help="default: eval/datasets/golden_partB_scenarios.jsonl")
    p.add_argument("--modes", default="oracle,pipeline,nofilter")
    p.set_defaults(fn=cmd_eval_rules)

    p = sub.add_parser("e2e", help="end-to-end evaluation: system vs baselines / ablations")
    p.add_argument("--part", default="B", choices=["A", "B", "a", "b"])
    p.add_argument("--systems", default="mas,single_agent,llm_only",
                   help="mas, single_agent, llm_only, ffonto (Part A), mas-no_iors, mas-no_verifier, mas-no_crm, "
                        "mas-no_ialt, mas-no_filter, mas-no_rules")
    p.add_argument("--dataset", help="default: eval/datasets/golden_part{A,B}.jsonl")
    p.add_argument("--split", default="test", choices=["dev", "test", "all"])
    p.add_argument("--limit", type=int, help="number of questions (stratified by question type)")
    p.add_argument("--qtypes", help="Part B only, e.g. L1,L2,L9")
    p.add_argument("--no-judge", action="store_true", help="score with the rule checks only (no LLM judge)")
    p.add_argument("--judge-model", help="Ollama tag for the judge (default: models.yaml slot 'judge')")
    p.add_argument("--include-rag", action="store_true", help="Part A: also the general-knowledge questions")
    p.set_defaults(fn=cmd_e2e)

    p = sub.add_parser("e2e-agreement", help="judge vs your grades in human_check.csv (Cohen's kappa)")
    p.add_argument("file")
    p.set_defaults(fn=cmd_e2e_agreement)

    p = sub.add_parser("where", help="describe a point: protected area, district, nearest place, land cover")
    p.add_argument("--lat", type=float, required=True)
    p.add_argument("--lon", type=float, required=True)
    p.add_argument("--instrument", default="VIIRS")
    p.set_defaults(fn=cmd_where)

    p = sub.add_parser("enrich-sample", help="write a labelling sheet of enriched hotspots (fire-context evaluation)")
    p.add_argument("--area", default="79.5,5.8,82.0,9.9", help="'w,s,e,n' (use --area=... for negative values)")
    p.add_argument("--days", type=int, default=10)
    p.add_argument("--end", help="YYYY-MM-DD (default: today, NRT data)")
    p.add_argument("--source", help="FIRMS sources, comma-separated (default: settings)")
    p.add_argument("-n", type=int, default=100)
    p.add_argument("--out", default="eval/datasets/enrich_labels.csv")
    p.set_defaults(fn=cmd_enrich_sample)

    p = sub.add_parser("eval-enrich", help="score fire-context labels against your manual labels")
    p.add_argument("--labels", default="eval/datasets/enrich_labels.csv")
    p.set_defaults(fn=cmd_eval_enrich)

    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
