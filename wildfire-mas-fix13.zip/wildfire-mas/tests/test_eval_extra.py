"""Evaluation additions: hold-out and splits, depth / trade-off, plain RAG baseline, confidence and tokens,
re-scoring (FCR, auto-fail, rubric, several judges, experts), analyses, delay, text-to-SPARQL ablation."""
import asyncio
import json
import sys
import types

from fakes import RoutingStore

from wildfire_mas.evaluation import analysis, e2e, holdout, plots, rescore, sweeps
from wildfire_mas.evaluation.resources import ResourceMonitor
from wildfire_mas.evaluation.scenarios import Generator, Spec, questions_for
from wildfire_mas.evaluation.world import ScenarioWorld
from wildfire_mas.llm import ScriptedLLM


def _partA(n_groups=30, per=3, gk=12):
    items = []
    for g in range(n_groups):
        for j in range(per):
            items.append({"id": f"A{g}-{j}", "question": f"question {g} {j}", "source": f"img_{g}.jpg",
                          "gold_cq": f"CQ{(g % 9) + 1:02d}", "gold_route": "kg", "gold_intent": "data_lookup"})
    for j in range(gk):
        items.append({"id": f"G{j}", "question": f"general {j}", "source": "General Knowledge", "gold_cq": None,
                      "gold_route": "rag", "gold_intent": "explanation"})
    return items


# ------------------------------------------------------------------------------ #37 #39 #41
def test_grouped_split_keeps_records_together_and_covers_cqs(tmp_path):
    rows = holdout.grouped_split(_partA(), 0.3, 1)
    dev = {r["group"] for r in rows if r["split"] == "dev"}
    test = {r["group"] for r in rows if r["split"] == "test"}
    assert not (dev & test)
    n_dev = sum(r["split"] == "dev" for r in rows)
    assert 0.2 * len(rows) < n_dev < 0.4 * len(rows)
    dev_cqs = {r["gold_cq"] for r in rows if r["split"] == "dev"}
    assert {f"CQ{i:02d}" for i in range(1, 10)} <= dev_cqs        # every CQ seen in dev
    p = tmp_path / "g.jsonl"
    p.write_text("\n".join(json.dumps(r) for r in rows))
    md = holdout.overlap_report(p)
    assert "records in both splits: 0" in md and "test CQs with no dev example: 0" in md
    files = holdout.resplit(p, [1, 2], 0.3, tmp_path / "splits")
    assert len(files) == 2 and files[0].read_text() != files[1].read_text()


def test_overlap_seen_unseen_and_splits_summary(tmp_path):
    ds = tmp_path / "a.jsonl"
    ds.write_text("\n".join(json.dumps({**r, "split": "dev" if i % 3 == 0 else "test"})
                            for i, r in enumerate(_partA(4, 2, 0))))
    runs = []
    for k, acc in (("s1", [1, 1, 0, 1]), ("s2", [1, 0, 0, 1])):
        d = tmp_path / k
        d.mkdir()
        d.joinpath("items.jsonl").write_text("\n".join(json.dumps(
            {"model": "m", "repeat": 0, "gold_cq": "CQ01", "cq_correct": bool(a), "intent_correct": True,
             "route_correct": True, "gold_cq_in_examples": i < 2, "gold_cq_top1_example": i == 0})
            for i, a in enumerate(acc)))
        runs.append(d)
    md = holdout.overlap_report(ds, runs[0])
    assert "CQ acc (seen)" in md and "| m | 4 | 0.500 | 0.250 | 1.000 (n=2) | 0.500 (n=2) |" in md
    s = holdout.splits_summary(runs)
    assert "0.625 ± 0.177" in s


def test_planner_uses_dev_pool_depth_and_hints(settings, tmp_path):
    from wildfire_mas.agents.planner import Planner
    from wildfire_mas.agents.state import Request
    from wildfire_mas.evaluation.harness import apply_planner_options
    from wildfire_mas.kg.cq import CQCatalog

    ds = tmp_path / "pool.jsonl"
    ds.write_text(json.dumps({"question": "Is smoke visible?", "split": "dev"}) + "\n"
                  + json.dumps({"question": "Is fire visible?", "split": "test"}) + "\n")
    seen = {}

    class Bridge:
        configured = True

        def registry(self):
            return {}

        def menu(self):
            return ""

        def nearest_examples(self, q, k, exclude_self, allowed):
            seen.update(k=k, allowed=allowed)
            return [{"question": f"e{i}", "label": f"CQ{i:02d}", "intent": "data_lookup"} for i in range(1, k + 1)]

    apply_planner_options(settings, str(ds), "dev", k=5, hints=2)
    llm = ScriptedLLM(settings, {"planner": lambda m: json.dumps({"intent": "data_lookup", "cq": None, "topic": "t"})})
    p = Planner(llm, CQCatalog.load(settings), settings, Bridge())
    out = asyncio.run(p.classify(Request("Is there smoke?")))
    assert seen["k"] == 5 and seen["allowed"] == {"is smoke visible?"}
    assert out["_hints"] == ["CQ01", "CQ02"] and len(out["_examples"]) == 5


# ------------------------------------------------------------------------------ #6 #8 #31 #35 #36
def _scripted(settings):
    def planner(msgs):
        q = msgs[-1]["content"].rsplit("Question:", 1)[1]
        return json.dumps({"intent": "hazard_advice" if "hazards" in q else "situational_awareness",
                           "urgency": "normal", "topic": q})

    def synth(msgs):
        sys_ = msgs[0]["content"]
        if "retrieved once" in sys_:                                   # plain RAG baseline
            return "No active fires were detected near the location."
        return json.dumps({"sections": [{"title": "Situation", "sentences": [
            {"text": "No active fires were detected within 10 km.", "cites": ["LIVE1"]}]}], "confidence": 0.8})

    def judge(msgs):
        return json.dumps({"grade": "correct" if "No likely wildfire" in msgs[-1]["content"] else "wrong", "why": "t"})

    return ScriptedLLM(settings, {"planner": planner, "synthesizer": synth, "judge": judge,
                                  "rag_grader": lambda m: json.dumps({"grades": [], "rewrite": None})})


def _run(settings, systems=("mas", "plain_rag", "single_agent")):
    gen = Generator(9, Spec.from_settings(settings))
    scs = [gen.r09(), gen.decoy()]
    items = [q for sc in scs for q in questions_for(sc) if q["qtype"] in ("L1", "L9")]
    for i, q in enumerate(items):
        q["id"] = f"T{i}"
    mon = ResourceMonitor(enabled=False).start()
    rows = asyncio.run(e2e.run_partb(settings, list(systems), items, {s.id: s for s in scs}, _scripted(settings), True,
                                     ScenarioWorld(settings, store=RoutingStore([])), log=lambda *_: None, monitor=mon))
    mon.stop()
    return rows, items, mon


def test_plain_rag_baseline_confidence_tokens_and_monitor(settings, tmp_path):
    rows, items, mon = _run(settings)
    assert not [r for r in rows if r["error"]], [r["error"] for r in rows if r["error"]][:2]
    rag = [r for r in rows if r["system"] == "plain_rag"]
    assert len(rag) == len(items) and all(r["answer"] for r in rag)
    assert all(r["llm_calls"] == 1 and r["tool_calls"] >= 3 for r in rag if r.get("place"))
    mas = [r for r in rows if r["system"] == "mas"]
    assert all(r["confidence"] == 0.8 for r in mas) and all(r["tokens_by_slot"].get("synthesizer") is not None for r in mas)
    assert all(isinstance(r["relaxations"], int) and r["n_steps"] > 0 for r in mas)
    assert all(r["gold_facts"] is not None for r in rows)
    rep = mon.write(tmp_path, ["m"])
    assert set(rep["per_system"]) == {"mas", "plain_rag", "single_agent"}
    assert rep["per_system"]["mas"]["questions"] == len(items) and (tmp_path / "resources.md").exists()


def test_iors_round_counting():
    assert e2e.iors_rounds(["IORS rounds: 10 km/2 d: 0; 25 km/2 d: 1", "IORS: CQL02 {}: ok -> radius=20: ok",
                            "rewrote query to 'x'", "matched known site"]) == 3


# ------------------------------------------------------------------------------ #18 #20 #22 #24 #27
def _fake_run(tmp_path, settings):
    rows, items, _ = _run(settings, ("mas", "single_agent"))
    run = tmp_path / "run"
    run.mkdir()
    e2e.write_outputs(run, rows, "x", True, "B")
    return run, rows


def test_rescore_fcr_autofail_rubric_and_judges(settings, tmp_path, monkeypatch):
    run, rows = _fake_run(tmp_path, settings)

    def judge_reply(msgs):
        sys_ = msgs[0]["content"]
        if "decision-support quality" in sys_:
            return json.dumps({"relevance": 8, "actionability": 6, "safety": 9, "completeness": 7, "conciseness": 8,
                               "fail": False, "why": "ok"})
        return json.dumps({"grade": "correct", "why": "ok"})

    monkeypatch.setattr(rescore, "LLMClient", lambda s, ov=None: ScriptedLLM(s, {"judge": judge_reply}))
    out = rescore.rescore(settings, run, judges=["j1", "j2"], rubric=True, log=lambda *_: None)
    rs = [json.loads(x) for x in (out / "items_rescored.jsonl").read_text().splitlines()]
    assert all("fcr" in r and "auto_fail" in r and "strict_grade" in r for r in rs)
    assert all(set(r["judges"]) == {"j1", "j2"} for r in rs)
    l9 = [r for r in rs if r.get("qtype") == "L9"]
    assert l9 and all(r["rubric_score"] == 74.3 and r["rubric_band"] == "Adequate" for r in l9)
    md = (out / "rescore.md").read_text()
    assert "Fact coverage" in md and "Several judges" in md and "Fleiss" in md and "Decision-support rubric" in md
    # expert sheet round trip
    sheet, key = rescore.expert_sheet(run, n=4)
    lines = sheet.read_text().splitlines()
    assert lines[0].startswith("item,question") and "mas" not in lines[0] and len(lines) > 1
    import csv
    rows_ = list(csv.DictReader(sheet.open()))
    for r in rows_:
        r.update(relevance="7", actionability="6", safety="8", completeness="6", conciseness="7", fail="")
    with sheet.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows_[0]))
        w.writeheader()
        w.writerows(rows_)
    md = rescore.expert_agreement(run, sheet, key)
    assert "answers rated" in md and "Expert vs LLM rubric" in md


def test_fact_coverage_and_auto_fail_rules():
    it = lambda q, **f: {"id": "x", "qtype": q, "gold_facts": f, "gold_hazards": [], "place": "Kandy"}  # noqa: E731
    assert rescore.fcr(rescore.key_facts_b(it("L2", nearest_km=8.7)), "It is 8.6 km away.")[0] == 1.0
    assert rescore.fcr(rescore.key_facts_b(it("L2", nearest_km=8.7)), "It is 9.5 km away.")[0] == 0.0
    l4 = it("L4", non_wildfire=True, categories=["offshore", "static_land_source"])
    assert abs(rescore.fcr(rescore.key_facts_b(l4), "Some are not wildfires: an industrial flare.")[0] - 2 / 3) < 1e-9
    l9 = {**it("L9"), "gold_hazards": ["NearbyActiveFire"]}
    assert rescore.auto_fail(l9, "An active fire is near; it is spreading fast. Leave now.", 1.0)
    assert rescore.auto_fail(it("L1", fire_nearby=False), "Yes, a wildfire is burning 4 km away.", 0.0)
    assert "generic" in rescore.auto_fail(it("L6", danger="High"), "Always follow local guidance.", 0.0)[0]
    assert rescore.text_fact_found("2.64 acres", "about 2.6 acres") and not rescore.text_fact_found("crown fire", "surface fire")
    assert rescore.fleiss_kappa([["a", "a"], ["b", "b"], ["a", "b"]]) is not None


def test_keyfacts_draft_and_part_a_fcr(settings, tmp_path, monkeypatch):
    ds = tmp_path / "a.jsonl"
    ds.write_text(json.dumps({"id": "A1", "question": "How big?", "gold_answer": "2.64 acres", "split": "test"}) + "\n")
    monkeypatch.setattr(rescore, "LLMClient",
                        lambda s, ov=None: ScriptedLLM(s, {"judge": lambda m: json.dumps({"facts": ["2.64 acres"]})}))
    out = rescore.keyfacts_draft(settings, ds, "test", tmp_path / "kf.csv", "m", log=lambda *_: None)
    assert "2.64 acres" in out.read_text()
    assert rescore.load_keyfacts(out) == {}                       # not reviewed yet
    lines = out.read_text().splitlines()
    out.write_text("\n".join([lines[0], lines[1] + "y"]) + "\n")
    assert rescore.load_keyfacts(out) == {"A1": ["2.64 acres"]}
    run = tmp_path / "runA"
    run.mkdir()
    (run / "items.jsonl").write_text(json.dumps({"id": "A1", "system": "mas", "question": "How big?",
                                                 "answer": "About 2.6 acres burned.", "judge_grade": "correct"}) + "\n")
    rescore.rescore(settings, run, ds, out, log=lambda *_: None)
    r = json.loads((run / "items_rescored.jsonl").read_text())
    assert r["fcr"] == 1.0


# ------------------------------------------------------------------------------ #29 #30 #31 #32 #33 #35 #47
def test_analysis_report_cases_and_charts(settings, tmp_path, monkeypatch):
    run, _ = _fake_run(tmp_path, settings)
    rows = [json.loads(x) for x in (run / "items.jsonl").read_text().splitlines()]
    for i, r in enumerate(rows):                                   # pretend a rubric pass happened
        if r.get("qtype") == "L9":
            r["rubric_band"] = ["Poor", "Adequate", "Excellent"][(i + (r["system"] == "mas")) % 3]
    (run / "items_rescored.jsonl").write_text("\n".join(json.dumps(r) for r in rows))
    analysis.analyze(run)
    md = (run / "analysis.md").read_text()
    for h in ("by difficulty", "Effort vs quality", "calibration", "Before / after", "Tokens", "Resources"):
        assert h.lower() in md.lower(), h
    assert "over-confident" in md or "under-confident" in md
    assert (run / "calibration.svg").read_text().startswith("<svg") and (run / "band_matrix.svg").exists()
    assert (run / "cases.md").read_text().startswith("# Worked cases")
    assert analysis.tier({"qtype": "L9"}) == "hard" and analysis.tier({"gold_cq": "CQ08"}) == "easy"


def test_delay_analysis_table():
    md = analysis.delay_analysis(27, [3.0], [40.0])
    assert "| 3 | 40 | 4.0 | 12.00 | 30 | 12.03 | 120% |" in md


def test_tradeoff_and_plots(tmp_path):
    d = tmp_path / "planner"
    d.mkdir()
    d.joinpath("items.jsonl").write_text("\n".join(json.dumps(
        {"model": m, "repeat": 0, "cq_correct": c, "latency_s": lat, "prompt_tokens": 10, "completion_tokens": 5})
        for m, c, lat in (("a", True, 1.0), ("a", False, 1.2), ("b", True, 5.0), ("b", True, 6.0))))
    md, svg = sweeps.tradeoff([d])
    assert md.index("| b |") < md.index("| a |") and svg.startswith("<svg") and ">b<" in svg
    assert plots.line({"x": [(1, 0.5), (3, 0.7)]}, "t", "k", "acc").startswith("<svg")


# ------------------------------------------------------------------------------ #13
def test_t2s_ablation_toggles_steps_and_restores(settings, tmp_path, monkeypatch):
    config = types.SimpleNamespace(T2S_BIND_CONTEXT=True, T2S_SCHEMA_LINK=True, T2S_ADAPT_TEMPLATE=True,
                                   T2S_EXEC_FEEDBACK=True, SPARQL_MODEL="m")
    cqs = types.SimpleNamespace(REGISTRY={"CQ01": 1, "CQ02": 1},
                                run_cq=lambda c, record=None, date=None: {"rows": [{"v": "1"}]})
    calls = []

    def t2s(question, record, hints, date=None, event=None, mode=None):
        calls.append((mode, list(hints), config.T2S_SCHEMA_LINK, config.T2S_EXEC_FEEDBACK))
        good = mode == "plus" and config.T2S_SCHEMA_LINK
        return "SELECT", ["v"], [{"v": "1"}] if good else [{"v": "2"}], {}

    mods = {"qa.pipeline": types.SimpleNamespace(text_to_sparql=t2s),
            "qa.metrics": types.SimpleNamespace(result_set_prf=lambda p, g: (1.0, 1.0, 1.0) if p == g else (0.0, 0.0, 0.0)),
            "qa.evaluate": types.SimpleNamespace(_record_lookup=lambda: {}, _weather_dates=lambda: set(),
                                                 match_context=lambda e, l, d: ({"iri": "urn:r"}, None))}
    for k, v in mods.items():
        sys.modules[k] = v

    class Bridge:
        def __init__(self, s, model=None):
            self.qa = {"config": config, "cqs": cqs}

        configured = True

        def available(self):
            return True

        def nearest_examples(self, q, k, exclude_self, allowed):
            return [{"label": "CQ01"}, {"label": "CQ02"}]

    import wildfire_mas.kg.ffonto_bridge as fb
    monkeypatch.setattr(fb, "FfontoBridge", Bridge)
    settings.raw.setdefault("paths", {})["runs_dir"] = str(tmp_path / "runs")
    ds = tmp_path / "a.jsonl"
    ds.write_text("\n".join(json.dumps({"id": f"A{i}", "question": f"q{i}", "gold_cq": "CQ01", "gold_route": "kg",
                                        "split": "test" if i else "dev"}) for i in range(4)))
    try:
        from wildfire_mas.evaluation.t2s_ablation import t2s_ablation
        out = t2s_ablation(settings, ds, log=lambda *_: None)
    finally:
        for k in mods:
            sys.modules.pop(k, None)
    md = (out / "summary.md").read_text()
    assert all(v is True for v in (config.T2S_SCHEMA_LINK, config.T2S_EXEC_FEEDBACK))   # restored
    assert any(m == "naive" and h == [] for m, h, *_ in calls)                          # zero-shot: no examples
    assert any(m == "plus" and not s for m, _, s, _ in calls)                           # no_schema run
    assert "| plus | " in md and "plus-no_schema" in md and "McNemar" in md
    assert "gold CQ among hints: 1.000" in md


def test_main_e2e_writes_run_metadata_and_resources(settings, tmp_path, monkeypatch):
    from wildfire_mas.evaluation import harness
    from wildfire_mas.evaluation.scenarios import write_partb

    spec = Spec.from_settings(settings)
    write_partb(Generator(3, spec).generate(1), tmp_path, spec, 0.3)
    pool = tmp_path / "golden_partA.jsonl"
    pool.write_text(json.dumps({"question": "Is smoke visible?", "split": "dev"}) + "\n")
    monkeypatch.setattr(e2e, "LLMClient", lambda s, ov=None: _scripted(s))
    monkeypatch.setattr(harness, "preflight", lambda llm, slot: None)
    import wildfire_mas.evaluation.world as world_mod
    real = world_mod.ScenarioWorld
    monkeypatch.setattr(world_mod, "ScenarioWorld", lambda s, **kw: real(s, store=RoutingStore([])))
    settings.raw.setdefault("paths", {})["runs_dir"] = str(tmp_path / "runs")
    out = e2e.main_e2e(settings, "B", ["mas", "plain_rag"], str(tmp_path / "golden_partB.jsonl"), "all", 6, True,
                       qtypes=["L1", "L6"], store_kind="memory", model="m-x", example_pool="all", k=4, tag="t1")
    meta = json.loads((out / "run.json").read_text())
    assert meta["systems"] == ["mas", "plain_rag"] and meta["k"] == 4 and out.name.endswith("_t1")
    assert (out / "resources.md").exists() and set(meta["throughput"]) == {"mas", "plain_rag"}
    assert "tokens" in (out / "summary.md").read_text()
