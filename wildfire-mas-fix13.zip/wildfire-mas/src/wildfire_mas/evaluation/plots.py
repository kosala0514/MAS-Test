"""Dependency-free SVG charts for the evaluation reports (open in a browser, or insert into Word/PowerPoint).

  scatter      accuracy vs latency per model (#10), with 95 % CI whiskers
  line         a metric against a parameter, e.g. CQ accuracy vs number of examples (#14)
  heatmap      before/after band matrix (#32)
  reliability  confidence calibration diagram (#31)
"""
from __future__ import annotations

import html
import math

INK, MUTED, GRID, ACCENT, TEAL = "#16201d", "#5f6b67", "#e2ddd2", "#b8461a", "#1d6a73"
FONT = "font-family='Helvetica, Arial, sans-serif'"


def _e(s) -> str:
    return html.escape(str(s))


def _nice_ticks(lo: float, hi: float, n: int = 5) -> list[float]:
    if hi <= lo:
        hi = lo + 1
    raw = (hi - lo) / n
    mag = 10 ** math.floor(math.log10(raw))
    step = min((m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw), default=raw)
    start = math.floor(lo / step) * step
    ticks, v = [], start
    while v <= hi + 1e-9:
        ticks.append(round(v, 10))
        v += step
    return ticks


def _frame(w, h, title, xlabel, ylabel) -> list[str]:
    return [f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {w} {h}' width='{w}' height='{h}' {FONT}>",
            f"<rect width='{w}' height='{h}' fill='#ffffff'/>",
            f"<text x='24' y='34' font-size='18' font-weight='700' fill='{INK}'>{_e(title)}</text>",
            f"<text x='{w / 2}' y='{h - 14}' font-size='13' fill='{MUTED}' text-anchor='middle'>{_e(xlabel)}</text>",
            f"<text transform='translate(18 {h / 2}) rotate(-90)' font-size='13' fill='{MUTED}' "
            f"text-anchor='middle'>{_e(ylabel)}</text>"]


def _axes(out, x0, y0, x1, y1, xt, yt, sx, sy, xfmt="{:g}", yfmt="{:.2f}"):
    for t in yt:
        y = sy(t)
        out.append(f"<line x1='{x0}' x2='{x1}' y1='{y:.1f}' y2='{y:.1f}' stroke='{GRID}'/>")
        out.append(f"<text x='{x0 - 8}' y='{y + 4:.1f}' font-size='11' fill='{MUTED}' text-anchor='end'>{yfmt.format(t)}</text>")
    for t in xt:
        x = sx(t)
        out.append(f"<line x1='{x:.1f}' x2='{x:.1f}' y1='{y0}' y2='{y1}' stroke='{GRID}'/>")
        out.append(f"<text x='{x:.1f}' y='{y1 + 18}' font-size='11' fill='{MUTED}' text-anchor='middle'>{xfmt.format(t)}</text>")
    out.append(f"<line x1='{x0}' x2='{x1}' y1='{y1}' y2='{y1}' stroke='{INK}'/>")
    out.append(f"<line x1='{x0}' x2='{x0}' y1='{y0}' y2='{y1}' stroke='{INK}'/>")


def scatter(points: list[dict], title: str, xlabel: str, ylabel: str, w: int = 760, h: int = 480,
            log_x: bool = False) -> str:
    """points: {label, x, y, lo?, hi?}"""
    pts = [p for p in points if p.get("x") is not None and p.get("y") is not None]
    x0, y0, x1, y1 = 78, 56, w - 40, h - 64
    out = _frame(w, h, title, xlabel, ylabel)
    if not pts:
        out.append(f"<text x='{w / 2}' y='{h / 2}' text-anchor='middle' fill='{MUTED}'>no data</text></svg>")
        return "\n".join(out)
    tx = (lambda v: math.log10(max(v, 1e-3))) if log_x else (lambda v: v)
    xs = [tx(p["x"]) for p in pts]
    ys = [p["y"] for p in pts] + [p["lo"] for p in pts if p.get("lo") is not None] + \
         [p["hi"] for p in pts if p.get("hi") is not None]
    xl, xh = min(xs), max(xs)
    pad = (xh - xl) * 0.12 or 0.5
    xl, xh = xl - pad, xh + pad
    yl, yh = max(0.0, min(ys) - 0.05), min(1.0, max(ys) + 0.05) if max(ys) <= 1 else max(ys) * 1.05
    sx = lambda v: x0 + (tx(v) - xl) / (xh - xl) * (x1 - x0)  # noqa: E731
    sy = lambda v: y1 - (v - yl) / (yh - yl) * (y1 - y0)  # noqa: E731
    xt = [10 ** t for t in _nice_ticks(xl, xh)] if log_x else _nice_ticks(xl, xh)
    _axes(out, x0, y0, x1, y1, [t for t in xt if xl <= tx(t) <= xh], [t for t in _nice_ticks(yl, yh) if yl <= t <= yh],
          sx, sy, "{:.3g}")
    for p in pts:
        x, y = sx(p["x"]), sy(p["y"])
        if p.get("lo") is not None and p.get("hi") is not None:
            out.append(f"<line x1='{x:.1f}' x2='{x:.1f}' y1='{sy(p['lo']):.1f}' y2='{sy(p['hi']):.1f}' "
                       f"stroke='{TEAL}' stroke-width='2'/>")
        out.append(f"<circle cx='{x:.1f}' cy='{y:.1f}' r='6' fill='{ACCENT if p.get('highlight') else TEAL}'/>")
        out.append(f"<text x='{x + 9:.1f}' y='{y - 8:.1f}' font-size='12' fill='{INK}'>{_e(p['label'])}</text>")
    out.append("</svg>")
    return "\n".join(out)


def line(series: dict[str, list[tuple[float, float]]], title: str, xlabel: str, ylabel: str,
         w: int = 760, h: int = 440) -> str:
    """series: name -> [(x, y), ...]"""
    allp = [p for s in series.values() for p in s if p[1] is not None]
    x0, y0, x1, y1 = 78, 56, w - 170, h - 64
    out = _frame(w, h, title, xlabel, ylabel)
    if not allp:
        out.append("</svg>")
        return "\n".join(out)
    xl, xh = min(p[0] for p in allp), max(p[0] for p in allp)
    yl, yh = max(0.0, min(p[1] for p in allp) - 0.05), min(1.0, max(p[1] for p in allp) + 0.05)
    xh = xh if xh > xl else xl + 1
    sx = lambda v: x0 + (v - xl) / (xh - xl) * (x1 - x0)  # noqa: E731
    sy = lambda v: y1 - (v - yl) / (yh - yl) * (y1 - y0)  # noqa: E731
    _axes(out, x0, y0, x1, y1, sorted({p[0] for p in allp}), [t for t in _nice_ticks(yl, yh) if yl <= t <= yh], sx, sy)
    colors = [TEAL, ACCENT, "#6a4c93", "#2a9d8f", "#8a5a00", "#3d5a80"]
    for i, (name, pts) in enumerate(series.items()):
        c = colors[i % len(colors)]
        pts = sorted(p for p in pts if p[1] is not None)
        if len(pts) > 1:
            out.append("<polyline fill='none' stroke='{}' stroke-width='2.5' points='{}'/>".format(
                c, " ".join(f"{sx(x):.1f},{sy(y):.1f}" for x, y in pts)))
        for x, y in pts:
            out.append(f"<circle cx='{sx(x):.1f}' cy='{sy(y):.1f}' r='4.5' fill='{c}'/>")
        out.append(f"<rect x='{x1 + 20}' y='{y0 + 22 * i}' width='12' height='12' fill='{c}'/>")
        out.append(f"<text x='{x1 + 38}' y='{y0 + 22 * i + 11}' font-size='12' fill='{INK}'>{_e(name)}</text>")
    out.append("</svg>")
    return "\n".join(out)


def heatmap(rows: list[str], cols: list[str], counts: dict[tuple[str, str], int], title: str,
            ylabel: str, xlabel: str, w: int = 620, h: int = 520) -> str:
    x0, y0 = 150, 80
    cw = (w - x0 - 30) / max(1, len(cols))
    ch = (h - y0 - 70) / max(1, len(rows))
    out = _frame(w, h, title, xlabel, ylabel)
    mx = max(counts.values() or [1]) or 1
    for j, c in enumerate(cols):
        out.append(f"<text x='{x0 + cw * (j + 0.5):.1f}' y='{y0 - 10}' font-size='12' fill='{INK}' "
                   f"text-anchor='middle'>{_e(c)}</text>")
    for i, r in enumerate(rows):
        out.append(f"<text x='{x0 - 10}' y='{y0 + ch * (i + 0.5) + 4:.1f}' font-size='12' fill='{INK}' "
                   f"text-anchor='end'>{_e(r)}</text>")
        for j, c in enumerate(cols):
            n = counts.get((r, c), 0)
            a = 0.08 + 0.85 * n / mx if n else 0.0
            out.append(f"<rect x='{x0 + cw * j:.1f}' y='{y0 + ch * i:.1f}' width='{cw - 2:.1f}' height='{ch - 2:.1f}' "
                       f"fill='{TEAL}' fill-opacity='{a:.2f}' stroke='{GRID}'/>")
            out.append(f"<text x='{x0 + cw * (j + 0.5):.1f}' y='{y0 + ch * (i + 0.5) + 5:.1f}' font-size='14' "
                       f"text-anchor='middle' fill='{'#ffffff' if a > 0.55 else INK}'>{n}</text>")
    out.append("</svg>")
    return "\n".join(out)


def reliability(bins: list[dict], title: str, w: int = 560, h: int = 520) -> str:
    """bins: {lo, hi, conf, acc, n} -> reliability diagram (diagonal = perfect calibration)."""
    x0, y0, x1, y1 = 78, 56, w - 40, h - 64
    out = _frame(w, h, title, "stated confidence", "observed score")
    sx = lambda v: x0 + v * (x1 - x0)  # noqa: E731
    sy = lambda v: y1 - v * (y1 - y0)  # noqa: E731
    ticks = [0, 0.2, 0.4, 0.6, 0.8, 1.0]
    _axes(out, x0, y0, x1, y1, ticks, ticks, sx, sy, "{:.1f}", "{:.1f}")
    out.append(f"<line x1='{sx(0)}' y1='{sy(0)}' x2='{sx(1)}' y2='{sy(1)}' stroke='{MUTED}' stroke-dasharray='5 4'/>")
    for b in bins:
        if not b["n"]:
            continue
        bw = (sx(b["hi"]) - sx(b["lo"])) * 0.8
        xm = (sx(b["lo"]) + sx(b["hi"])) / 2
        out.append(f"<rect x='{xm - bw / 2:.1f}' y='{sy(b['acc']):.1f}' width='{bw:.1f}' "
                   f"height='{sy(0) - sy(b['acc']):.1f}' fill='{TEAL}' fill-opacity='0.75'/>")
        out.append(f"<circle cx='{sx(b['conf']):.1f}' cy='{sy(b['acc']):.1f}' r='4' fill='{ACCENT}'/>")
        out.append(f"<text x='{xm:.1f}' y='{sy(b['acc']) - 6:.1f}' font-size='11' text-anchor='middle' "
                   f"fill='{INK}'>n={b['n']}</text>")
    out.append("</svg>")
    return "\n".join(out)
