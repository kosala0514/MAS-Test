"""Planner sweeps and trade-off charts.

  depth_sweep     #14 retrieval depth: CQ accuracy for k = 1, 3, 5, 8, 15 few-shot examples (one model)
  tradeoff        #10 accuracy vs latency per model, from planner runs or e2e runs (SVG + table)
  #9 model size is a normal planner sweep over one family, e.g. --models qwen3:4b,qwen3:8b,qwen3:14b;
     `tradeoff --x size` then plots accuracy against the size Ollama reports for each model.
"""
from __future__ import annotations

import asyncio
import json
import statistics
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from ..config import load_settings
from . import plots
from .metrics import bootstrap_ci


def _load(path: Path) -> list[dict]:
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def depth_sweep(dataset: str, split: str, example_pool: str, ks: list[int], model: str, provider: str = "ollama",
                limit: int | None = None, log=print) -> Path:
    from .harness import apply_planner_options, run_sweep

    base = load_settings()
    root = base.root / base.get("paths.runs_dir", "runs") / f"{datetime.now():%Y%m%d_%H%M%S}_depth_{model.replace(':', '-')}"
    root.mkdir(parents=True, exist_ok=True)
    items = _load(Path(dataset))
    if split != "all":
        items = [i for i in items if i.get("split", split) == split]
    if limit:
        items = items[:limit]
    res = {}
    for k in ks:
        s = load_settings()
        apply_planner_options(s, dataset, example_pool, k)
        log(f"k = {k}: {len(items)} questions")
        out = asyncio.run(run_sweep(s, "planner", [{"provider": provider, "model": model}], items,
                                    out_dir=root / f"k{k}"))
        res[k] = out["summary"]["models"].get(model)
    (root / "run.json").write_text(json.dumps({"dataset": dataset, "split": split, "example_pool": example_pool,
                                               "ks": ks, "model": model, "n_items": len(items)}, indent=2))
    lines = [f"# Retrieval depth sweep · planner {model}", "",
             f"{len(items)} {split} questions · example pool: {example_pool}", "",
             "| k examples | CQ accuracy [95% CI] | intent accuracy | gold CQ among examples | p50 s | tokens/question |",
             "|---|---|---|---|---|---|"]
    series = defaultdict(list)
    for k in ks:
        m = res.get(k)
        if not m:
            lines.append(f"| {k} | (failed) | | | | |")
            continue
        cq, it = m["cq_correct"], m["intent_correct"]
        hit = (m.get("gold_cq_in_examples") or {}).get("mean")
        hit = hit if isinstance(hit, float) and hit == hit else None
        lines.append(f"| {k} | {cq['mean']:.3f} [{cq['ci95'][0]:.3f}-{cq['ci95'][1]:.3f}] | {it['mean']:.3f} | "
                     f"{'-' if hit is None else f'{hit:.3f}'} | {m['latency_p50']:.2f} | {m['tokens_per_item']:.0f} |")
        series["CQ accuracy"].append((k, cq["mean"]))
        series["intent accuracy"].append((k, it["mean"]))
        if hit is not None:
            series["gold CQ among examples"].append((k, hit))
    lines += ["", "More examples help only while they add new, relevant labels; past that point they add prompt "
                  "tokens and latency. Report the k you use and why."]
    (root / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (root / "depth.svg").write_text(plots.line(series, f"Retrieval depth · {model}", "few-shot examples (k)",
                                               "share of questions"), encoding="utf-8")
    return root


def _ollama_sizes(settings) -> dict[str, float]:
    """Model tag -> size in GB from Ollama's /api/tags (empty if Ollama is unreachable)."""
    import requests

    base = ((settings.models.get("providers") or {}).get("ollama") or {}).get("base_url") or "http://localhost:11434/v1"
    try:
        r = requests.get(base.rstrip("/").removesuffix("/v1") + "/api/tags", timeout=5)
        r.raise_for_status()
        return {m["name"]: m.get("size", 0) / 1e9 for m in r.json().get("models", [])}
    except Exception:  # noqa: BLE001
        return {}


def tradeoff(run_dirs: list[Path], metric: str | None = None, system: str = "mas", x: str = "latency") -> tuple[str, str]:
    """Accuracy vs latency (or model size) per model. Works with planner runs (items.jsonl rows have `model`)
    and e2e runs (rows have `system` and `answer_model`). Returns (markdown, svg)."""
    per: dict[str, dict] = {}
    kind = None
    for d in run_dirs:
        rows = _load(d / "items.jsonl")
        if not rows:
            continue
        if "system" in rows[0]:
            kind = kind or "e2e"
            rows = [r for r in rows if r.get("system") == system]
            met = metric or "correct"
            for r in rows:
                per.setdefault(r.get("answer_model") or d.name, {"vals": [], "lat": [], "tok": []})
                p = per[r.get("answer_model") or d.name]
                p["vals"].append(float(bool(r.get(met))) if isinstance(r.get(met), bool) else r.get(met))
                p["lat"].append(r.get("latency_s"))
                p["tok"].append(r.get("tokens"))
        else:
            kind = kind or "planner"
            met = metric or "cq_correct"
            for r in rows:
                if r.get("repeat", 0):
                    continue
                p = per.setdefault(r["model"], {"vals": [], "lat": [], "tok": []})
                v = r.get(met)
                p["vals"].append(None if v is None else float(v))
                p["lat"].append(r.get("latency_s"))
                p["tok"].append((r.get("prompt_tokens") or 0) + (r.get("completion_tokens") or 0))
    met = metric or ("correct" if kind == "e2e" else "cq_correct")
    sizes = _ollama_sizes(load_settings()) if x == "size" else {}
    pts, lines = [], [f"# Accuracy vs {'model size' if x == 'size' else 'latency'} ({kind} runs, metric `{met}`)", "",
                      "| model | n | " + met + " [95% CI] | p50 latency s | mean tokens | size GB |",
                      "|---|---|---|---|---|---|"]
    best = max(per, key=lambda m: statistics.mean([v for v in per[m]["vals"] if v is not None] or [0]), default=None)
    for m, p in sorted(per.items(), key=lambda kv: -statistics.mean([v for v in kv[1]["vals"] if v is not None] or [0])):
        vals = [v for v in p["vals"] if v is not None]
        if not vals:
            continue
        mean, lo, hi = bootstrap_ci(vals)
        lat = [v for v in p["lat"] if v is not None]
        tok = [v for v in p["tok"] if v is not None]
        p50 = statistics.median(lat) if lat else None
        size = sizes.get(m) or sizes.get(m + ":latest")
        lines.append(f"| {m} | {len(vals)} | {mean:.3f} [{lo:.3f}-{hi:.3f}] | {p50 if p50 is None else round(p50, 2)} | "
                     f"{round(statistics.mean(tok)) if tok else '-'} | {round(size, 1) if size else '-'} |")
        xv = size if x == "size" else p50
        pts.append({"label": m, "x": xv, "y": mean, "lo": lo, "hi": hi, "highlight": m == best})
    if x == "size" and not sizes:
        lines += ["", "Ollama was not reachable, so model sizes are unknown; the chart is empty. Run where Ollama runs."]
    svg = plots.scatter(pts, f"{met} vs {'model size' if x == 'size' else 'median latency'}",
                        "model size (GB)" if x == "size" else "median latency per question (s, log scale)", met,
                        log_x=(x != "size"))
    lines += ["", "Upper-left is best (accurate and fast). Overlapping CI whiskers mean the difference may be noise; "
                  "check the McNemar tests in the run summaries."]
    return "\n".join(lines) + "\n", svg
