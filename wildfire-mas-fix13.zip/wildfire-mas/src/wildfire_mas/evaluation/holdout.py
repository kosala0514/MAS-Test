"""Data-split hygiene for the golden sets (#37 strict hold-out, #39 several splits, #41 structural overlap).

  group_key        questions about the same image / audio clip / weather row form one group, so a record
                   never appears in both dev and test (general-knowledge questions stay independent)
  grouped_split    dev/test split by group (golden-import --group-by source, golden-resplit)
  overlap_report   how much the test questions resemble the example pool: CQ distribution dev vs test,
                   test CQs never seen in dev, records shared between splits, and (with a planner run)
                   accuracy when the gold CQ was / was not among the retrieved examples
  splits_summary   mean and spread of planner metrics over runs on several resampled splits
"""
from __future__ import annotations

import json
import random
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from .metrics import bootstrap_ci


def group_key(item: dict, i: int) -> str:
    src = str(item.get("source") or "").strip()
    if not src or "general" in src.lower():
        return f"q{i}"                     # general knowledge: no shared record, each question on its own
    return src


def grouped_split(items: list[dict], dev_share: float = 0.3, seed: int = 42, by_group: bool = True) -> list[dict]:
    """Assign split = dev/test. With by_group, whole groups go to one side (no record in both)."""
    groups: dict[str, list[int]] = defaultdict(list)
    for i, it in enumerate(items):
        groups[group_key(it, i) if by_group else f"q{i}"].append(i)
    keys = sorted(groups)
    rnd = random.Random(seed)
    rnd.shuffle(keys)
    target = round(len(items) * dev_share)
    dev: set[int] = set()
    # stratify: every CQ that occurs in two or more groups gets at least one group in dev (smallest
    # first), so the strict-hold-out planner still sees an example of each CQ it is tested on
    label = lambda i: str(items[i].get("gold_cq") or items[i].get("label") or "OOS")  # noqa: E731
    by_label: dict[str, list[str]] = defaultdict(list)
    for k in keys:
        for lab in {label(i) for i in groups[k]}:
            by_label[lab].append(k)
    chosen: set[str] = set()
    for lab in sorted(by_label, key=lambda x: len(by_label[x])):
        ks = by_label[lab]
        if len(ks) < 2 or any(k in chosen for k in ks):
            continue
        k = min(ks, key=lambda x: len(groups[x]))
        chosen.add(k)
        dev |= set(groups[k])
    for k in keys:
        if k in chosen:
            continue
        if len(dev) >= target:
            break
        if len(dev) + len(groups[k]) > target + max(3, 0.02 * len(items)):
            continue                        # a big group would overshoot: try the next one
        dev |= set(groups[k])
    out = []
    for i, it in enumerate(items):
        out.append({**it, "split": "dev" if i in dev else "test", "group": group_key(it, i) if by_group else f"q{i}"})
    return out


def resplit(path: Path, seeds: list[int], dev_share: float, out_dir: Path, by_group: bool = True) -> list[Path]:
    items = [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for s in seeds:
        rows = grouped_split(items, dev_share, s, by_group)
        f = out_dir / f"{path.stem}_s{s}.jsonl"
        f.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows) + "\n", encoding="utf-8")
        written.append(f)
    return written


def _load(path: Path) -> list[dict]:
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def overlap_report(dataset: Path, planner_run: Path | None = None) -> str:
    items = _load(dataset)
    for i, it in enumerate(items):
        it.setdefault("group", group_key(it, i))
    dev = [i for i in items if i.get("split") == "dev"]
    test = [i for i in items if i.get("split") == "test"]
    cq = lambda rows: Counter(r.get("gold_cq") or "OOS" for r in rows)  # noqa: E731
    cd, ct = cq(dev), cq(test)
    unseen = {c: n for c, n in ct.items() if c not in cd}
    shared_groups = {i["group"] for i in dev} & {i["group"] for i in test}
    test_shared = [i for i in test if i["group"] in shared_groups]
    lines = [f"# Structural overlap · {dataset.name}", "",
             f"{len(dev)} dev / {len(test)} test questions", "",
             "## 1. Record leakage (questions about the same image / clip / weather row in both splits)", "",
             f"- records in both splits: {len(shared_groups)}",
             f"- test questions whose record also has dev questions: {len(test_shared)} "
             f"({len(test_shared) / max(1, len(test)):.1%})",
             "- fix: `wfmas golden-import --group-by source` (or `wfmas golden-resplit`)" if test_shared else
             "- none: the split is grouped by record", "",
             "## 2. Competency questions in dev vs test", "",
             f"- distinct CQs: dev {len(cd)}, test {len(ct)}",
             f"- test CQs with no dev example: {len(unseen)} ({sum(unseen.values())} test questions)"
             + (": " + ", ".join(f"{c} ({n})" for c, n in sorted(unseen.items())) if unseen else ""), "",
             "| CQ | dev | test |", "|---|---|---|"]
    for c in sorted(set(cd) | set(ct)):
        lines.append(f"| {c} | {cd.get(c, 0)} | {ct.get(c, 0)} |")
    if planner_run:
        rows = _load(planner_run / "items.jsonl")
        lines += ["", f"## 3. Retrieval overlap in planner run `{planner_run.name}`", "",
                  "seen = the gold CQ was among the labels of the retrieved few-shot examples", "",
                  "| model | n | gold CQ in examples | top-1 example = gold | CQ acc (seen) | CQ acc (unseen) |",
                  "|---|---|---|---|---|---|"]
        by = defaultdict(list)
        for r in rows:
            if r.get("gold_cq") and r.get("repeat", 0) == 0:
                by[r.get("model")].append(r)
        for m, rs in by.items():
            seen = [r for r in rs if r.get("gold_cq_in_examples")]
            uns = [r for r in rs if r.get("gold_cq_in_examples") is False]
            acc = lambda xs: (f"{sum(bool(x.get('cq_correct')) for x in xs) / len(xs):.3f} (n={len(xs)})"  # noqa: E731
                              if xs else "-")
            lines.append(f"| {m} | {len(rs)} | {len(seen) / max(1, len(rs)):.3f} | "
                         f"{sum(bool(r.get('gold_cq_top1_example')) for r in rs) / max(1, len(rs)):.3f} | "
                         f"{acc(seen)} | {acc(uns)} |")
        if not by:
            lines.append("| (run has no gold_cq_in_examples: re-run the planner sweep with this version) | | | | | |")
        lines += ["", "Read: a large gap between seen and unseen accuracy means the planner mostly copies the "
                      "label of a similar example; report both numbers."]
    return "\n".join(lines) + "\n"


def splits_summary(run_dirs: list[Path], metrics: tuple[str, ...] = ("cq_correct", "intent_correct", "route_correct")) -> str:
    """Planner runs on several resampled splits -> mean ± sd per model and metric."""
    per: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    used = []
    for d in run_dirs:
        rows = [r for r in _load(d / "items.jsonl") if r.get("repeat", 0) == 0]
        if not rows:
            continue
        used.append(d.name)
        by = defaultdict(list)
        for r in rows:
            by[r["model"]].append(r)
        for m, rs in by.items():
            for k in metrics:
                v = [float(bool(r[k])) for r in rs if r.get(k) is not None]
                if v:
                    per[m][k].append(sum(v) / len(v))
    lines = [f"# Planner metrics over {len(used)} splits", "", "runs: " + ", ".join(used), "",
             "| model | " + " | ".join(f"{k} mean ± sd (min-max)" for k in metrics) + " |",
             "|" + "---|" * (len(metrics) + 1)]
    for m, d in sorted(per.items(), key=lambda kv: -statistics.mean(kv[1].get(metrics[0]) or [0])):
        cells = []
        for k in metrics:
            v = d.get(k) or []
            if not v:
                cells.append("-")
            elif len(v) == 1:
                cells.append(f"{v[0]:.3f} (one split)")
            else:
                cells.append(f"{statistics.mean(v):.3f} ± {statistics.stdev(v):.3f} ({min(v):.3f}-{max(v):.3f})")
        lines.append(f"| {m} | " + " | ".join(cells) + " |")
    return "\n".join(lines) + "\n"


def ci_text(vals) -> str:
    v = [float(x) for x in vals if x is not None]
    if not v:
        return "-"
    m, lo, hi = bootstrap_ci(v)
    return f"{m:.3f} [{lo:.3f}-{hi:.3f}]"
