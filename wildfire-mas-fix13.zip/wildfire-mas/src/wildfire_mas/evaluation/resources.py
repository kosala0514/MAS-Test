"""Resource use during an evaluation run (#36): throughput, GPU power/energy, GPU memory, models in memory,
model storage. Everything is optional: missing tools are reported, never fatal.

  GPU power / memory   `nvidia-smi` sampled every `interval` seconds (NVIDIA GPUs only); energy = power × time
  models in memory     Ollama /api/ps (size and VRAM share of each loaded model)
  storage              Ollama /api/tags (download size of each model used)
  throughput           questions per hour of wall time, per system (marks set by the runner)
"""
from __future__ import annotations

import json
import shutil
import subprocess
import threading
import time
from pathlib import Path


class ResourceMonitor:
    def __init__(self, ollama_base: str | None = None, interval: float = 2.0, enabled: bool = True):
        self.base = (ollama_base or "http://localhost:11434/v1").rstrip("/").removesuffix("/v1")
        self.interval = interval
        self.enabled = enabled
        self.samples: list[dict] = []          # {t, power_w, mem_mb, util}
        self.marks: list[tuple[str, str, float, int]] = []   # (system, start|end, t, n_done)
        self.ps: list[dict] = []
        self.gpu = enabled and shutil.which("nvidia-smi") is not None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.t0 = self.t1 = None

    # ------------------------------------------------------------------ sampling
    def _gpu_sample(self) -> dict | None:
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=power.draw,memory.used,utilization.gpu",
                                  "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=5).stdout
        except Exception:  # noqa: BLE001
            return None
        p = m = u = 0.0
        ok = False
        for line in out.strip().splitlines():          # several GPUs: sum power and memory
            try:
                a, b, c = (float(x) for x in line.split(","))
            except ValueError:
                continue
            p, m, u, ok = p + a, m + b, max(u, c), True
        return {"t": time.time(), "power_w": p, "mem_mb": m, "util": u} if ok else None

    def _ollama_ps(self) -> None:
        try:
            import requests

            r = requests.get(self.base + "/api/ps", timeout=3)
            r.raise_for_status()
            for mdl in r.json().get("models", []):
                self.ps.append({"t": time.time(), "model": mdl.get("name"), "size_gb": (mdl.get("size") or 0) / 1e9,
                                "vram_gb": (mdl.get("size_vram") or 0) / 1e9})
        except Exception:  # noqa: BLE001
            pass

    def _loop(self) -> None:
        last_ps = 0.0
        while not self._stop.is_set():
            if self.gpu:
                s = self._gpu_sample()
                if s:
                    self.samples.append(s)
            if time.time() - last_ps > 30:
                self._ollama_ps()
                last_ps = time.time()
            self._stop.wait(self.interval)

    def start(self) -> "ResourceMonitor":
        self.t0 = time.time()
        if self.enabled:
            self._thread = threading.Thread(target=self._loop, daemon=True)
            self._thread.start()
        return self

    def stop(self) -> None:
        self.t1 = time.time()
        if self._thread:
            self._stop.set()
            self._thread.join(timeout=10)
            self._ollama_ps()

    def mark(self, system: str, what: str, n_done: int = 0) -> None:
        self.marks.append((system, what, time.time(), n_done))

    # ------------------------------------------------------------------ report
    def storage(self, models: list[str]) -> dict[str, float]:
        try:
            import requests

            r = requests.get(self.base + "/api/tags", timeout=5)
            r.raise_for_status()
            tags = {m["name"]: (m.get("size") or 0) / 1e9 for m in r.json().get("models", [])}
        except Exception:  # noqa: BLE001
            return {}
        return {m: round(tags.get(m) or tags.get(f"{m}:latest") or 0, 2) for m in models if m}

    def _energy_wh(self, a: float, b: float) -> float | None:
        pts = [s for s in self.samples if a <= s["t"] <= b]
        if len(pts) < 2:
            return None
        return sum((y["t"] - x["t"]) * (x["power_w"] + y["power_w"]) / 2 for x, y in zip(pts, pts[1:])) / 3600

    def report(self, models: list[str]) -> dict:
        per = {}
        starts = {}
        for system, what, t, n in self.marks:
            if what == "start":
                starts[system] = t
            elif system in starts:
                wall = t - starts[system]
                e = self._energy_wh(starts[system], t)
                pts = [s for s in self.samples if starts[system] <= s["t"] <= t]
                per[system] = {"questions": n, "wall_s": round(wall, 1),
                               "questions_per_hour": round(3600 * n / wall, 1) if wall > 0 and n else None,
                               "energy_wh": round(e, 2) if e is not None else None,
                               "wh_per_question": round(e / n, 3) if e is not None and n else None,
                               "mean_power_w": round(sum(s["power_w"] for s in pts) / len(pts), 1) if pts else None,
                               "peak_gpu_mem_gb": round(max(s["mem_mb"] for s in pts) / 1024, 2) if pts else None}
        loaded = {}
        for p in self.ps:
            cur = loaded.setdefault(p["model"], {"size_gb": 0.0, "vram_gb": 0.0})
            cur["size_gb"] = round(max(cur["size_gb"], p["size_gb"]), 2)
            cur["vram_gb"] = round(max(cur["vram_gb"], p["vram_gb"]), 2)
        return {"gpu_monitor": "nvidia-smi" if self.gpu else "not available (no NVIDIA GPU or nvidia-smi)",
                "total_wall_s": round((self.t1 or time.time()) - (self.t0 or time.time()), 1),
                "per_system": per, "models_in_memory": loaded, "model_storage_gb": self.storage(models),
                "samples": len(self.samples)}

    def write(self, out_dir: Path, models: list[str]) -> dict:
        rep = self.report(models)
        (out_dir / "resources.json").write_text(json.dumps(rep, indent=2), encoding="utf-8")
        lines = ["# Resource use", "", f"GPU monitor: {rep['gpu_monitor']} · total wall time {rep['total_wall_s']} s", "",
                 "| system | questions | wall s | questions/hour | energy Wh | Wh/question | mean power W | peak GPU mem GB |",
                 "|---|---|---|---|---|---|---|---|"]
        for s, r in rep["per_system"].items():
            lines.append(f"| {s} | {r['questions']} | {r['wall_s']} | {r['questions_per_hour']} | {r['energy_wh']} | "
                         f"{r['wh_per_question']} | {r['mean_power_w']} | {r['peak_gpu_mem_gb']} |")
        if rep["models_in_memory"]:
            lines += ["", "| model loaded by Ollama | size in memory GB | of which on GPU GB |", "|---|---|---|"]
            lines += [f"| {m} | {v['size_gb']} | {v['vram_gb']} |" for m, v in rep["models_in_memory"].items()]
            lines += ["", "If 'on GPU' is smaller than 'size in memory', part of the model ran on the CPU: its latency is "
                          "not comparable with models that fit the GPU."]
        if rep["model_storage_gb"]:
            lines += ["", "| model | download size GB |", "|---|---|"]
            lines += [f"| {m} | {g} |" for m, g in rep["model_storage_gb"].items()]
        (out_dir / "resources.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return rep
