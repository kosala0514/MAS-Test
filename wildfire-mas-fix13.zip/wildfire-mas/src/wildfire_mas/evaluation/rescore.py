"""Re-score saved end-to-end runs without re-running the systems (`wfmas rescore`).

  #18 Fact Coverage Rate (FCR)  share of the key facts a correct answer must contain that the answer contains.
                                Deterministic (no LLM): numbers within ±5 %, words / classes case-insensitive,
                                yes/no facts by polarity. Part B facts come from the scenario specification;
                                Part A facts from a reviewed key-facts sheet (`wfmas keyfacts-draft`).
  #20 automatic fail rules      contradicts the reference (yes/no inverted), names a hazard the rules did not
                                derive, generic answer (no place, no number, no key fact), empty answer.
                                Also a stricter judge prompt with the same fail conditions (--rejudge).
  #22 rubric judge              relevance 2/7, actionability 2/7, safety 1/7, specificity/completeness 1/7,
                                conciseness 1/7, each 1-10 -> 0-100 with bands Excellent >=85, Adequate 60-84,
                                Poor 40-59, Fail <=39; automatic fail conditions give 0. Hazard-advice questions.
  #24 several judges            the same answers graded by 2-3 judges: correct rate per judge, spread,
                                pairwise Cohen's kappa, Fleiss' kappa, majority grade
  #27 expert rating             blinded rating sheet + agreement between expert and LLM rubric
Outputs go into the run folder: items_rescored.jsonl, rescore.md (and expert_sheet.csv / expert_key.csv).
"""
from __future__ import annotations

import asyncio
import csv
import json
import random
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from ..llm import LLMClient
from .e2e import GRADE, HAZARD_PAT, NON_WILDFIRE, POS, WORDNUM, _danger_words, polarity, reference, rule_check
from .metrics import bootstrap_ci, cohen_kappa, mcnemar

# ------------------------------------------------------------------------------ key facts (#18)
CATEGORY_PAT = {"static_land_source": r"static|industr|flare|refiner|plant|factory|kiln",
                "persistent_static_source": r"persistent|recurr|same (spot|place|location)|every day|static",
                "offshore": r"offshore|at sea|over (the )?(sea|water|ocean)|platform",
                "volcanic": r"volcan", "low_confidence": r"low[- ]confidence|uncertain|weak detection"}
ACTION_PAT = (r"\b(evacuat|avoid|stay|keep|monitor|move|leave|prepare|alert|report|wear|carry|clear|close|"
              r"warn|check|establish|maintain|withdraw|retreat|patrol|notify|restrict|postpone|follow)\w*")
STOP = {"the", "a", "an", "of", "and", "or", "is", "are", "was", "were", "in", "on", "at", "to", "for", "with",
        "by", "from", "this", "that", "it", "its", "be", "as", "there", "yes", "no", "not"}
_NUM = re.compile(r"(?<![\w.])-?\d+(?:\.\d+)?")


def _numbers(text: str) -> list[float]:
    out = [float(x) for x in _NUM.findall(text or "")]
    out += [float(v) for w, v in WORDNUM.items() if re.search(rf"\b{w}\b", text or "", re.I) and w != "a"]
    return out


def num_match(want: float, text: str, rel: float = 0.05, abs_min: float = 0.0) -> bool:
    tol = max(abs(want) * rel, abs_min)
    return any(abs(v - want) <= tol + 1e-9 for v in _numbers(text))


def key_facts_b(item: dict) -> list[dict]:
    """Facts a correct Part B answer must state, from the gold facts of the scenario specification."""
    q, f = item["qtype"], item.get("gold_facts") or {}
    hz = item.get("gold_hazards") or []
    if q in ("L1", "L12"):
        return [{"name": "fire nearby" if f.get("fire_nearby") else "no fire nearby", "kind": "polarity",
                 "pos": POS[q], "want": bool(f.get("fire_nearby"))}]
    if q == "L2":
        return [{"name": f"nearest {f['nearest_km']} km", "kind": "number", "want": f["nearest_km"], "abs_min": 0.2}]
    if q == "L3":
        return [{"name": f"count {f['count']}", "kind": "count", "want": int(f["count"])}]
    if q == "L4":
        out = [{"name": "non-wildfire detections" if f.get("non_wildfire") else "all vegetation fires",
                "kind": "presence", "pat": NON_WILDFIRE, "want": bool(f.get("non_wildfire"))}]
        for c in f.get("categories") or []:
            out.append({"name": f"category {c}", "kind": "presence", "pat": CATEGORY_PAT.get(c, c.replace("_", " ")),
                        "want": True})
        return out
    if q in ("L5", "L7", "L8"):
        key = {"L5": "spreading", "L7": "raised", "L8": "conflict"}[q]
        return [{"name": key if f.get(key) else f"not {key}", "kind": "polarity", "pos": POS[q],
                 "want": bool(f.get(key)), "absent_ok": not f.get(key)}]
    if q == "L6":
        return [{"name": f"danger {f['danger']}", "kind": "danger", "want": f["danger"]}]
    if q == "L9":
        if not hz:
            return [{"name": "no rule hazard", "kind": "no_hazard"}]
        return ([{"name": f"hazard {h}", "kind": "presence", "pat": HAZARD_PAT[h], "want": True} for h in hz]
                + [{"name": "an action", "kind": "presence", "pat": ACTION_PAT, "want": True}])
    if q == "L10":
        return [{"name": "asks for location", "kind": "presence",
                 "pat": r"location|where|which (place|area|site)|coordinates|specify|provide", "want": True}]
    if q == "L11":
        return [{"name": f"trend {f['direction']}", "kind": "trend", "want": f["direction"]}]
    return []


def fact_found(fact: dict, text: str) -> bool:
    k, t = fact["kind"], text or ""
    if k == "polarity":
        p = polarity(t, fact["pos"])
        if p is None:
            return bool(fact.get("absent_ok"))
        return p == fact["want"]
    if k == "number":
        return num_match(float(fact["want"]), t, 0.05, fact.get("abs_min", 0.0))
    if k == "count":
        return int(fact["want"]) in {int(v) for v in _numbers(t) if float(v).is_integer()}
    if k == "presence":
        return bool(re.search(fact["pat"], t, re.I)) == fact["want"]
    if k == "danger":
        words = _danger_words(fact["want"])
        pat = rf"(?<!very )\b{words}\b" if words in ("high", "low") else rf"\b{words}\b"
        return bool(re.search(pat, t, re.I))
    if k == "trend":
        return bool(rule_check({"qtype": "L11", "gold_facts": {"direction": fact["want"]}}, t))
    if k == "no_hazard":
        return not any(polarity(t, p) for p in HAZARD_PAT.values())
    if k == "text":                      # Part A key fact: a short phrase
        return text_fact_found(fact["text"], t)
    return False


def text_fact_found(fact: str, answer: str) -> bool:
    """Part A: numbers in the fact must appear within ±5 %; the remaining content words must mostly appear
    (word prefixes of 5 letters, so 'burning' matches 'burned'; >= 80 % of them)."""
    nums = [float(x) for x in _NUM.findall(fact)]
    if nums and not all(num_match(n, answer) for n in nums):
        return False
    a = answer.lower()
    if fact.lower().strip(" .") in a:
        return True
    words = [w for w in re.findall(r"[a-z]+", fact.lower()) if w not in STOP and len(w) > 2]
    if not words:
        return bool(nums)
    hits = sum(1 for w in words if re.search(r"\b" + re.escape(w[:5]), a))
    return hits / len(words) >= 0.8


def fcr(facts: list[dict], text: str) -> tuple[float | None, list[str]]:
    if not facts:
        return None, []
    missing = [f["name"] for f in facts if not fact_found(f, text)]
    return (len(facts) - len(missing)) / len(facts), missing


# ------------------------------------------------------------------------------ automatic fail rules (#20)
GENERIC_HINT = r"\b(fire|danger|hazard|hotspot|risk|fwi|smoke|km|class)\w*"


def auto_fail(item: dict, answer: str, facts_found: float | None) -> list[str]:
    """Deterministic fail reasons (empty list = no automatic fail)."""
    t = (answer or "").strip()
    q = item.get("qtype")
    reasons = []
    if not t:
        return ["empty answer"]
    if q in ("L1", "L12", "L5", "L7", "L8"):
        key = {"L1": "fire_nearby", "L12": "fire_nearby", "L5": "spreading", "L7": "raised", "L8": "conflict"}[q]
        p = polarity(t, POS[q])
        want = bool((item.get("gold_facts") or {}).get(key))
        if p is not None and p != want:
            reasons.append("contradicts the reference (yes/no inverted)")
    if q == "L9":
        gold = set(item.get("gold_hazards") or [])
        if gold & {"ElevatedDangerNearActiveFire", "SpreadingFire"}:
            gold.add("NearbyActiveFire")                 # implied by the other two
        for h in ("SpreadingFire", "ElevatedDangerNearActiveFire", "SatelliteSceneConflict"):
            if h not in gold and polarity(t, HAZARD_PAT[h]) is True:
                reasons.append(f"names a hazard the rules did not derive ({h})")
        if "NearbyActiveFire" not in gold and polarity(t, POS["L1"]) is True:
            reasons.append("reports an active fire nearby where the rules found none")
    place = item.get("place")
    if q not in ("L10",) and facts_found == 0.0 and not _numbers(t) and not (place and place.lower() in t.lower()):
        reasons.append("generic answer (no place, no number, no key fact)")
    if re.search(r"\b(i (cannot|can't|do not have)|no (access|information|data) (to|about|on))\b", t, re.I) \
            and facts_found == 0.0 and q not in ("L10",):
        reasons.append("declines although the data was available")
    return reasons


JUDGE_STRICT = """You grade the answer of a wildfire screening system against the reference facts.
Return JSON {"grade": "correct" | "partial" | "wrong" | "no_answer", "why": "<short reason>"}.
correct   = states every key fact of the reference; wording, extra context and safety advice are fine;
partial   = some key facts right, some missing or vague (e.g. right class, missing number);
wrong     = contradicts the reference, OR names a hazard/fire the reference does not support,
            OR is generic advice that does not address this place and question;
no_answer = says it has no information or cannot answer.
Automatic "wrong": a yes/no fact inverted; a number outside ±10 % of the reference; a danger class
different from the reference. Judge only the facts in the reference. Do not reward length."""

# ------------------------------------------------------------------------------ rubric judge (#22)
RUBRIC_WEIGHTS = {"relevance": 2, "actionability": 2, "safety": 1, "completeness": 1, "conciseness": 1}
RUBRIC_SYSTEM = """You rate the decision-support quality of an answer from a wildfire screening system.
You get the question, the reference facts (hazards the rules derived for this place) and the answer.
Score each dimension from 1 (very poor) to 10 (excellent):
- relevance: addresses this place, this situation and the hazards in the reference
- actionability: gives concrete, practical actions or procedures a crew or resident can follow
- safety: correct and safe; nothing that would put people at risk; no invented hazards or numbers
- completeness: covers who/what/where/how; every reference hazard is addressed with an action
- conciseness: clear, no repetition, no filler
Set "fail": true (overall score 0) if the answer is generic only, addresses the wrong hazard, contradicts
the reference, or gives unsafe advice. Reply JSON:
{"relevance": int, "actionability": int, "safety": int, "completeness": int, "conciseness": int,
 "fail": bool, "why": "<one sentence>"}"""
BANDS = [(85, "Excellent"), (60, "Adequate"), (40, "Poor"), (-1, "Fail")]


def band(score: float | None) -> str | None:
    if score is None:
        return None
    return next(b for lo, b in BANDS if score >= lo)


def rubric_score(r: dict) -> float | None:
    try:
        vals = {k: max(1.0, min(10.0, float(r[k]))) for k in RUBRIC_WEIGHTS}
    except (KeyError, TypeError, ValueError):
        return None
    if r.get("fail") in (True, "true", "True", 1):
        return 0.0
    return round(sum(RUBRIC_WEIGHTS[k] * vals[k] for k in vals) / sum(RUBRIC_WEIGHTS.values()) * 10, 1)


def rubric_eligible(row: dict, all_questions: bool = False) -> bool:
    if all_questions:
        return True
    return row.get("qtype") == "L9" or row.get("gold_intent") == "hazard_advice"


# ------------------------------------------------------------------------------ agreement statistics
def fleiss_kappa(ratings: list[list[str]]) -> float | None:
    """ratings: one list of category labels per item (same number of raters per item)."""
    ratings = [r for r in ratings if r and all(x is not None for x in r)]
    if not ratings:
        return None
    n = len(ratings[0])
    if n < 2 or any(len(r) != n for r in ratings):
        return None
    cats = sorted({x for r in ratings for x in r})
    N = len(ratings)
    p_j = {c: sum(r.count(c) for r in ratings) / (N * n) for c in cats}
    P_i = [(sum(r.count(c) ** 2 for c in cats) - n) / (n * (n - 1)) for r in ratings]
    pbar, pe = sum(P_i) / N, sum(v * v for v in p_j.values())
    return 1.0 if pe == 1 else (pbar - pe) / (1 - pe)


def _rank(v: list[float]) -> list[float]:
    order = sorted(range(len(v)), key=lambda i: v[i])
    ranks = [0.0] * len(v)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and v[order[j + 1]] == v[order[i]]:
            j += 1
        for k in range(i, j + 1):
            ranks[order[k]] = (i + j) / 2 + 1
        i = j + 1
    return ranks


def pearson(a: list[float], b: list[float]) -> float | None:
    if len(a) < 3:
        return None
    ma, mb = statistics.mean(a), statistics.mean(b)
    sa = sum((x - ma) ** 2 for x in a) ** 0.5
    sb = sum((y - mb) ** 2 for y in b) ** 0.5
    if not sa or not sb:
        return None
    return sum((x - ma) * (y - mb) for x, y in zip(a, b)) / (sa * sb)


def spearman(a: list[float], b: list[float]) -> float | None:
    return pearson(_rank(a), _rank(b)) if len(a) >= 3 else None


# ------------------------------------------------------------------------------ loading
def load_rows(run: Path) -> list[dict]:
    f = run / "items_rescored.jsonl" if (run / "items_rescored.jsonl").exists() else run / "items.jsonl"
    return [json.loads(x) for x in f.read_text(encoding="utf-8").splitlines() if x.strip()]


def _gold_for(rows: list[dict], run: Path, dataset: Path | None) -> dict[str, dict]:
    """Gold items by id (Part B rows written before this version have no gold_facts)."""
    if dataset is None:
        meta = run / "run.json"
        if meta.exists():
            dataset = Path(json.loads(meta.read_text()).get("dataset") or "")
    gold = {}
    if dataset and dataset.exists():
        for x in dataset.read_text(encoding="utf-8").splitlines():
            if x.strip():
                it = json.loads(x)
                gold[it["id"]] = it
    for r in rows:
        if r["id"] not in gold and r.get("gold_facts") is not None:
            gold[r["id"]] = {k: r.get(k) for k in ("id", "qtype", "question", "place", "gold_facts", "gold_hazards",
                                                   "gold_intent")}
    return gold


def load_keyfacts(path: Path | None) -> dict[str, list[str]]:
    if not path or not path.exists():
        return {}
    out = {}
    for r in csv.DictReader(path.open(encoding="utf-8")):
        facts = [x.strip() for x in (r.get("key_facts") or "").split(";") if x.strip()]
        if facts and (r.get("reviewed") or "").strip().lower() in ("y", "yes", "1", "true", "x"):
            out[r["id"]] = facts
    return out


# ------------------------------------------------------------------------------ the rescore pass
async def _judge_one(llm: LLMClient, system: str, user: str) -> dict:
    try:
        return await llm.chat_json("judge", system, user)
    except Exception as e:  # noqa: BLE001
        return {"error": e.__class__.__name__}


def _judge_user(row: dict, gold: dict | None) -> str:
    ref = row.get("reference") or (reference(gold) if gold and gold.get("qtype") else "")
    hz = ", ".join((gold or {}).get("gold_hazards") or row.get("gold_hazards") or []) or "none"
    return f"Question: {row.get('question')}\nReference facts: {ref}\nRule-derived hazards: {hz}\nAnswer: {row.get('answer') or ''}"


def rescore(settings, run: Path, dataset: Path | None = None, keyfacts: Path | None = None,
            judges: list[str] | None = None, rubric: bool = False, rubric_all: bool = False,
            rejudge: str | None = None, rubric_model: str | None = None, log=print) -> Path:
    rows = load_rows(run)
    gold = _gold_for(rows, run, dataset)
    kf = load_keyfacts(keyfacts)
    answer_models = {r.get("answer_model") for r in rows}
    # ---- deterministic: FCR + automatic fail rules
    for r in rows:
        g = gold.get(r["id"])
        if g:
            for k in ("gold_intent", "qtype", "gold_hazards"):
                if r.get(k) is None and g.get(k) is not None:
                    r[k] = g[k]
        if g and g.get("qtype"):
            facts = key_facts_b(g)
        elif r["id"] in kf:
            facts = [{"name": x, "kind": "text", "text": x} for x in kf[r["id"]]]
        else:
            facts = []
        r["fcr"], r["fcr_missing"] = fcr(facts, r.get("answer") or "")
        r["n_key_facts"] = len(facts)
        r["auto_fail"] = auto_fail(g, r.get("answer") or "", r["fcr"]) if g and g.get("qtype") else \
            (["empty answer"] if not (r.get("answer") or "").strip() else [])
        jg = r.get("judge_grade")
        r["strict_grade"] = "wrong" if r["auto_fail"] and jg in ("correct", "partial") else jg
        r["strict_correct"] = r["strict_grade"] == "correct" if jg else None
    # ---- LLM passes
    llm_jobs = []
    if rejudge:
        llm_jobs.append(("rejudge", rejudge))
    for m in judges or []:
        llm_jobs.append(("judge", m))
    if rubric:
        llm_jobs.append(("rubric", rubric_model or (judges or [rejudge or rows[0].get("judge_model") or "gemma4:12b"])[0]))

    async def run_jobs():
        for kind, model in llm_jobs:
            if model in answer_models:
                log(f"WARNING: {model} also wrote the answers in this run; its grades may favour them")
            llm = LLMClient(settings, {"judge": {"provider": "ollama", "model": model, "json": True}})
            todo = [r for r in rows if kind != "rubric" or rubric_eligible(r, rubric_all)]
            log(f"{kind} with {model}: {len(todo)} answers")
            for i, r in enumerate(todo, 1):
                g = gold.get(r["id"])
                if kind in ("judge", "rejudge"):
                    if not (r.get("answer") or "").strip():
                        out = {"grade": "no_answer", "why": "empty answer"}
                    else:
                        out = await _judge_one(llm, JUDGE_STRICT, _judge_user(r, g))
                    grade = str(out.get("grade", "error")).lower()
                    grade = grade if grade in GRADE else "error"
                    if kind == "rejudge":
                        r["strict_judge_grade"], r["strict_judge_model"] = grade, model
                        r["strict_grade"] = "wrong" if r["auto_fail"] and grade in ("correct", "partial") else grade
                        r["strict_correct"] = r["strict_grade"] == "correct"
                    else:
                        r.setdefault("judges", {})[model] = grade
                else:
                    out = await _judge_one(llm, RUBRIC_SYSTEM, _judge_user(r, g))
                    sc = rubric_score(out)
                    r["rubric"] = {**{k: out.get(k) for k in RUBRIC_WEIGHTS}, "fail": bool(out.get("fail")),
                                   "why": str(out.get("why", ""))[:200], "model": model}
                    r["rubric_score"], r["rubric_band"] = sc, band(sc)
                if i % 50 == 0:
                    log(f"  {i}/{len(todo)}")

    if llm_jobs:
        asyncio.run(run_jobs())
    with (run / "items_rescored.jsonl").open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, default=str, ensure_ascii=False) + "\n")
    (run / "rescore.md").write_text(rescore_report(rows), encoding="utf-8")
    return run


def _ci(vals) -> str:
    v = [float(x) for x in vals if x is not None]
    if not v:
        return "-"
    m, lo, hi = bootstrap_ci(v)
    return f"{m:.3f} [{lo:.3f}-{hi:.3f}]"


def rescore_report(rows: list[dict]) -> str:
    systems = list(dict.fromkeys(r["system"] for r in rows))
    by = defaultdict(list)
    for r in rows:
        by[r["system"]].append(r)
    lines = ["# Re-scoring", "", "## Fact coverage, automatic fails, strict correctness", "",
             "| system | FCR [95% CI] | answers with all key facts | auto-fail rate | judge correct | strict correct |",
             "|---|---|---|---|---|---|"]
    for s in systems:
        rs = by[s]
        full = [float(r["fcr"] == 1.0) for r in rs if r.get("fcr") is not None]
        lines.append(f"| {s} | {_ci([r.get('fcr') for r in rs])} | {_ci(full)} | "
                     f"{_ci([float(bool(r.get('auto_fail'))) for r in rs])} | "
                     f"{_ci([float(r.get('judge_grade') == 'correct') for r in rs if r.get('judge_grade')])} | "
                     f"{_ci([float(bool(r.get('strict_correct'))) for r in rs if r.get('strict_correct') is not None])} |")
    reasons = Counter((r["system"], x) for r in rows for x in r.get("auto_fail") or [])
    if reasons:
        lines += ["", "Automatic fail reasons:", ""]
        lines += [f"- {s}: {x} × {n}" for (s, x), n in reasons.most_common(12)]
    if len(systems) > 1 and all(r.get("fcr") is not None for r in by[systems[0]]):
        base = {r["id"]: r.get("fcr") == 1.0 for r in by[systems[0]]}
        lines += ["", f"McNemar on 'all key facts present' vs {systems[0]}:", ""]
        for s in systems[1:]:
            other = {r["id"]: r.get("fcr") == 1.0 for r in by[s]}
            ks = sorted(set(base) & set(other))
            t = mcnemar([base[k] for k in ks], [other[k] for k in ks])
            lines.append(f"- {s}: {systems[0]}-only {t['b']}, {s}-only {t['c']}, p = {t['p']:.4f}")
    # FCR vs judge (agreement of the deterministic score and the LLM judge)
    pairs = [(r["fcr"], GRADE.get(r.get("judge_grade"))) for r in rows
             if r.get("fcr") is not None and r.get("judge_grade") in GRADE]
    if len(pairs) >= 3:
        a, b = [p[0] for p in pairs], [p[1] for p in pairs]
        dis = [r for r in rows if r.get("fcr") is not None and r.get("judge_grade") in GRADE
               and abs(r["fcr"] - GRADE[r["judge_grade"]]) >= 0.75]
        lines += ["", "## Fact coverage vs LLM judge", "",
                  f"- Pearson r = {pearson(a, b):.3f}, Spearman ρ = {spearman(a, b):.3f} (n = {len(pairs)})"
                  if pearson(a, b) is not None else "- not enough variation to correlate",
                  f"- strong disagreements (|FCR − judge score| ≥ 0.75): {len(dis)}"]
        for r in dis[:8]:
            lines.append(f"  - {r['system']} {r['id']} FCR {r['fcr']:.2f} vs judge {r['judge_grade']}: "
                         f"missing {', '.join(r.get('fcr_missing') or []) or '-'} · \"{(r.get('answer') or '')[:110]}\"")
    # several judges
    jm = sorted({m for r in rows for m in (r.get("judges") or {})})
    if jm:
        lines += ["", "## Several judges (strict prompt)", "",
                  "| system | " + " | ".join(jm) + " | spread | majority correct |", "|" + "---|" * (len(jm) + 3)]
        for s in systems:
            rs = [r for r in by[s] if r.get("judges")]
            rates = []
            cells = []
            for m in jm:
                v = [float(r["judges"].get(m) == "correct") for r in rs if r["judges"].get(m) in GRADE]
                rates.append(sum(v) / len(v) if v else None)
                cells.append(f"{rates[-1]:.3f}" if rates[-1] is not None else "-")
            ok = [x for x in rates if x is not None]
            maj = []
            for r in rs:
                g = [r["judges"].get(m) for m in jm if r["judges"].get(m) in GRADE]
                if g:
                    maj.append(float(Counter(g).most_common(1)[0][0] == "correct"))
            lines.append(f"| {s} | " + " | ".join(cells) + f" | {max(ok) - min(ok):.3f} | "
                         f"{(sum(maj) / len(maj)) if maj else float('nan'):.3f} |" if ok else f"| {s} | - |")
        both = [r for r in rows if r.get("judges") and all(r["judges"].get(m) in GRADE for m in jm)]
        lines += ["", "Pairwise Cohen's kappa (4 grades):", ""]
        for i, m1 in enumerate(jm):
            for m2 in jm[i + 1:]:
                k = cohen_kappa([r["judges"][m1] for r in both], [r["judges"][m2] for r in both])
                lines.append(f"- {m1} vs {m2}: κ = {k:.3f}" if k is not None else f"- {m1} vs {m2}: -")
        if len(jm) >= 2:
            fk = fleiss_kappa([[r["judges"][m] for m in jm] for r in both])
            lines.append(f"- Fleiss' kappa over {len(jm)} judges: {fk:.3f} (n = {len(both)})" if fk is not None else "")
        orig = [r for r in both if r.get("judge_grade") in GRADE]
        for m in jm:
            k = cohen_kappa([r["judge_grade"] for r in orig], [r["judges"][m] for r in orig])
            if k is not None:
                lines.append(f"- run's own judge vs {m}: κ = {k:.3f}")
        lines += ["", "Kappa: <0.2 slight, 0.21-0.40 fair, 0.41-0.60 moderate, 0.61-0.80 substantial, >0.80 almost perfect."]
    # rubric
    rub = [r for r in rows if r.get("rubric_score") is not None]
    if rub:
        lines += ["", "## Decision-support rubric (hazard-advice answers)", "",
                  "| system | n | overall 0-100 [95% CI] | relevance | actionability | safety | completeness | conciseness | "
                  "Excellent | Adequate | Poor | Fail |", "|" + "---|" * 12]
        for s in systems:
            rs = [r for r in rub if r["system"] == s]
            if not rs:
                continue
            dims = [statistics.mean([float(r["rubric"].get(k) or 0) for r in rs]) for k in RUBRIC_WEIGHTS]
            bands = Counter(r["rubric_band"] for r in rs)
            m, lo, hi = bootstrap_ci([r["rubric_score"] for r in rs])
            lines.append(f"| {s} | {len(rs)} | {m:.1f} [{lo:.1f}-{hi:.1f}] | "
                         + " | ".join(f"{d:.1f}" for d in dims) + " | "
                         + " | ".join(str(bands.get(b, 0)) for _, b in BANDS) + " |")
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------------------ expert rating (#27)
EXPERT_COLS = ["relevance", "actionability", "safety", "completeness", "conciseness", "fail", "comment"]


def expert_sheet(run: Path, n: int = 20, seed: int = 5, all_questions: bool = False) -> tuple[Path, Path]:
    """Blinded sheet: answers from every system, shuffled, system names hidden (the key is a separate file)."""
    rows = [r for r in load_rows(run) if rubric_eligible(r, all_questions) and (r.get("answer") or "").strip()]
    rnd = random.Random(seed)
    ids = sorted({r["id"] for r in rows})
    rnd.shuffle(ids)
    pick = set(ids[: max(1, n // max(1, len({r['system'] for r in rows})))])
    chosen = [r for r in rows if r["id"] in pick]
    rnd.shuffle(chosen)
    sheet, key = run / "expert_sheet.csv", run / "expert_key.csv"
    with sheet.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["item", "question", "rule-derived hazards (reference)", "answer"] + EXPERT_COLS)
        for i, r in enumerate(chosen, 1):
            w.writerow([f"E{i:03d}", r.get("question"), ", ".join(r.get("gold_hazards") or []) or "none",
                        r.get("answer")] + [""] * len(EXPERT_COLS))
    with key.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["item", "id", "system"])
        for i, r in enumerate(chosen, 1):
            w.writerow([f"E{i:03d}", r["id"], r["system"]])
    return sheet, key


def expert_agreement(run: Path, sheet: Path, key: Path) -> str:
    keys = {r["item"]: r for r in csv.DictReader(key.open(encoding="utf-8"))}
    rows = {(r["id"], r["system"]): r for r in load_rows(run)}
    exp, llm_s, bands_e, bands_l, per_sys = [], [], [], [], defaultdict(list)
    dim_diff = defaultdict(list)
    n_rated = 0
    for e in csv.DictReader(sheet.open(encoding="utf-8")):
        if not (e.get("relevance") or "").strip():
            continue
        n_rated += 1
        k = keys.get(e["item"])
        sc = rubric_score({**{d: e.get(d) for d in RUBRIC_WEIGHTS}, "fail": (e.get("fail") or "").strip().lower()
                           in ("y", "yes", "1", "true", "x")})
        if sc is None or not k:
            continue
        per_sys[k["system"]].append(sc)
        r = rows.get((k["id"], k["system"]))
        if r and r.get("rubric_score") is not None:
            exp.append(sc)
            llm_s.append(r["rubric_score"])
            bands_e.append(band(sc))
            bands_l.append(r["rubric_band"])
            for d in RUBRIC_WEIGHTS:
                try:
                    dim_diff[d].append(float(r["rubric"].get(d)) - float(e[d]))
                except (TypeError, ValueError):
                    pass
    lines = ["# Expert rating", "", f"{n_rated} answers rated", "", "| system | expert overall (0-100) | n |", "|---|---|---|"]
    for s, v in per_sys.items():
        lines.append(f"| {s} | {statistics.mean(v):.1f} | {len(v)} |")
    if len(exp) >= 3:
        lines += ["", "## Expert vs LLM rubric judge", "",
                  f"- Spearman ρ = {spearman(exp, llm_s):.3f}, Pearson r = {pearson(exp, llm_s):.3f} (n = {len(exp)})"
                  if spearman(exp, llm_s) is not None else "- not enough variation",
                  f"- Cohen's kappa on bands: {cohen_kappa(bands_e, bands_l):.3f}",
                  f"- mean |difference| of overall score: {statistics.mean(abs(a - b) for a, b in zip(exp, llm_s)):.1f}"]
        lines += [f"- {d}: LLM − expert = {statistics.mean(v):+.2f} on the 1-10 scale" for d, v in dim_diff.items() if v]
    else:
        lines += ["", "Run `wfmas rescore <run> --rubric` first, and rate at least 3 answers, to compare with the LLM judge."]
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------------------ Part A key-fact drafts (#18)
KEYFACTS_SYSTEM = """List the key facts a correct answer to the question must contain, taken ONLY from the
reference answer: numbers with units, names, classes, yes/no. 1 to 4 short facts, most important first.
Reply JSON: {"facts": [str]}"""


def keyfacts_draft(settings, dataset: Path, split: str, out: Path, model: str, limit: int | None = None,
                   log=print) -> Path:
    items = [json.loads(x) for x in dataset.read_text(encoding="utf-8").splitlines() if x.strip()]
    items = [i for i in items if (split == "all" or i.get("split") == split) and i.get("gold_answer")]
    if limit:
        items = items[:limit]
    llm = LLMClient(settings, {"judge": {"provider": "ollama", "model": model, "json": True}})

    async def go():
        res = []
        for i, it in enumerate(items, 1):
            out_ = await _judge_one(llm, KEYFACTS_SYSTEM, f"Question: {it['question']}\nReference answer: {it['gold_answer']}")
            facts = [str(x).strip() for x in (out_.get("facts") or []) if str(x).strip()][:4]
            res.append((it, facts))
            if i % 50 == 0:
                log(f"  {i}/{len(items)}")
        return res

    res = asyncio.run(go())
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "question", "gold_answer", "key_facts_draft", "key_facts", "reviewed"])
        for it, facts in res:
            w.writerow([it["id"], it["question"], it["gold_answer"], "; ".join(facts), "; ".join(facts), ""])
    return out
