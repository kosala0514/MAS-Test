"""#13 Text-to-SPARQL step ablation (`wfmas t2s-ablation`).

Runs ffonto-v2's text-to-SPARQL on the Part A knowledge-graph questions whose record or weather day is in
GraphDB, in six configurations, on exactly the same questions:

  zero_shot          the model writes the whole query with no examples (no retrieval at all)
  naive              the model writes the whole query; the retrieved CQ queries are shown as examples (plain RAG)
  plus               context binding + schema linking + template adaptation + execution feedback
  plus-no_bind       plus without context binding (the model must bind ?record / ?date itself)
  plus-no_schema     plus without schema linking (no ontology concepts matched to the question)
  plus-no_template   plus without template adaptation (no nearest CQ query to edit)
  plus-no_feedback   plus without the regeneration on an empty / too large result

The CQ hints come from the same retrieval as in the system: the CQ labels of the embedding-nearest labelled
questions (from the dev split with --example-pool dev). Scored against the gold CQ's rows:
  exec_ok      the query ran;   non_empty   it returned rows
  result P/R/F1  answer-set overlap with the gold rows (KGQA style);   exact   F1 = 1
  hint_hit     the gold CQ was among the hints (retrieval quality, same for every configuration)
"""
from __future__ import annotations

import importlib
import json
import random
import statistics
import time
from datetime import datetime
from pathlib import Path

from .metrics import bootstrap_ci, mcnemar

CONFIGS = {
    "zero_shot": ("naive", {}),
    "naive": ("naive", {}),
    "plus": ("plus", {}),
    "plus-no_bind": ("plus", {"T2S_BIND_CONTEXT": False}),
    "plus-no_schema": ("plus", {"T2S_SCHEMA_LINK": False}),
    "plus-no_template": ("plus", {"T2S_ADAPT_TEMPLATE": False}),
    "plus-no_feedback": ("plus", {"T2S_EXEC_FEEDBACK": False}),
}
FLAGS = ("T2S_BIND_CONTEXT", "T2S_SCHEMA_LINK", "T2S_ADAPT_TEMPLATE", "T2S_EXEC_FEEDBACK")


def _ci(v) -> str:
    v = [float(x) for x in v if x is not None]
    if not v:
        return "-"
    m, lo, hi = bootstrap_ci(v)
    return f"{m:.3f} [{lo:.3f}-{hi:.3f}]"


def t2s_ablation(settings, dataset: Path, split: str = "test", configs: list[str] | None = None,
                 model: str | None = None, limit: int | None = None, example_pool: str = "dev", k: int = 8,
                 hints: int = 3, log=print) -> Path:
    from ..kg.ffonto_bridge import FfontoBridge

    br = FfontoBridge(settings, model)
    if not (br.configured and br.available()):
        raise SystemExit("needs FFONTO_V2_PATH and GraphDB with your ffonto-v2 data")
    qa = br.qa
    config, cqs = qa["config"], qa["cqs"]
    pipeline = importlib.import_module("qa.pipeline")
    M = importlib.import_module("qa.metrics")
    ev = importlib.import_module("qa.evaluate")
    if model:
        config.SPARQL_MODEL = model
    items = [json.loads(x) for x in dataset.read_text(encoding="utf-8").splitlines() if x.strip()]
    allowed = {i["question"].strip().lower() for i in items if i.get("split") == "dev"} if example_pool == "dev" else None
    items = [i for i in items if (split == "all" or i.get("split") == split) and i.get("gold_route") == "kg"
             and i.get("gold_cq") in cqs.REGISTRY]
    lookup, dates = ev._record_lookup(), ev._weather_dates()
    chosen = []
    for it in items:
        e = {"question": it["question"], "answer": it.get("gold_answer", ""), "route": "kg", "cq": it["gold_cq"],
             "source": it.get("source"), "modality": it.get("modality")}
        rec, day = ev.match_context(e, lookup, dates)
        if rec or day:
            chosen.append((it, rec, day))
    if not chosen:
        raise SystemExit("no test question has its record or weather day in GraphDB")
    if limit:
        random.Random(3).shuffle(chosen)
        chosen = chosen[:limit]
    log(f"{len(chosen)} KG questions with data in GraphDB · SPARQL model {config.SPARQL_MODEL}")
    # gold rows and retrieved hints once per question (identical for every configuration)
    prepared = []
    for it, rec, day in chosen:
        try:
            gold = cqs.run_cq(it["gold_cq"], record=rec["iri"] if rec else None, date=day)["rows"]
        except Exception:  # noqa: BLE001
            gold = None
        near = br.nearest_examples(it["question"], k=k, exclude_self=True, allowed=allowed) or []
        hs = [e["label"] for e in near if e.get("label") and e["label"] in cqs.REGISTRY][:hints]
        prepared.append((it, rec, day, gold, hs))
    saved = {f: getattr(config, f) for f in FLAGS}
    out_dir = settings.root / settings.get("paths.runs_dir", "runs") / f"{datetime.now():%Y%m%d_%H%M%S}_t2s_ablation"
    out_dir.mkdir(parents=True, exist_ok=True)
    results: dict[str, list[dict]] = {}
    try:
        with (out_dir / "items.jsonl").open("w", encoding="utf-8") as f:
            for name in configs or list(CONFIGS):
                mode, off = CONFIGS[name]
                for fl in FLAGS:
                    setattr(config, fl, saved[fl] if fl not in off else off[fl])
                rows = []
                for i, (it, rec, day, gold, hs) in enumerate(prepared, 1):
                    t0 = time.perf_counter()
                    try:
                        q, cols, rws, _ = pipeline.text_to_sparql(it["question"], rec["iri"] if rec else None,
                                                                  [] if name == "zero_shot" else hs,
                                                                  date=day, event=None, mode=mode)
                        err = None
                    except Exception as ex:  # noqa: BLE001
                        q, rws, err = None, [], f"{ex.__class__.__name__}: {str(ex)[:200]}"
                    r = {"config": name, "id": it["id"], "gold_cq": it["gold_cq"], "hints": hs,
                         "hint_hit": it["gold_cq"] in hs, "exec_ok": err is None, "non_empty": bool(rws),
                         "n_rows": len(rws), "error": err, "sparql": q, "seconds": round(time.perf_counter() - t0, 2)}
                    if gold is not None:
                        p, rc, f1 = M.result_set_prf(rws, gold)
                        r.update(result_P=p, result_R=rc, result_F1=f1, exact=f1 == 1.0)
                    rows.append(r)
                    f.write(json.dumps(r, default=str) + "\n")
                    if i % 25 == 0:
                        log(f"  {name}: {i}/{len(prepared)}")
                results[name] = rows
    finally:
        for fl, v in saved.items():
            setattr(config, fl, v)
    lines = [f"# Text-to-SPARQL step ablation", "",
             f"{len(prepared)} Part A KG questions ({split}) with data in GraphDB · SPARQL model {config.SPARQL_MODEL} · "
             f"hints from {'dev-split' if allowed is not None else 'all'} examples (k={k}, {hints} hints) · "
             f"gold CQ among hints: {sum(1 for p in prepared if p[0]['gold_cq'] in p[4]) / len(prepared):.3f}", "",
             "| configuration | exec rate | non-empty | result P | result R | result F1 | exact match | p50 s |",
             "|---|---|---|---|---|---|---|---|"]
    for name, rows in results.items():
        lines.append(f"| {name} | {_ci([float(r['exec_ok']) for r in rows])} | {_ci([float(r['non_empty']) for r in rows])} | "
                     f"{_ci([r.get('result_P') for r in rows])} | {_ci([r.get('result_R') for r in rows])} | "
                     f"{_ci([r.get('result_F1') for r in rows])} | "
                     f"{_ci([float(r['exact']) for r in rows if 'exact' in r])} | "
                     f"{statistics.median([r['seconds'] for r in rows]):.2f} |")
    if "plus" in results:
        base = {r["id"]: bool(r.get("exact")) for r in results["plus"]}
        lines += ["", "McNemar on exact match vs plus (the full method):", ""]
        for name, rows in results.items():
            if name == "plus":
                continue
            other = {r["id"]: bool(r.get("exact")) for r in rows}
            ks = sorted(set(base) & set(other))
            t = mcnemar([base[x] for x in ks], [other[x] for x in ks])
            lines.append(f"- {name}: plus-only exact {t['b']}, {name}-only exact {t['c']}, p = {t['p']:.4f}")
    lines += ["", "A step matters when switching it off lowers result F1 / exact match. zero_shot vs naive is the effect "
                  "of retrieved examples (prompting with retrieval); naive vs plus is the effect of the four plus steps "
                  "together; hint_hit is how often retrieval found the right CQ at all."]
    (out_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_dir
