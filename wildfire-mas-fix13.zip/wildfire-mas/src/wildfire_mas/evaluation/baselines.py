"""Baselines for the end-to-end comparison.

  B1 single_agent  one LLM with the SAME tools as the multi-agent system (FIRMS, weather/FWI, rules,
                   live CQs, documents), choosing tool calls itself in a loop (ReAct-style JSON).
                   It has no planner, no fixed plan, no CRM schema, no verifier.
  B2 llm_only      the same LLM with no tools at all (closed book). Shows what the model alone does with
                   live questions: guessing or saying it cannot know.
  B3 plain_rag     standard (non-agentic) RAG: one fixed retrieval round (hotspots 10 km / 1 day, FWI, record
                   facts, top-3 passages) and one LLM call. No planner, IORS, rules, CRM or verifier.
  B0 ffonto        the original ffonto-v2 QA pipeline (Part A only; called through the bridge in e2e.py).

All baselines use the synthesizer slot's model, so the comparison is about the architecture, not the model.
"""
from __future__ import annotations

import json
import time

from ..llm import LLMClient, start_call_log

SINGLE_AGENT_SYSTEM = """You are a wildfire screening assistant with tools. Today's live data comes only from the tools.
Call one tool at a time. Reply with JSON only:
  {{"tool": "<name>", "args": {{...}}}}     to call a tool, or
  {{"answer": "<final answer for the user>"}}  when you are done.
Use at most {max_steps} tool calls. Never invent data that a tool did not return.

Tools:
- weather.geocode {{"name": str}}: coordinates of a place
- firms.get_hotspots {{"lat": float, "lon": float, "radius_km": float, "days": int}}: NASA FIRMS hotspots, each
  with a category (only "likely_vegetation_fire" is wildfire evidence)
- weather.fwi {{"lat": float, "lon": float, "site": str|null}}: fire weather index and danger class
- kg.register_site {{"label": str, "lat": float, "lon": float}}: register a location so the rules can use it
- kg.run_rules {{}}: rules R09-R12 -> hazards (nearby fire, spreading fire, raised danger, satellite/image conflict)
- kg.run_cq {{"cq_id": str, "params": {{...}}}}: run a competency question; available: {cqs}
- rag.search {{"query": str}}: passages from wildfire documents
"""

LLM_ONLY_SYSTEM = """You are a wildfire assistant. You have no access to live satellite data, weather data or databases.
Answer the question as well as you can; if it needs data you do not have, say so plainly."""


def _trim(out, n: int = 2500) -> str:
    if isinstance(out, dict) and isinstance(out.get("hotspots"), list):
        out = {**out, "hotspots": [{k: h.get(k) for k in ("latitude", "longitude", "acq_datetime", "category",
                                                           "frp", "confidence_raw")} for h in out["hotspots"][:8]]}
    if isinstance(out, dict) and isinstance(out.get("hazards"), list):
        out = {**out, "hazards": [{k: h.get(k) for k in ("rule", "type", "site", "explanation")} for h in out["hazards"][:10]]}
    s = json.dumps(out, default=str)
    return s[:n] + ("…" if len(s) > n else "")


async def single_agent(question: str, bus, llm: LLMClient, cq_menu: str, context: str = "",
                       max_steps: int = 8) -> dict:
    log = start_call_log()
    t0 = time.perf_counter()
    system = SINGLE_AGENT_SYSTEM.format(max_steps=max_steps, cqs=cq_menu)
    transcript = f"Question: {question}" + (f"\nContext: {context}" if context else "")
    calls, issues, answer = [], [], ""
    for _ in range(max_steps + 1):
        try:
            out = await llm.chat_json("synthesizer", system, transcript)
        except Exception as e:  # noqa: BLE001
            issues.append(f"LLM failed: {e.__class__.__name__}")
            break
        if "answer" in out:
            answer = str(out["answer"])
            break
        tool, args = out.get("tool"), out.get("args") or {}
        if not tool or len(calls) >= max_steps:
            issues.append("no final answer within the step budget")
            break
        try:
            res = await bus.call(tool, args)
            calls.append({"tool": tool, "args": args, "ok": True})
        except Exception as e:  # noqa: BLE001
            res = {"error": f"{e.__class__.__name__}: {e}"}
            calls.append({"tool": tool, "args": args, "ok": False, "error": res["error"][:300]})
        transcript += f"\n\nCALL {tool} {json.dumps(args, default=str)}\nRESULT {_trim(res)}"
    if not answer:
        try:
            answer = await llm.chat("synthesizer", "Write the final answer from the tool results so far. Plain text.",
                                    transcript, json_mode=False)
        except Exception as e:  # noqa: BLE001
            issues.append(f"final answer failed: {e.__class__.__name__}")
    return {"answer": answer, "intent": None, "cited_hazards": None, "derived_hazards": None, "grounded_rate": None,
            "tool_calls": len(calls), "llm_calls": len(log), "issues": issues,
            "latency_s": round(time.perf_counter() - t0, 2), **token_stats(log),
            "trace": {"calls": calls}}


PLAIN_RAG_SYSTEM = """You are a wildfire screening assistant. Answer the question using ONLY the context below,
which was retrieved once for this question (satellite hotspots within 10 km over the last day, today's fire weather,
facts about the selected record, and document passages). If the context does not answer the question, say so.
Write a short plain-text answer."""


def _wkt_point(rows: list[dict]) -> tuple[float, float] | None:
    import re

    for r in rows or []:
        m = re.search(r"POINT\s*\(\s*(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)", str(r.get("wkt") or ""), re.I)
        if m:
            return float(m.group(2)), float(m.group(1))
    return None


async def plain_rag(question: str, bus, llm: LLMClient, lat: float | None = None, lon: float | None = None,
                    place: str | None = None, record: str | None = None, radius_km: float = 10, days: int = 1,
                    k_docs: int = 3) -> dict:
    """B3 standard (non-agentic) RAG: one fixed retrieval round, then one LLM call.

    Same tools and data as the multi-agent system, but no planner (no intent, no choice of CQ), no retry or
    widening (no IORS), no rules R09-R12, no response schema or citations (no CRM), no verifier."""
    log = start_call_log()
    t0 = time.perf_counter()
    calls, issues, ctx = [], [], []

    async def call(tool, args):
        try:
            out = await bus.call(tool, args)
            calls.append({"tool": tool, "args": args, "ok": True})
            return out
        except Exception as e:  # noqa: BLE001
            calls.append({"tool": tool, "args": args, "ok": False, "error": f"{e.__class__.__name__}: {e}"[:300]})
            return None

    if record:
        facts = await call("kg.run_sparql", {"query": f"SELECT ?p ?o WHERE {{ <{record}> ?p ?o }} LIMIT 40"})
        if facts and facts.get("rows"):
            ctx.append("Selected record facts: " + _trim(facts.get("rows"), 1500))
        loc = await call("kg.run_cq", {"cq_id": "CQL05", "params": {"record": record}})
        pt = _wkt_point((loc or {}).get("rows"))
        if pt and lat is None:
            lat, lon = pt
    if lat is None and place:
        g = await call("weather.geocode", {"name": place})
        res = (g or {}).get("results") or []
        if res:
            lat, lon = res[0].get("lat"), res[0].get("lon")
    if lat is not None and lon is not None:
        hs = await call("firms.get_hotspots", {"lat": lat, "lon": lon, "radius_km": radius_km, "days": days})
        if hs is not None:
            ctx.append(f"Satellite hotspots within {radius_km:g} km, last {days} day(s): " + _trim(hs))
        fw = await call("weather.fwi", {"lat": lat, "lon": lon})
        if fw is not None:
            ctx.append("Fire weather today: " + _trim(fw, 1200))
    else:
        issues.append("no location in the question or context")
    docs = await call("rag.search", {"query": question, "k": k_docs})
    if docs and docs.get("hits"):
        ctx.append("Document passages: " + _trim([{k: h.get(k) for k in ("text", "source")} for h in docs["hits"]], 2000))
    answer = ""
    try:
        answer = await llm.chat("synthesizer", PLAIN_RAG_SYSTEM,
                                f"Question: {question}\n\nContext:\n" + ("\n\n".join(ctx) or "(nothing retrieved)"),
                                json_mode=False)
    except Exception as e:  # noqa: BLE001
        issues.append(f"LLM failed: {e.__class__.__name__}")
    return {"answer": answer, "intent": None, "cited_hazards": None, "derived_hazards": None, "grounded_rate": None,
            "tool_calls": len(calls), "llm_calls": len(log), "issues": issues,
            "latency_s": round(time.perf_counter() - t0, 2), **token_stats(log), "trace": {"calls": calls}}


def token_stats(log) -> dict:
    """Tokens per answer, split by role (slot) and by prompt / completion (#35)."""
    by_slot: dict[str, int] = {}
    calls_by_slot: dict[str, int] = {}
    for c in log:
        slot = c.slot if hasattr(c, "slot") else c.get("slot")
        pt = (c.prompt_tokens if hasattr(c, "prompt_tokens") else c.get("prompt_tokens")) or 0
        ct = (c.completion_tokens if hasattr(c, "completion_tokens") else c.get("completion_tokens")) or 0
        by_slot[slot] = by_slot.get(slot, 0) + pt + ct
        calls_by_slot[slot] = calls_by_slot.get(slot, 0) + 1
    g = lambda c, k: (getattr(c, k) if hasattr(c, k) else c.get(k)) or 0  # noqa: E731
    return {"tokens": sum(by_slot.values()), "prompt_tokens": sum(g(c, "prompt_tokens") for c in log),
            "completion_tokens": sum(g(c, "completion_tokens") for c in log),
            "tokens_by_slot": by_slot, "llm_calls_by_slot": calls_by_slot}


async def llm_only(question: str, llm: LLMClient, context: str = "") -> dict:
    log = start_call_log()
    t0 = time.perf_counter()
    issues = []
    try:
        answer = await llm.chat("synthesizer", LLM_ONLY_SYSTEM,
                                question + (f"\nContext: {context}" if context else ""), json_mode=False)
    except Exception as e:  # noqa: BLE001
        answer, issues = "", [f"LLM failed: {e.__class__.__name__}"]
    return {"answer": answer, "intent": None, "cited_hazards": None, "derived_hazards": None, "grounded_rate": None,
            "tool_calls": 0, "llm_calls": len(log), "issues": issues, "latency_s": round(time.perf_counter() - t0, 2),
            **token_stats(log), "trace": {}}
