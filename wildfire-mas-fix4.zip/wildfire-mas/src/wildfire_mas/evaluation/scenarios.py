"""Golden set Part B: synthetic live / geospatial scenarios with gold labels.

Each scenario is a small, self-contained world (sites, FIRMS hotspots with their 30-day history,
known static heat sources, FWI danger per site, image records) built so that one rule or filter
check is exercised, often close to its threshold. The gold labels are derived from the
*specification* (the thresholds in config/settings.yaml and the check order documented in
live/classify.py), never by calling the code under test, so the evaluation can find real bugs.

Families
  r09       site + 1-2 vegetation hotspots at 1-20 km (half near the 10 km edge)
  r10       two satellite passes; distance, time gap and FRP growth vary around 2 km / 24 h / 1.5x
  r11       site with a nearby (or not) fire and an FWI danger class (5-day series)
  r12       image record (fire score vs threshold) and a hotspot near / far, in / out of 3 h
  filter    site + 3-6 hotspots, each with one non-wildfire trait (type column, static source,
            persistence, low confidence) or none
  decoy     site with only non-wildfire heat nearby (gas flare / plant): no hazard expected

Questions (types L1-L12) are attached for the end-to-end evaluation:
  L1 presence · L2 nearest distance · L3 count within 10 km · L4 non-wildfire detections ·
  L5 spreading · L6 danger class today · L7 danger raised · L8 image-satellite conflict ·
  L9 hazards + actions · L10 no location given · L11 danger trend · L12 presence outside Sri Lanka
"""
from __future__ import annotations

import json
import math
import random
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ..live.geo import EARTH_KM, haversine_km

SL_SITES = [("Kandy", 7.2906, 80.6337), ("Badulla", 6.9934, 81.0550), ("Anuradhapura", 8.3114, 80.4037),
            ("Knuckles Range", 7.4500, 80.8000), ("Ella", 6.8667, 81.0466), ("Sigiriya", 7.9570, 80.7600),
            ("Hambantota", 6.1240, 81.1180), ("Nuwara Eliya", 6.9497, 80.7891), ("Monaragala", 6.8728, 81.3507),
            ("Polonnaruwa", 7.9403, 81.0188), ("Kurunegala", 7.4863, 80.3623), ("Ratnapura", 6.6828, 80.3992)]
GLOBAL_SITES = [("Canberra", -35.2809, 149.1300), ("Sacramento", 38.5816, -121.4944), ("Manaus", -3.1190, -60.0217),
                ("Kelowna", 49.8880, -119.4960), ("Athens", 37.9838, 23.7275), ("Kruger Park", -24.0110, 31.4850)]

DANGER = ["VeryLow", "Low", "Moderate", "High", "VeryHigh", "Extreme"]
FWI_MID = {"VeryLow": 2.5, "Low": 8.0, "Moderate": 16.0, "High": 29.0, "VeryHigh": 44.0, "Extreme": 62.0}
TYPE_GOLD = {1: "volcanic", 2: "static_land_source", 3: "offshore"}
EDGE = 0.06   # draws closer than this (relative to a threshold) are redrawn: no ties on the boundary


@dataclass
class Spec:
    """Thresholds the gold labels are computed from (defaults = config/settings.yaml)."""
    r09_km: float = 10.0
    r10_km: float = 2.0
    r10_h: float = 24.0
    r10_ratio: float = 1.5
    r11_min: str = "High"
    r12_km: float = 1.0
    r12_h: float = 3.0
    static_km: float = 1.0
    persist_days: int = 8
    modis_min_conf: float = 30.0

    @classmethod
    def from_settings(cls, s) -> "Spec":
        r, f = s.get("rules"), s.get("hotspot_filter")
        return cls(float(r["R09_near_km"]), float(r["R10_cluster_km"]), float(r["R10_cluster_hours"]),
                   float(r["R10_frp_growth_ratio"]), r["R11_min_danger"], float(r["R12_match_km"]),
                   float(r["R12_match_hours"]), float(f.get("static_match_km", 1.0)),
                   int(f.get("persistence_min_days", 8)), float(f.get("min_modis_confidence", 30)))


@dataclass
class SHotspot:
    id: str
    lat: float
    lon: float
    t: str                      # ISO UTC
    frp: float
    product: str = "VIIRS_NOAA20_NRT"
    instrument: str = "VIIRS"
    confidence: str = "n"
    fire_type: int | None = None
    history_days: list[str] = field(default_factory=list)   # earlier detections at this spot (ISO dates)
    gold_category: str = "likely_vegetation_fire"
    group: str | None = None    # R10: fire the hotspot belongs to
    note: str = ""


@dataclass
class Scenario:
    id: str
    family: str
    region: str
    sites: list[dict]
    hotspots: list[SHotspot]
    static_sources: list[dict] = field(default_factory=list)
    fwi: dict = field(default_factory=dict)         # site id -> [{date, fwi, danger}] oldest first
    images: list[dict] = field(default_factory=list)
    gold_hazards: list[dict] = field(default_factory=list)   # {rule, type, target}
    gold_events: int | None = None                  # R10: number of live fire events
    params: dict = field(default_factory=dict)      # generating parameters (edge analysis)
    near_edge: bool = False

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False)

    @staticmethod
    def from_dict(d: dict) -> "Scenario":
        d = dict(d)
        d["hotspots"] = [SHotspot(**h) for h in d["hotspots"]]
        return Scenario(**d)


def load_scenarios(path: str | Path) -> list[Scenario]:
    return [Scenario.from_dict(json.loads(x)) for x in Path(path).read_text().splitlines() if x.strip()]


# ------------------------------------------------------------------------------- geometry
def destination(lat: float, lon: float, bearing_deg: float, km: float) -> tuple[float, float]:
    """Point `km` away on a great circle (same sphere as haversine_km)."""
    d = km / EARTH_KM
    b, p1, l1 = math.radians(bearing_deg), math.radians(lat), math.radians(lon)
    p2 = math.asin(math.sin(p1) * math.cos(d) + math.cos(p1) * math.sin(d) * math.cos(b))
    l2 = l1 + math.atan2(math.sin(b) * math.sin(d) * math.cos(p1), math.cos(d) - math.sin(p1) * math.sin(p2))
    return round(math.degrees(p2), 6), round((math.degrees(l2) + 540) % 360 - 180, 6)


# ------------------------------------------------------------------------------- gold logic
def gold_category(h: SHotspot, static: list[dict], spec: Spec) -> str:
    """The documented check order: type column > static source > (land mask) > persistence > confidence."""
    if h.fire_type in TYPE_GOLD:
        return TYPE_GOLD[h.fire_type]
    near = [s for s in static if haversine_km(h.lat, h.lon, s["lat"], s["lon"]) <= spec.static_km]
    if near:
        return "volcanic" if min(near, key=lambda s: haversine_km(h.lat, h.lon, s["lat"], s["lon"]))["kind"] == "volcano" \
            else "static_land_source"
    if len(set(h.history_days) | {h.t[:10]}) >= spec.persist_days:
        return "persistent_static_source"
    if h.instrument == "MODIS":
        if float(h.confidence) < spec.modis_min_conf:
            return "low_confidence"
    elif h.confidence.lower() in {"l", "low"}:
        return "low_confidence"
    return "likely_vegetation_fire"


def _site_hazards(sc: Scenario, spec: Spec) -> None:
    """Gold R09 / R11 for every site from the gold-vegetation hotspots."""
    veg = [h for h in sc.hotspots if h.gold_category == "likely_vegetation_fire"]
    for s in sc.sites:
        dists = [haversine_km(s["lat"], s["lon"], h.lat, h.lon) for h in veg]
        if dists and min(dists) <= spec.r09_km:
            sc.gold_hazards.append({"rule": "R09", "type": "NearbyActiveFire", "target": s["id"]})
            series = sc.fwi.get(s["id"])
            if series and DANGER.index(series[-1]["danger"]) >= DANGER.index(spec.r11_min):
                sc.gold_hazards.append({"rule": "R11", "type": "ElevatedDangerNearActiveFire", "target": s["id"]})


# ------------------------------------------------------------------------------- generator
class Generator:
    def __init__(self, seed: int = 7, spec: Spec | None = None, global_share: float = 0.15):
        self.rng = random.Random(seed)
        self.spec = spec or Spec()
        self.global_share = global_share
        self.n = 0
        self.t0 = datetime(2026, 3, 15, 7, 45, tzinfo=timezone.utc)   # Sri Lankan dry season, VIIRS day pass

    # helpers
    def _id(self, fam: str) -> str:
        self.n += 1
        return f"B{self.n:04d}-{fam}"

    def _site(self, sid: str = "S1") -> tuple[dict, str]:
        r = self.rng
        glob = r.random() < self.global_share
        name, lat, lon = r.choice(GLOBAL_SITES if glob else SL_SITES)
        return {"id": sid, "label": name, "lat": lat, "lon": lon}, ("global" if glob else "sri_lanka")

    def _draw(self, lo: float, hi: float, edge: float | None = None, edge_share: float = 0.4,
              edge_width: float = 0.0, rel: bool = True) -> tuple[float, bool]:
        """Uniform draw; with probability edge_share near `edge`. Never within EDGE of it."""
        r = self.rng
        while True:
            near = edge is not None and r.random() < edge_share
            v = r.uniform(edge - edge_width, edge + edge_width) if near else r.uniform(lo, hi)
            if edge is None or abs(v - edge) > (EDGE * edge if rel else EDGE):
                return round(v, 3), near

    def _side(self, lo: float, edge: float, hi: float, below: bool, width: float) -> tuple[float, bool]:
        """Draw on one side of a threshold (below = in [lo, edge), else (edge, hi]); 40% close to the edge."""
        r = self.rng
        while True:
            near = r.random() < 0.4
            if below:
                v = r.uniform(max(lo, edge - width), edge) if near else r.uniform(lo, edge)
            else:
                v = r.uniform(edge, min(hi, edge + width)) if near else r.uniform(edge, hi)
            if abs(v - edge) > EDGE * edge:
                return round(v, 3), near

    def _conditions(self, n: int) -> list[bool]:
        """Half the scenarios satisfy every condition; the rest break exactly one, so each condition
        is tested on its own (balanced positives and informative negatives)."""
        ok = [True] * n
        if self.rng.random() >= 0.5:
            ok[self.rng.randrange(n)] = False
        return ok

    def _t(self, hours: float = 0.0) -> datetime:
        return self.t0 + timedelta(hours=hours)

    def _hs(self, sc_id: str, k: int, lat: float, lon: float, t: datetime, frp: float, **kw) -> SHotspot:
        return SHotspot(id=f"{sc_id}-h{k}", lat=lat, lon=lon, t=t.isoformat(), frp=round(frp, 1), **kw)

    def _fwi_series(self, last: str) -> list[dict]:
        """5 days ending in `last`, drifting towards it (gives L11 a trend)."""
        r = self.rng
        i = DANGER.index(last)
        start = max(0, min(5, i + r.choice([-2, -1, 0, 1, 2])))
        out = []
        for d in range(5):
            cls = DANGER[round(start + (i - start) * d / 4)]
            out.append({"date": (self.t0.date() - timedelta(days=4 - d)).isoformat(),
                        "fwi": round(FWI_MID[cls] + r.uniform(-1.5, 1.5), 1), "danger": cls})
        out[-1]["danger"] = last
        return out

    # families
    def r09(self) -> Scenario:
        r, sp = self.rng, self.spec
        sid = self._id("r09")
        site, region = self._site()
        n = r.choice([1, 1, 2])
        hs, ds, edge = [], [], False
        b0 = r.uniform(0, 360)
        for k in range(n):
            d, near = self._draw(1.5, 20.0, sp.r09_km, edge_share=0.5, edge_width=1.5)
            edge |= near
            # a second fire on the opposite side: never within R10's cluster distance of the first
            lat, lon = destination(site["lat"], site["lon"], b0 + 180 * k + r.uniform(-10, 10), d)
            hs.append(self._hs(sid, k + 1, lat, lon, self._t(-r.uniform(0, 6)), r.uniform(3, 60),
                               confidence=r.choice(["n", "h"])))
            ds.append(d)
        sc = Scenario(sid, "r09", region, [site], hs, fwi={"S1": self._fwi_series("Low")},
                      params={"distances_km": ds}, near_edge=edge)
        _site_hazards(sc, sp)
        return sc

    def r10(self) -> Scenario:
        r, sp = self.rng, self.spec
        sid = self._id("r10")
        site, region = self._site()
        while True:
            c_gap, c_off, c_ratio = self._conditions(3)
            gap_h, e1 = self._side(2.0, sp.r10_h, 40.0, c_gap, 4.0)
            off_km, e2 = self._side(0.4, sp.r10_km, 4.0, c_off, 0.5)
            ratio, e3 = self._side(0.5, sp.r10_ratio, 3.0, not c_ratio, 0.3)
            c_lat, c_lon = destination(site["lat"], site["lon"], r.uniform(0, 360), r.uniform(3.0, 7.0))
            bearing = r.uniform(0, 360)
            c2 = destination(c_lat, c_lon, bearing, off_km)
            n1, n2 = r.randint(1, 3), r.randint(1, 3)
            t1, t2 = self._t(-gap_h - 1), self._t(-1)
            p1 = [destination(c_lat, c_lon, r.uniform(0, 360), r.uniform(0, 0.15)) for _ in range(n1)]
            p2 = [destination(*c2, r.uniform(0, 360), r.uniform(0, 0.15)) for _ in range(n2)]
            min_d = min(haversine_km(a[0], a[1], b[0], b[1]) for a in p1 for b in p2)
            if abs(min_d - sp.r10_km) > EDGE * sp.r10_km:
                break
        frp1 = [r.uniform(5, 40) for _ in range(n1)]
        total2 = sum(frp1) * ratio
        w = [r.uniform(0.5, 1.5) for _ in range(n2)]
        frp2 = [total2 * x / sum(w) for x in w]
        hs = [self._hs(sid, k + 1, *p, t1, f, group="F1") for k, (p, f) in enumerate(zip(p1, frp1))]
        hs += [self._hs(sid, n1 + k + 1, *p, t2, f, group="F1") for k, (p, f) in enumerate(zip(p2, frp2))]
        linked = min_d <= sp.r10_km and gap_h <= sp.r10_h
        # the same physical fire only if the passes link; otherwise each pass is its own event
        if not linked:
            for h in hs[n1:]:
                h.group = "F2"
        sc = Scenario(sid, "r10", region, [site], hs, fwi={"S1": self._fwi_series("Moderate")},
                      gold_events=1 if linked else 2,
                      params={"gap_h": gap_h, "min_pass_distance_km": round(min_d, 3), "frp_ratio": ratio,
                              "linked": linked},
                      near_edge=e1 or e2 or e3)
        if linked and ratio >= sp.r10_ratio:
            sc.gold_hazards.append({"rule": "R10", "type": "SpreadingFire", "target": "F1"})
        _site_hazards(sc, sp)
        return sc

    def r11(self) -> Scenario:
        r, sp = self.rng, self.spec
        sid = self._id("r11")
        site, region = self._site()
        has_fire = r.random() < 0.7
        d, edge = (self._draw(1.0, 9.0) if has_fire else self._draw(12.0, 25.0))
        lat, lon = destination(site["lat"], site["lon"], r.uniform(0, 360), d)
        last = r.choice(DANGER[1:] + ["Moderate", "High", "High"])  # weight the Moderate/High edge
        hs = [self._hs(sid, 1, lat, lon, self._t(-r.uniform(0, 6)), r.uniform(3, 60), confidence="h")]
        sc = Scenario(sid, "r11", region, [site], hs, fwi={"S1": self._fwi_series(last)},
                      params={"distance_km": d, "danger": last}, near_edge=last in (DANGER[DANGER.index(sp.r11_min) - 1], sp.r11_min))
        _site_hazards(sc, sp)
        return sc

    def r12(self) -> Scenario:
        r, sp = self.rng, self.spec
        sid = self._id("r12")
        site, region = self._site()
        ilat, ilon = destination(site["lat"], site["lon"], r.uniform(0, 360), r.uniform(15, 30))  # no R09 noise
        th = round(r.uniform(0.4, 0.6), 2)
        has_t = r.random() < 0.75
        c_score, c_dist, c_time = self._conditions(3 if has_t else 2) + ([True] if not has_t else [])
        score = round(r.uniform(0.05, th - 0.03) if c_score else r.uniform(th + 0.03, 0.98), 2)
        d, e1 = self._side(0.1, sp.r12_km, 3.0, c_dist, 0.3)
        dt_h, e2 = self._side(0.0, sp.r12_h, 8.0, c_time, 1.0) if has_t else (None, False)
        sign = r.choice([-1, 1])
        hlat, hlon = destination(ilat, ilon, r.uniform(0, 360), d)
        cap = self._t(-2)
        ht = cap + timedelta(hours=sign * dt_h) if has_t else self._t(-r.uniform(0, 30))
        rec = f"{sid}-img"
        hs = [self._hs(sid, 1, hlat, hlon, ht, r.uniform(3, 40), confidence="n")]
        img = {"rec": rec, "lat": ilat, "lon": ilon, "t": cap.isoformat() if has_t else None,
               "score": score, "threshold": th, "event": f"{sid}-event"}
        sc = Scenario(sid, "r12", region, [site], hs, images=[img],
                      params={"distance_km": d, "dt_h": dt_h, "score": score, "threshold": th},
                      near_edge=e1 or e2)
        if score < th and d <= sp.r12_km and (not has_t or dt_h <= sp.r12_h):
            sc.gold_hazards.append({"rule": "R12", "type": "SatelliteSceneConflict", "target": rec})
        _site_hazards(sc, sp)
        return sc

    def _trait_hotspot(self, sid: str, k: int, lat: float, lon: float, trait: str, static: list[dict]) -> tuple[SHotspot, bool]:
        r, sp = self.rng, self.spec
        t = self._t(-r.uniform(0, 6))
        edge = False
        modis = r.random() < 0.3
        kw = {"instrument": "MODIS", "product": "MODIS_NRT", "confidence": str(r.randint(35, 100))} if modis \
            else {"confidence": r.choice(["n", "h"])}
        h = self._hs(sid, k, lat, lon, t, r.uniform(2, 80), **kw)
        if trait == "type":
            h.product = "MODIS_SP" if modis else "VIIRS_SNPP_SP"
            h.fire_type = r.choice([0, 1, 2, 3])
        elif trait == "static":
            d, edge = self._draw(0.1, 2.5, sp.static_km, edge_width=0.3)
            slat, slon = destination(lat, lon, r.uniform(0, 360), d)
            kind = r.choice(["flare", "industrial", "power", "volcano"])
            static.append({"name": f"{sid}-src{k}", "lat": slat, "lon": slon, "kind": kind})
            h.note = f"static source {d} km"
        elif trait == "persistent":
            n_total = r.randint(3, 14)
            edge = abs(n_total - sp.persist_days) <= 1
            days = r.sample(range(1, 30), n_total - 1)
            h.history_days = sorted((self.t0.date() - timedelta(days=x)).isoformat() for x in days)
            h.note = f"seen on {n_total} days"
        elif trait == "lowconf":
            if modis:
                c, edge = self._draw(0, 60, sp.modis_min_conf, edge_width=6, rel=False)
                h.confidence = str(int(round(c)))
            else:
                h.confidence = r.choice(["l", "l", "n", "h"])
        return h, edge

    def filter(self) -> Scenario:
        r = self.rng
        sid = self._id("filter")
        site, region = self._site()
        static: list[dict] = []
        hs, edge = [], False
        n = r.randint(3, 6)
        bearings = sorted(r.sample(range(0, 360, 30), n))      # >= 30 deg apart at >= 6 km: no cross-talk
        for k, b in enumerate(bearings, 1):
            lat, lon = destination(site["lat"], site["lon"], b, r.uniform(6.0, 9.0))
            trait = r.choice(["none", "type", "static", "persistent", "lowconf", "lowconf", "persistent"])
            h, e = self._trait_hotspot(sid, k, lat, lon, trait, static)
            if trait == "persistent" and r.random() < 0.25:    # combined traits: order decides
                h.confidence = "l" if h.instrument == "VIIRS" else "10"
            hs.append(h)
            edge |= e
        for h in hs:
            h.gold_category = gold_category(h, static, self.spec)
        sc = Scenario(sid, "filter", region, [site], hs, static_sources=static,
                      fwi={"S1": self._fwi_series(r.choice(["Moderate", "High", "VeryHigh"]))}, near_edge=edge)
        _site_hazards(sc, self.spec)
        return sc

    def decoy(self) -> Scenario:
        r = self.rng
        sid = self._id("decoy")
        site, region = self._site()
        static: list[dict] = []
        hs = []
        for k, trait in enumerate(r.sample(["static", "persistent", "type"], r.randint(1, 3)), 1):
            lat, lon = destination(site["lat"], site["lon"], k * 110 + r.uniform(0, 40), r.uniform(2.0, 8.0))
            h, _ = self._trait_hotspot(sid, k, lat, lon, trait, static)
            if trait == "static":                 # decoys are always inside the match radius
                static[-1].update(dict(zip(("lat", "lon"), destination(lat, lon, r.uniform(0, 360), r.uniform(0.1, 0.6)))))
            if trait == "persistent":
                days = r.sample(range(1, 30), r.randint(9, 20))
                h.history_days = sorted((self.t0.date() - timedelta(days=x)).isoformat() for x in days)
            if trait == "type":
                h.fire_type = r.choice([1, 2, 3])
            h.gold_category = gold_category(h, static, self.spec)
            hs.append(h)
        sc = Scenario(sid, "decoy", region, [site], hs, static_sources=static,
                      fwi={"S1": self._fwi_series(r.choice(["High", "VeryHigh", "Extreme"]))})
        _site_hazards(sc, self.spec)
        return sc

    def generate(self, per_family: int = 40) -> list[Scenario]:
        out = []
        for fam in ("r09", "r10", "r11", "r12", "filter", "decoy"):
            n = per_family if fam != "decoy" else max(1, per_family // 2)
            out += [getattr(self, fam)() for _ in range(n)]
        return out


# ------------------------------------------------------------------------------- questions
def questions_for(sc: Scenario, spec: Spec | None = None) -> list[dict]:
    """End-to-end questions with gold intent, gold hazards and gold facts (types L1-L12)."""
    spec = spec or Spec()
    s = sc.sites[0]
    place = s["label"]
    veg = [h for h in sc.hotspots if h.gold_category == "likely_vegetation_fire"]
    dists = sorted(haversine_km(s["lat"], s["lon"], h.lat, h.lon) for h in veg)
    near = [d for d in dists if d <= spec.r09_km]
    haz = sorted({h["type"] for h in sc.gold_hazards})
    base = {"scenario": sc.id, "family": sc.family, "region": sc.region, "place": place,
            "lat": s["lat"], "lon": s["lon"], "part": "B", "gold_hazards": haz}
    q: list[dict] = []

    def add(qtype, text, intent, **facts):
        q.append({**base, "qtype": qtype, "question": text, "gold_intent": intent, "gold_facts": facts})

    presence = "L12" if sc.region == "global" else "L1"
    add(presence, f"Are there any active wildfires near {place} right now?", "situational_awareness",
        fire_nearby=bool(near))
    if near:
        add("L2", f"How far is the nearest wildfire from {place}?", "situational_awareness",
            nearest_km=round(near[0], 1))
        add("L3", f"How many likely wildfire detections are within {spec.r09_km:g} km of {place}?",
            "situational_awareness", count=len(near))
    others = [h.gold_category for h in sc.hotspots if h.gold_category != "likely_vegetation_fire"]
    if sc.family in ("filter", "decoy"):
        add("L4", f"Are any of the heat detections near {place} not wildfires?", "situational_awareness",
            non_wildfire=len(others) > 0, categories=sorted(set(others)))
    if sc.family == "r10":
        add("L5", f"Is the fire near {place} spreading?", "trend",
            spreading=any(h["rule"] == "R10" for h in sc.gold_hazards))
    series = sc.fwi.get(s["id"])
    if series:
        add("L6", f"What is the fire danger level at {place} today?", "situational_awareness",
            danger=series[-1]["danger"])
        first, last = DANGER.index(series[0]["danger"]), DANGER.index(series[-1]["danger"])
        if sc.family == "r11":
            add("L7", f"Has the fire danger near {place} been raised because of a nearby fire?", "hazard_advice",
                raised=any(h["rule"] == "R11" for h in sc.gold_hazards))
            add("L11", f"Is the fire danger at {place} rising over the last five days?", "trend",
                direction="up" if last > first else "down" if last < first else "flat")
    for img in sc.images:
        q.append({**base, "qtype": "L8", "record": img["rec"], "place": None, "lat": None, "lon": None,
                  "question": "Does the satellite data contradict what this image shows?",
                  "gold_intent": "hazard_advice",
                  "gold_facts": {"conflict": any(h["rule"] == "R12" for h in sc.gold_hazards)}})
    if haz or sc.family in ("filter", "decoy"):
        add("L9", f"What hazards should crews at {place} expect, and what should they do?", "hazard_advice")
    return q


def no_location_questions() -> list[dict]:
    texts = ["Are there any fires nearby?", "Is it safe to send a crew out there now?",
             "How dangerous is the fire weather at the moment?", "Is the fire getting closer?"]
    intents = ["situational_awareness", "hazard_advice", "situational_awareness", "trend"]
    return [{"scenario": None, "family": "none", "region": None, "part": "B", "qtype": "L10", "question": t,
             "gold_intent": i, "gold_hazards": [], "place": None, "lat": None, "lon": None,
             "gold_facts": {"expects": "ask for or report the missing location"}} for t, i in zip(texts, intents)]


def write_partb(scenarios: list[Scenario], out_dir: Path, spec: Spec | None = None, dev: float = 0.3,
                seed: int = 42) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    rnd = random.Random(seed)
    split = {sc.id: ("dev" if rnd.random() < dev else "test") for sc in scenarios}
    sc_path = out_dir / "golden_partB_scenarios.jsonl"
    q_path = out_dir / "golden_partB.jsonl"
    sc_path.write_text("".join(sc.to_json() + "\n" for sc in scenarios))
    qs = [x for sc in scenarios for x in questions_for(sc, spec)] + no_location_questions()
    for i, x in enumerate(qs, 1):
        x["id"] = f"B-Q{i:04d}"
        x["split"] = split.get(x["scenario"], "test")
    q_path.write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in qs))
    by_q: dict[str, int] = {}
    for x in qs:
        by_q[x["qtype"]] = by_q.get(x["qtype"], 0) + 1
    return {"scenarios": len(scenarios), "questions": len(qs), "by_type": dict(sorted(by_q.items())),
            "hotspots": sum(len(s.hotspots) for s in scenarios),
            "gold_hazards": sum(len(s.gold_hazards) for s in scenarios),
            "files": [str(sc_path), str(q_path)]}
