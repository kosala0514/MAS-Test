"""End-to-end evaluation: the whole system vs baselines and ablations, with error attribution.

    wfmas e2e --part B --systems mas,single_agent,llm_only --limit 200
    wfmas e2e --part B --systems mas,mas-no_iors,mas-no_verifier,mas-no_crm,mas-no_ialt,mas-no_filter,mas-no_rules
    wfmas e2e --part A --systems mas,ffonto,single_agent,llm_only --limit 150      # needs GraphDB + ffonto-v2

Part B (live / geospatial) runs every system inside a scenario world (world.py): the real planner, agents,
rules and synthesizer, with FIRMS, weather and the graph replaced by the scenario. Part A (offline KG)
runs against your GraphDB and reuses ffonto-v2's evaluation (record matching, gold rows, answer metrics,
judge) so the original pipeline (B0) and the multi-agent system are scored identically.

Scores per answer
  judge         LLM judge vs a reference built from the gold facts: correct / partial / wrong / no_answer
  rule_check    deterministic check of the key fact (distance within tolerance, danger class named, yes/no
                polarity, trend direction, hazard keywords) - no LLM involved
  hazard_recall share of gold hazards the answer mentions (keywords; same for every system)
  cited_hazard_recall  multi-agent system only: gold hazards that are cited rule evidence
  grounded_rate multi-agent system only: share of claims with a valid citation
Validate the judge: fill human_grade in human_check.csv, then `wfmas e2e-agreement` (Cohen's kappa).
"""
from __future__ import annotations

import asyncio
import copy
import csv
import json
import random
import re
import statistics
import time
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from ..agents.state import Request
from ..agents.synthesis import GAP_TITLES
from ..config import Settings
from ..llm import LLMClient
from .metrics import bootstrap_ci, cohen_kappa, mcnemar
from .scenarios import DANGER, Scenario, load_scenarios

ABLATIONS = {"no_iors": "iors", "no_verifier": "verifier", "no_crm": "crm", "no_ialt": "ialt",
             "no_filter": "hotspot_filter", "no_rules": "rules"}
GRADE = {"correct": 1.0, "partial": 0.5, "wrong": 0.0, "no_answer": 0.0}

JUDGE_SYSTEM = """You grade the answer of a wildfire screening system against the reference facts.
Return JSON {"grade": "correct" | "partial" | "wrong" | "no_answer", "why": "<short reason>"}.
correct   = states the key fact of the reference (wording, extra context and safety advice are fine);
partial   = some key facts right, some missing or vague;
wrong     = contradicts the reference (e.g. says there is a fire when there is none, wrong number or class);
no_answer = says it has no information or cannot answer.
Judge only the facts in the reference. Do not reward length."""


# ------------------------------------------------------------------------------ settings per system
def settings_for(settings: Settings, system: str) -> Settings:
    if not system.startswith("mas-"):
        return settings
    key = ABLATIONS[system.split("-", 1)[1]]
    raw = copy.deepcopy(settings.raw)
    raw.setdefault("ablation", {})[key] = False
    return Settings(raw, settings.models, settings.root)


# ------------------------------------------------------------------------------ references + checks
def reference(item: dict) -> str:
    f, place, q = item.get("gold_facts", {}), item.get("place") or "the location", item["qtype"]
    if q in ("L1", "L12"):
        return (f"Yes: at least one likely wildfire is within 10 km of {place}." if f["fire_nearby"]
                else f"No likely wildfire is detected within 10 km of {place}.")
    if q == "L2":
        return f"The nearest likely wildfire is about {f['nearest_km']} km from {place}."
    if q == "L3":
        return f"{f['count']} likely wildfire detection(s) within 10 km of {place}."
    if q == "L4":
        return (f"Yes: some detections are not wildfires ({', '.join(c.replace('_', ' ') for c in f['categories'])})."
                if f["non_wildfire"] else "No: all detections are likely vegetation fires.")
    if q == "L5":
        return "Yes, the fire is spreading (its radiative power grew between satellite passes)." if f["spreading"] \
            else "No: there is no evidence that the fire is spreading."
    if q == "L6":
        return f"The fire danger class today is {_danger_words(f['danger'])}."
    if q == "L7":
        return ("Yes: the danger is raised because an active fire is nearby while fire weather is high." if f["raised"]
                else "No: the danger level is not raised by a nearby fire.")
    if q == "L8":
        return ("Yes: a satellite hotspot near the image contradicts the image's below-threshold fire score."
                if f["conflict"] else "No: the satellite data does not contradict the image.")
    if q == "L9":
        h = item.get("gold_hazards") or []
        return ("Hazards: " + ", ".join(_hazard_words(x) for x in h) + ", with matching actions.") if h \
            else "No rule-based fire hazard applies at this location."
    if q == "L10":
        return "The question gives no location: the system should ask for one or report it as missing."
    if q == "L11":
        return {"up": "Fire danger has been rising.", "down": "Fire danger has been falling.",
                "flat": "Fire danger has stayed about the same."}[f["direction"]]
    return ""


def _danger_words(c: str) -> str:
    return re.sub(r"(?<!^)(?=[A-Z])", " ", c).lower()


def _hazard_words(t: str) -> str:
    return {"NearbyActiveFire": "an active fire nearby", "SpreadingFire": "a spreading fire",
            "ElevatedDangerNearActiveFire": "danger raised by a nearby fire",
            "SatelliteSceneConflict": "satellite data conflicting with the image"}.get(t, t)


HAZARD_PAT = {"NearbyActiveFire": r"(active|nearby|likely)\s+(wild)?fire|fire[^.]{0,40}(within|km)|hotspot",
              "SpreadingFire": r"spread|grow|expand|intensif",
              "ElevatedDangerNearActiveFire": r"(danger|risk)[^.]{0,50}(rais|elevat|increas|escalat|upgrad)|"
                                              r"(rais|elevat|increas|escalat|upgrad)[^.]{0,50}(danger|risk)",
              "SatelliteSceneConflict": r"conflict|contradict|disagree|inconsisten|mismatch"}
POS = {"L1": r"(wild)?fires?\b|hotspots?|burning", "L12": r"(wild)?fires?\b|hotspots?|burning",
       "L5": HAZARD_PAT["SpreadingFire"], "L7": HAZARD_PAT["ElevatedDangerNearActiveFire"],
       "L8": HAZARD_PAT["SatelliteSceneConflict"]}
NEG = re.compile(r"\b(no|not|none|zero|nothing|neither|nor|without|absent)\b|n't\b|\b0\s+(likely|active|wild)", re.I)
NON_WILDFIRE = r"not (a |likely )?(wild|vegetation )?fire|static|industrial|flare|persistent|volcan|offshore|" \
               r"low[- ]confidence|non-wildfire|heat source"
WORDNUM = {"one": 1, "a": 1, "single": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
           "eight": 8, "nine": 9, "ten": 10}


def _sentences(text: str) -> list[str]:
    return [s for s in re.split(r"(?<=[.!?])\s+|\n+", text or "") if s.strip()]


def polarity(text: str, pos: str) -> bool | None:
    """True if the answer asserts the positive, False if it denies it, None if absent or both."""
    yes = no = False
    for s in _sentences(text):
        if re.search(pos, s, re.I):
            if NEG.search(s):
                no = True
            else:
                yes = True
    if yes and not no:
        return True
    if no and not yes:
        return False
    return None


def rule_check(item: dict, text: str) -> bool | None:
    q, f = item["qtype"], item.get("gold_facts", {})
    t = text or ""
    if q in ("L1", "L12"):
        p = polarity(t, POS[q])
        return None if p is None else p == f["fire_nearby"]
    if q in ("L5", "L7", "L8"):
        key = {"L5": "spreading", "L7": "raised", "L8": "conflict"}[q]
        p = polarity(t, POS[q])
        if p is None and not f[key]:
            return True                      # never claimed it: consistent with "no"
        return None if p is None else p == f[key]
    if q == "L2":
        kms = [float(x) for x in re.findall(r"(\d+(?:\.\d+)?)\s*km", t)]
        tol = max(0.6, 0.1 * f["nearest_km"])
        return any(abs(k - f["nearest_km"]) <= tol for k in kms)
    if q == "L3":
        nums = {int(x) for x in re.findall(r"\b(\d+)\b", t)}
        nums |= {v for w, v in WORDNUM.items() if re.search(rf"\b{w}\b (likely|active|wild|fire|hotspot|detection)", t, re.I)}
        return f["count"] in nums
    if q == "L4":
        return bool(re.search(NON_WILDFIRE, t, re.I)) == f["non_wildfire"]
    if q == "L6":
        words = _danger_words(f["danger"])
        pat = rf"(?<!very )\b{words}\b" if words in ("high", "low") else rf"\b{words}\b"
        return bool(re.search(pat, t, re.I))
    if q == "L9":
        h = item.get("gold_hazards") or []
        return None if not h else all(re.search(HAZARD_PAT[x], t, re.I) for x in h)
    if q == "L10":
        return bool(re.search(r"location|where|which (place|area|site)|coordinates|specify|provide", t, re.I))
    if q == "L11":
        pats = {"up": r"\b(ris|increas|upward|worsen|higher|climb)", "down": r"\b(fall|decreas|declin|drop|lower|eas|improv)",
                "flat": r"\b(stable|steady|unchanged|flat|same|constant)"}
        hit = {k for k, p in pats.items() if re.search(p, t, re.I)}
        return f["direction"] in hit and len(hit) == 1
    return None


def hazard_recall_text(item: dict, text: str) -> float | None:
    h = item.get("gold_hazards") or []
    return None if not h else sum(bool(re.search(HAZARD_PAT[x], text or "", re.I)) for x in h) / len(h)


async def judge(llm: LLMClient, item: dict, answer: str) -> tuple[str, str]:
    try:
        out = await llm.chat_json("judge", JUDGE_SYSTEM,
                                  f"Question: {item['question']}\nReference facts: {reference(item)}\nSystem answer: {answer}")
        g = str(out.get("grade", "")).lower()
        return (g if g in GRADE else "error"), str(out.get("why", ""))[:200]
    except Exception as e:  # noqa: BLE001
        return "error", f"{e.__class__.__name__}"


# ------------------------------------------------------------------------------ running the MAS
def _strip_cites(md: str) -> str:
    return re.sub(r"\s*\[[A-Z]+\d*(?:-\d+)?(?:,\s*[A-Z]+\d*(?:-\d+)?)*\]", "", md or "")


async def run_mas(settings: Settings, tk, llm: LLMClient, req: Request) -> dict:
    from ..orchestrator import build

    orch = build(settings, llm=llm, toolkit=tk)
    t0 = time.perf_counter()
    res = await orch.ask(req)
    rule_type = {e["id"]: (e.get("data") or {}).get("type") for e in res.evidence
                 if e["kind"] == "rule" and isinstance(e.get("data"), dict)}
    ids = {e["id"] for e in res.evidence}
    claims = [x for s in res.sections if s["title"] not in GAP_TITLES for x in s["sentences"]]
    cited = {c for x in claims for c in x.get("cites", [])}
    grounded = [x for x in claims if x.get("cites") and all(c in ids for c in x["cites"])]
    live = [e.get("data") for e in res.evidence if e["kind"] == "live" and isinstance(e.get("data"), dict)
            and "likely_wildfire" in e["data"]]
    return {"answer": _strip_cites(res.answer_markdown), "intent": res.intent,
            "cited_hazards": sorted({rule_type[c] for c in cited if rule_type.get(c)}),
            "derived_hazards": sorted({t for t in rule_type.values() if t}),
            "grounded_rate": (len(grounded) / len(claims)) if claims else None,
            "tool_calls": len(res.tool_calls), "llm_calls": len(res.llm_calls), "issues": res.issues[:8],
            "latency_s": round(time.perf_counter() - t0, 2),
            "tokens": sum((c.get("prompt_tokens") or 0) + (c.get("completion_tokens") or 0) for c in res.llm_calls),
            "trace": {"steps": res.steps, "plan_steps": [(s.get("agent"), (s.get("params") or {}).get("cq"))
                                                         for s in (res.plan or {}).get("steps", [])],
                      "live": [{k: x.get(k) for k in ("total", "likely_wildfire", "by_category", "_radius_km")} for x in live]}}


NEEDS = {"L1": {"live_data"}, "L2": {"live_data"}, "L3": {"live_data"}, "L4": {"live_data"},
         "L5": {"live_data", "risk"}, "L6": {"live_data"}, "L7": {"live_data", "risk"}, "L8": {"risk"},
         "L9": {"live_data", "risk"}, "L11": {"live_data"}, "L12": {"live_data"}}


def attribute(item: dict, out: dict) -> str:
    """First agent whose output was wrong (multi-agent system only). A different intent counts as a planner
    error only if the resulting plan lacks an agent the question needs."""
    planned = {a for a, _ in out["trace"].get("plan_steps", [])}
    if NEEDS.get(item["qtype"], set()) - planned:
        return "planner (plan misses " + ", ".join(sorted(NEEDS[item["qtype"]] - planned)) + ")"
    steps = out["trace"].get("steps", [])
    if any(s.get("agent") == "resolve" and not s.get("ok") for s in steps):
        return "resolve"
    gold = set(item.get("gold_hazards") or [])
    derived = set(out.get("derived_hazards") or [])
    live = out["trace"].get("live") or []
    if any(s.get("agent") == "live_data" and not s.get("ok") for s in steps):
        return "live_data (step failed)"
    if gold - derived:
        if "NearbyActiveFire" in gold - derived and live and not any(x.get("likely_wildfire") for x in live):
            return "live_data/filter"
        return "rules"
    if derived - gold:
        return "rules/filter (false alarm)"
    if gold - set(out.get("cited_hazards") or []):
        return "synthesizer (hazard not cited)"
    return "synthesizer"


# ------------------------------------------------------------------------------ Part B
def _request(item: dict, settings: Settings) -> Request:
    from .world import image_record_iri

    return Request(item["question"], record=image_record_iri(settings, item["record"]) if item.get("record") else None,
                   lat=item.get("lat"), lon=item.get("lon"), place=item.get("place"),
                   role=item.get("role", "analyst"))


async def run_partb(settings: Settings, systems: list[str], items: list[dict], scenarios: dict[str, Scenario],
                    llm: LLMClient, use_judge: bool = True, world=None, log=print, store_kind: str = "graphdb",
                    repository: str = "ffonto-eval") -> list[dict]:
    from ..tools.bus import InProcessBus
    from .baselines import llm_only, single_agent
    from .world import ScenarioWorld, time_shift

    world = world or ScenarioWorld(settings, kind=store_kind, repository=repository)
    shift = time_shift()
    by_sc: dict[str | None, list[dict]] = defaultdict(list)
    for it in items:
        by_sc[it.get("scenario")].append(it)
    empty = Scenario("none", "none", "sri_lanka", [], [])
    rows = []
    for system in systems:
        s_set = settings_for(settings, system)
        n = 0
        for sc_id, qs in by_sc.items():
            sc = scenarios.get(sc_id) if sc_id else empty
            for it in qs:
                tk = world.enter(sc, llm=llm, shift=shift, settings=s_set)   # fresh world per question
                req = _request(it, settings)
                try:
                    if system == "single_agent":
                        ctx = f"location {it['place']} ({it['lat']}, {it['lon']})" if it.get("lat") is not None else ""
                        if it.get("record"):
                            ctx = f"selected image record {req.record}"
                        out = await single_agent(it["question"], InProcessBus(tk), llm, tk.catalog.menu(), ctx)
                    elif system == "llm_only":
                        out = await llm_only(it["question"], llm)
                    else:
                        out = await run_mas(s_set, tk, llm, req)
                    err = None
                except Exception as e:  # noqa: BLE001
                    out, err = {"answer": "", "issues": [], "trace": {}}, f"{e.__class__.__name__}: {e}"[:300]
                row = {"id": it["id"], "system": system, "qtype": it["qtype"], "family": it.get("family"),
                       "region": it.get("region"), "question": it["question"], "reference": reference(it),
                       "gold_intent": it.get("gold_intent"), "gold_hazards": it.get("gold_hazards"), "error": err,
                       **{k: v for k, v in out.items() if k != "trace"}}
                row["rule_check"] = rule_check(it, out.get("answer", ""))
                row["hazard_recall"] = hazard_recall_text(it, out.get("answer", ""))
                gh = set(it.get("gold_hazards") or [])
                row["cited_hazard_recall"] = (len(gh & set(out.get("cited_hazards") or [])) / len(gh)) \
                    if gh and out.get("cited_hazards") is not None else None
                row["intent_correct"] = (out.get("intent") == it.get("gold_intent")) if out.get("intent") else None
                if use_judge:
                    row["judge_grade"], row["judge_why"] = (await judge(llm, it, out["answer"])) if out.get("answer") \
                        else ("no_answer", "empty answer")
                row["correct"] = (row.get("judge_grade") == "correct") if use_judge else bool(row["rule_check"])
                if system.startswith("mas") and not row["correct"] and out.get("trace"):
                    row["attribution"] = attribute(it, out)
                row["trace"] = out.get("trace")
                rows.append(row)
                n += 1
                if n % 25 == 0:
                    log(f"  {system}: {n}/{len(items)}")
    return rows


# ------------------------------------------------------------------------------ Part A (via ffonto-v2)
async def run_parta(settings: Settings, systems: list[str], items: list[dict], llm: LLMClient,
                    use_judge: bool = True, include_rag: bool = False, limit: int | None = None,
                    log=print) -> list[dict]:
    from ..kg.ffonto_bridge import FfontoBridge
    from ..tools.toolkit import Toolkit
    from ..tools.bus import InProcessBus
    from .baselines import llm_only, single_agent

    br = FfontoBridge(settings)
    if not (br.configured and br.available()):
        raise RuntimeError("Part A needs FFONTO_V2_PATH and GraphDB with your ffonto-v2 data")
    qa = br.qa
    import importlib

    ev = importlib.import_module("qa.evaluate")
    lookup, dates = ev._record_lookup(), ev._weather_dates()
    chosen = []
    for it in items:
        e = {"question": it["question"], "answer": it.get("gold_answer", ""), "route": it.get("gold_route"),
             "cq": it.get("gold_cq") or "", "source": it.get("source"), "modality": it.get("modality")}
        rec, day = ev.match_context(e, lookup, dates)
        if (e["route"] == "kg" and (rec or day)) or (e["route"] == "rag" and include_rag):
            chosen.append((it, e, rec, day))
    if not chosen:
        raise RuntimeError("no Part A question has its record or weather day in GraphDB (see ffonto-v2 coverage)")
    log(f"Part A: {len(chosen)} questions with data in GraphDB" + (f"; using {limit}" if limit else ""))
    if limit:
        random.Random(3).shuffle(chosen)
        chosen = chosen[:limit]
    tk = Toolkit(settings, llm=llm)
    rows = []
    for system in systems:
        s_set = settings_for(settings, system)
        for i, (it, e, rec, day) in enumerate(chosen, 1):
            q = e["question"] + (f" (weather record of {day})" if day and not rec else "")
            t0 = time.perf_counter()
            try:
                if system == "ffonto":
                    res = qa.pipeline.answer(e["question"], record=rec["iri"] if rec else None,
                                             record_desc=rec["label"] if rec else (f"weather record of {day}" if day else None),
                                             exclude_self=True, default_date=day)
                    extra = {}
                else:
                    if system == "single_agent":
                        out = await single_agent(q, InProcessBus(tk), llm, tk.catalog.menu(),
                                                 f"selected record {rec['iri']}" if rec else "")
                    elif system == "llm_only":
                        out = await llm_only(q, llm)
                    else:
                        out = await run_mas(s_set, tk, llm, Request(q, record=rec["iri"] if rec else None))
                    kg_rows = []
                    res = {"answer": out["answer"], "route": ("rag" if out.get("intent") == "explanation" else "kg")
                           if out.get("intent") else None,
                           "cq": next((c for a, c in (out.get("trace") or {}).get("plan_steps", []) if a == "kg" and c), None),
                           "mode": "cq", "rows": kg_rows, "sources": [], "error": "; ".join(out.get("issues", []))[:200] or None,
                           "seconds": out.get("latency_s")}
                    extra = {k: out.get(k) for k in ("grounded_rate", "tool_calls", "llm_calls", "tokens")}
                gold_rows = None
                if e["route"] == "kg" and e["cq"] in qa.cqs.REGISTRY:
                    try:
                        gold_rows = qa.cqs.run_cq(e["cq"], record=rec["iri"] if rec else None, date=day)["rows"]
                    except Exception:  # noqa: BLE001
                        gold_rows = None
                row = ev.score_answer(e, res, gold_rows, use_judge, False)
                row.update(system=system, id=it["id"], seconds=round(time.perf_counter() - t0, 2), **extra)
                row["correct"] = (row.get("judge_grade") == "correct") if use_judge else bool(row.get("yes_no"))
            except Exception as ex:  # noqa: BLE001
                row = {"system": system, "id": it["id"], "question": e["question"], "error": f"{ex.__class__.__name__}: {ex}"[:300],
                       "correct": False}
            rows.append(row)
            if i % 25 == 0:
                log(f"  {system}: {i}/{len(chosen)}")
    return rows


# ------------------------------------------------------------------------------ summary
def _ci(vals) -> str:
    v = [float(x) for x in vals if x is not None]
    if not v:
        return "-"
    m, lo, hi = bootstrap_ci(v)
    return f"{m:.3f} [{lo:.3f}-{hi:.3f}]"


def summarize(rows: list[dict], systems: list[str], part: str, use_judge: bool) -> tuple[str, dict]:
    by = defaultdict(list)
    for r in rows:
        by[r["system"]].append(r)
    metrics = (["correct", "rule_check", "hazard_recall", "cited_hazard_recall", "grounded_rate", "intent_correct"]
               if part == "B" else ["correct", "judge_score", "faith_score", "token_F1", "yes_no", "route_ok", "cq_ok",
                                    "grounded_rate"])
    lines = [f"# End-to-end evaluation, Part {part}", "",
             f"{len({r['id'] for r in rows})} questions × {len(systems)} systems · "
             f"'correct' = {'LLM judge grade correct' if use_judge else 'rule check passed'}", "",
             "| system | " + " | ".join(metrics) + " | p50 s | tool calls | LLM calls | errors |",
             "|" + "---|" * (len(metrics) + 5)]
    summary: dict = {"systems": {}}
    for s in systems:
        rs = by[s]
        lat = [r.get("latency_s", r.get("seconds")) for r in rs if r.get("latency_s", r.get("seconds")) is not None]
        cells = [_ci([r.get(m) for r in rs]) for m in metrics]
        p50 = statistics.median(lat) if lat else None
        tc = statistics.mean([r.get("tool_calls") or 0 for r in rs]) if rs else 0
        lc = statistics.mean([r.get("llm_calls") or 0 for r in rs]) if rs else 0
        errs = sum(1 for r in rs if r.get("error"))
        lines.append(f"| {s} | " + " | ".join(cells) + f" | {p50 if p50 is None else round(p50, 2)} | {tc:.1f} | {lc:.1f} | {errs} |")
        summary["systems"][s] = {m: [r.get(m) for r in rs].count(None) for m in metrics}
    base = systems[0]
    ref = {r["id"]: bool(r.get("correct")) for r in by[base]}
    if len(systems) > 1:
        lines += ["", f"McNemar (exact) on 'correct' vs {base}:", ""]
        for s in systems[1:]:
            other = {r["id"]: bool(r.get("correct")) for r in by[s]}
            keys = sorted(set(ref) & set(other))
            t = mcnemar([ref[k] for k in keys], [other[k] for k in keys])
            lines.append(f"- {s}: {base}-only correct {t['b']}, {s}-only correct {t['c']}, p = {t['p']:.4f}")
    if part == "B":
        qtypes = sorted({r["qtype"] for r in rows}, key=lambda x: int(x[1:]))
        lines += ["", "## Correct by question type", "", "| qtype | n | " + " | ".join(systems) + " |",
                  "|" + "---|" * (len(systems) + 2)]
        for q in qtypes:
            n = len([r for r in by[base] if r["qtype"] == q])
            cells = []
            for s in systems:
                v = [float(bool(r.get("correct"))) for r in by[s] if r["qtype"] == q]
                cells.append(f"{sum(v) / len(v):.2f}" if v else "-")
            lines.append(f"| {q} | {n} | " + " | ".join(cells) + " |")
        att = {s: Counter(r.get("attribution") for r in by[s] if r.get("attribution")) for s in systems if s.startswith("mas")}
        if any(att.values()):
            lines += ["", "## Error attribution (first agent that went wrong, wrong answers only)", ""]
            for s, c in att.items():
                if c:
                    lines.append(f"- {s}: " + ", ".join(f"{k} {v}" for k, v in c.most_common()))
    errs = Counter()
    for r in rows:
        for st in (r.get("trace") or {}).get("steps", []):
            if not st.get("ok") and not str(st.get("error") or "").startswith("skipped"):
                errs[(r["system"], st.get("agent"), str(st.get("error"))[:140])] += 1
        for c in (r.get("trace") or {}).get("calls", []):
            if not c.get("ok"):
                errs[(r["system"], c.get("tool"), str(c.get("error"))[:140])] += 1
    if errs:
        lines += ["", "## Most frequent step / tool errors (check these first: they are setup problems, not answers)", ""]
        lines += [f"- {n} × {s} · {a}: {e}" for (s, a, e), n in errs.most_common(8)]
    if use_judge:
        grades = {s: Counter(r.get("judge_grade") for r in by[s]) for s in systems}
        lines += ["", "Judge grades: " + "; ".join(f"{s}: " + ", ".join(f"{k} {v}" for k, v in g.most_common())
                                                   for s, g in grades.items())]
    return "\n".join(lines) + "\n", summary


def write_outputs(out_dir: Path, rows: list[dict], md: str, use_judge: bool, part: str) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    with (out_dir / "items.jsonl").open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, default=str, ensure_ascii=False) + "\n")
    (out_dir / "summary.md").write_text(md, encoding="utf-8")
    if use_judge:
        judged = [r for r in rows if r.get("judge_grade") in GRADE]
        sample = random.Random(1).sample(judged, min(100, len(judged)))
        with (out_dir / "human_check.csv").open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["id", "system", "question", "reference", "answer", "judge_grade", "human_grade"])
            w.writeheader()
            for r in sample:
                w.writerow({"id": r["id"], "system": r["system"], "question": r.get("question"),
                            "reference": r.get("reference") or r.get("reference", ""), "answer": r.get("answer"),
                            "judge_grade": r["judge_grade"], "human_grade": ""})


def judge_agreement(path: Path) -> dict:
    rows = [r for r in csv.DictReader(path.open(encoding="utf-8")) if r.get("human_grade", "").strip()]
    if not rows:
        raise ValueError("fill the human_grade column (correct / partial / wrong / no_answer) first")
    j = [r["judge_grade"].strip().lower() for r in rows]
    h = [r["human_grade"].strip().lower() for r in rows]
    jb = [x == "correct" for x in j]
    hb = [x == "correct" for x in h]
    return {"n": len(rows), "agreement": sum(a == b for a, b in zip(j, h)) / len(rows),
            "kappa_4_grades": cohen_kappa(j, h), "kappa_correct_vs_not": cohen_kappa([str(x) for x in jb], [str(x) for x in hb]),
            "judge_correct_rate": sum(jb) / len(jb), "human_correct_rate": sum(hb) / len(hb)}


def load_items(path: Path, split: str, limit: int | None, seed: int = 3, qtypes: list[str] | None = None) -> list[dict]:
    items = [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
    if split != "all":
        items = [i for i in items if i.get("split", split) == split]
    if qtypes:
        items = [i for i in items if i.get("qtype") in qtypes]
    if limit and len(items) > limit:                # stratified by question type, reproducible
        by = defaultdict(list)
        for i in items:
            by[i.get("qtype", "")].append(i)
        rnd = random.Random(seed)
        for v in by.values():
            rnd.shuffle(v)
        out, k = [], 0
        while len(out) < limit:
            for v in by.values():
                if k < len(v) and len(out) < limit:
                    out.append(v[k])
            k += 1
        items = out
    return items


def main_e2e(settings: Settings, part: str, systems: list[str], dataset: str | None, split: str, limit: int | None,
             use_judge: bool, include_rag: bool = False, qtypes: list[str] | None = None,
             judge_model: str | None = None, store_kind: str = "graphdb", repository: str = "ffonto-eval") -> Path:
    overrides = {"judge": {"provider": "ollama", "model": judge_model, "json": True}} if judge_model else {}
    if "judge" not in (settings.models.get("slots") or {}) and not judge_model:
        overrides = {"judge": {"provider": "ollama", "model": "gemma4:12b", "json": True}}
    llm = LLMClient(settings, overrides)
    for s in systems:
        if s.startswith("mas-") and s.split("-", 1)[1] not in ABLATIONS:
            raise SystemExit(f"unknown system {s}; ablations: {', '.join('mas-' + a for a in ABLATIONS)}")
    if part == "B":
        ds = Path(dataset) if dataset else settings.root / "eval" / "datasets" / "golden_partB.jsonl"
        scs = {s.id: s for s in load_scenarios(ds.with_name("golden_partB_scenarios.jsonl"))}
        items = load_items(ds, split, limit, qtypes=qtypes)
        rows = asyncio.run(run_partb(settings, systems, items, scs, llm, use_judge, store_kind=store_kind,
                                     repository=repository))
    else:
        ds = Path(dataset) if dataset else settings.root / "eval" / "datasets" / "golden_partA.jsonl"
        items = load_items(ds, split, None)
        rows = asyncio.run(run_parta(settings, systems, items, llm, use_judge, include_rag, limit))
    md, _ = summarize(rows, systems, part, use_judge)
    out = settings.root / settings.get("paths.runs_dir", "runs") / f"{datetime.now():%Y%m%d_%H%M%S}_e2e_{part}"
    write_outputs(out, rows, md, use_judge, part)
    return out
