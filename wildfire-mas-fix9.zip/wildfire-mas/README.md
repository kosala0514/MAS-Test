# wildfire-mas

Multi-agent wildfire screening on top of the FFOnto knowledge graph: a planner, an
orchestrator (LangGraph), worker agents that call tools only through MCP, live NASA FIRMS
hotspots and fire weather, rules R09–R12, and a synthesizer + verifier that cite every
claim. The LLM plans and words the answer; the facts come from the KG, the rules, live
sources, or cited documents.

```
question ─► PLANNER ─► plan (typed DAG) ─► ORCHESTRATOR (LangGraph: parallel waves, timeouts)
              intent, urgency,                │
              slots (few-shot)    ┌───────────┼─────────────┬──────────────┬─────────────┐
                                  ▼           ▼             ▼              ▼             ▼
                               resolve    live_data       risk            kg            rag
                               record→    FIRMS + FWI    rules R09–R12   CQs + IORS,   BM25/bge-m3,
                               site/point (IORS radius)  hazards         NL→SPARQL     CRAG, figures
                                  │           │             │              │             │
                                  └─── MCP: graphdb-mcp · firms-mcp · weather-mcp · rag-mcp ───┘
                                                                │
                     evidence ledger (KG1, LIVE2, R09-1, D3, F1, O1 …) ─► SYNTHESIZER (CRM schema per intent)
                                                                         ─► VERIFIER (cites, safety recall) ─► answer
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,validate]"
cp .env.example .env                # FIRMS_MAP_KEY, FFONTO_V2_PATH, GraphDB URL/repo
ollama pull qwen2.5:14b && ollama pull qwen2.5:7b && ollama pull bge-m3
pytest                              # offline tests; with FFONTO_V2_PATH set, also checks against your project
```

## How it connects to ffonto-v2

wildfire-mas does not replace anything in ffonto-v2. ffonto-v2 builds the knowledge graph (Phase A:
lift, rules R00–R08, validation) and owns the KG question-answering code; wildfire-mas answers
questions (Phase B) and reads the same GraphDB repository.

| From ffonto-v2 | Used by wildfire-mas for |
|---|---|
| `qa/cqs.py` + `queries/CQ*.rq` | the GraphDB agent's CQ01–CQ26, narrowed by record / event / site / date exactly as ffonto-v2 does |
| `qa/pipeline.text_to_sparql` | questions no CQ covers ("plus" mode; `T2S_*` switches still work) |
| `qa/rag.py` + `qa/index` | the RAG agent (bge-m3 over text, tables and figures) when the index exists |
| `qa/examples.py` + `qa/index/examples.jsonl` | the planner's few-shot examples (embedding-nearest labelled questions) |
| `docs/FFVQA_CQ_mapping.xlsx` | golden set Part A (`wfmas golden-import`) |
| `ontology/*.ttl` | the SPARQL guard's term list (read in place, no copying) |

Set `FFONTO_V2_PATH` in `.env`. Without it the system falls back to its own live CQs, guard and BM25 index.
Build ffonto-v2's indexes once if you have not: `cd $FFONTO_V2_PATH && python -m qa.build_index`.

The live module extends FFOnto rather than shadowing it:

| Live data | FFOnto terms it uses | Effect |
|---|---|---|
| FWI days, current weather | `ffonto:WeatherRecord`, `atSite`, `observationDate`, `airTemperatureC`, `relativeHumidityPct`, `windSpeedKmh`, `rainMm`, `ffmc` … `fwi`, `previousRecord` | your CQ08 / CQ09 return live weather too |
| Live hazards (R09–R12) | `ffonto:Hazard`, `hasHazardType`, `inEvent`, `prov:wasDerivedFrom`, `rdfs:comment`; hazard types in `ffontov:HazardScheme` with `mitigatedBy` actions | your CQ24 / CQ25 list satellite hazards and their actions next to image/audio hazards |
| Hotspot classification | `ffonto:ModelObservation`, `ffonto:confidence` (xsd:double) | consistent with your observation model |
| R12 and selected records | `centerWKT`, `captureTime`, `aboutEvent`, `hasObservation` → `predictedClass ffontov:Fire`, `usedThreshold/thresholdValue` | live checks run at the image's own location |

New names avoid clashes with your vocabulary: FWI danger classes are `ffontov:FWIDanger*` (not your
severity values High/Low/Extreme), and R11's hazard is `ElevatedDangerNearActiveFire` (related to your
condition `ElevatedFireDanger`).

### Load the live module into GraphDB

```bash
wfmas ontology load        # ffonto-live.ttl -> graph/ontology, ffonto-live-vocab.ttl -> graph/vocab
wfmas test-cqs             # CQL06 passes once the vocab is loaded
```

### Upgrading from the first version (you loaded the earlier ffonto-live*.ttl)

The first version declared some FFOnto terms again with other ranges (xsd:decimal) and reused the
names High/Low/Extreme. Remove those triples before loading the new files:

```bash
mkdir -p ~/old-live && cp ontology/ffonto-live*.ttl ~/old-live/     # BEFORE replacing the folder
# replace the wildfire-mas folder with the new version (keep your .env), then:
wfmas ontology unload --dir ~/old-live   # removes exactly the old files' triples
wfmas ontology clear-live                # live data written with the old terms
wfmas ontology load
```

### Still to do on your side

- **Site coordinates.** FFOnto sites have `siteName` / grid cells but no coordinates, so R09/R11 only see
  sites the MAS registers for a question (a place, coordinates or a record's `centerWKT`). To include a
  real site, add `ffonto:latitude` / `ffonto:longitude` to it (or a GeoSPARQL WKT point).
- **Images without `centerWKT`** (or audio) get no live checks; the answer says so as a data gap.

### Commands

```bash
wfmas key-status                                     # check the MAP_KEY
wfmas hotspots --brief                               # Sri Lanka (default), last 24 h, stored in the live graph
wfmas hotspots --area=-60,-15,-45,-5 --days 1 --no-persistence --no-store --brief   # note the "=" before a negative bbox
wfmas fwi --lat 7.29 --lon 80.63                     # FWI + danger class, Kandy
wfmas rules                                          # R09–R12 -> inferred-live graph
wfmas ask "Are there any fires near Kandy right now?" --role incident_commander --json trace.json
wfmas ask "What hazards are present and what should we do?" --record "http://purl.org/ffonto/data/record/<uuid>"
wfmas ask "Is the fire score above its threshold?" --record "http://purl.org/ffonto/data/record/<uuid>"
wfmas ask "How does FWI relate to fire spread?"
wfmas ask "..." --transport mcp                      # every tool call over MCP stdio
wfmas test-cqs                                       # CQ tests (entries with an expect block)
wfmas shacl                                          # SHACL check of the live graphs
wfmas golden-import                                  # golden Part A from FFVQA_CQ_mapping.xlsx
streamlit run app/streamlit_mas.py                   # UI with map, plan, evidence
```

## NASA FIRMS: what is and is not a wildfire

FIRMS reports thermal anomalies. `live/classify.py` keeps every detection but labels it,
and only `likely_vegetation_fire` counts as wildfire evidence in rules and answers:

| Check | Category |
|---|---|
| FIRMS `type` column (standard-processing products only): 1 / 2 / 3 | volcanic / static land source / offshore |
| Within 1 km of an entry in `data/static_sources.csv` | static land source or volcanic |
| Outside `land_mask_file` (optional GeoJSON) | offshore |
| Same ~400 m cell detected on ≥ 8 distinct days in 30 | persistent static source (flares, plants) |
| VIIRS confidence `l`, or MODIS confidence < 30 | low confidence |
| none of the above | likely vegetation fire (may still be agricultural burning) |

NRT products have no `type` column, so the persistence check does most of the work. It
costs one extra 30-day request per call (cached 15 minutes; your key allows 5,000
transactions per 10 minutes). Add verified static sources for Sri Lanka to
`data/static_sources.csv` to tighten it further.

The MAP_KEY is read from `.env` and never written to logs, caches, snapshots or the KG.
Set `firms.record_dir` to save every response, and `firms.replay_dir` to replay them, so
evaluation runs are reproducible.

### End-to-end: the whole system vs baselines and ablations

```bash
# Part B (live / geospatial): every question runs inside its scenario (FIRMS, weather and graph replaced,
# all agents real). Create an EMPTY GraphDB repository "ffonto-eval" first (Workbench: Setup > Repositories >
# Create new, same ruleset as your data repository); your data repository is never touched.
wfmas e2e --part B --systems mas,single_agent,llm_only --limit 240
wfmas e2e --part B --systems mas,mas-no_iors,mas-no_verifier,mas-no_crm,mas-no_ialt,mas-no_filter,mas-no_rules --limit 240
# Part A (offline KG): your GraphDB + ffonto-v2; B0 = the original ffonto-v2 pipeline
wfmas e2e --part A --systems mas,ffonto,single_agent,llm_only --limit 150
# validate the LLM judge: fill human_grade in runs/<time>_e2e_B/human_check.csv, then
wfmas e2e-agreement runs/<time>_e2e_B/human_check.csv
```

| System | What it is |
|---|---|
| `mas` | the full multi-agent system |
| `single_agent` (B1) | one LLM with the same tools, choosing calls itself (no planner, schema or verifier) |
| `llm_only` (B2) | the same LLM, no tools |
| `ffonto` (B0, Part A) | the original ffonto-v2 QA pipeline |
| `mas-no_iors`, `-no_verifier`, `-no_crm`, `-no_ialt`, `-no_filter`, `-no_rules` | the full system with one technique switched off (`ablation:` in settings) |

Each answer gets an LLM-judge grade against a reference built from the gold facts, a deterministic
rule check of the key fact, keyword hazard recall (same for every system) and, for the multi-agent
system, citation-based hazard recall, grounded rate and the first agent that went wrong (error
attribution). `--limit` samples evenly across question types. Use a judge model from another family
than the one under test (`--judge-model`, default `gemma4:12b`).

## Where is the fire, and is it a wildfire? (hotspot enrichment)

FIRMS gives a point, a time and an intensity, not a forest name or a land type. `live/enrich.py`
adds both from offline map layers (downloaded once; no API calls while answering), and labels every
vegetation-fire detection **wildfire likely / agricultural burning likely / settlement fire likely /
mixed / unknown**, with reasons. This is a likelihood, not ground truth.

| Setting (`enrichment:`) | Download | Gives |
|---|---|---|
| `protected_areas` | WDPA for Sri Lanka (protectedplanet.net; convert the shapefile with `ogr2ogr -f GeoJSON pa.geojson WDPA_*.shp`) or an Overpass Turbo export of `boundary=protected_area` | park / reserve name and designation |
| `forests` | Forest Department reserves, or Overpass `landuse=forest` with a name | forest name |
| `admin` | GADM 4.1 Sri Lanka level 2 GeoJSON (gadm.org) or HDX admin boundaries (level 3 = DS divisions) | province, district (, division) |
| `places` | GeoNames `LK.txt` (download.geonames.org/export/dump/LK.zip) | "4.2 km NE of Ella" |
| `land_cover` | ESA WorldCover 10 m tiles covering Sri Lanka (folder of GeoTIFFs; `pip install rasterio`), or a GeoJSON of land-use polygons | shares of tree, shrub, grass, crop, built-up… |
| `elevation` | SRTM / Copernicus DEM GeoTIFF (`pip install rasterio`) | metres above sea level |

Put the files under `data/geo/`, set the paths, then:

```bash
wfmas where --lat 6.912 --lon 81.071          # check the layers: what does the system know about this point?
wfmas hotspots --brief                        # by_context: wildfire_likely / agricultural_burning_likely / ...
wfmas ask "Which forests are burning in Sri Lanka today?"     # uses CQL10
```

Evaluate the labels against your own judgement of satellite imagery:

```bash
wfmas enrich-sample --end 2026-04-30 --days 30 --source VIIRS_SNPP_SP,VIIRS_NOAA20_SP -n 100
# open eval/datasets/enrich_labels.csv, hide predicted_context, fill gold_context from the map link
# (wildfire | agricultural | settlement | other | unsure); a second person fills gold_context_2
wfmas eval-enrich                             # accuracy, macro-F1, wildfire P/R/F1, Cohen's κ
```

## Where each technique lives

| Technique | Code |
|---|---|
| Planner (intent, urgency, slots, typed plan DAG, template or LLM plans) | `agents/planner.py`, `agents/state.py` |
| Orchestrator (LangGraph; same nodes run without it) | `orchestrator.py` |
| MCP servers / client bus | `mcp_servers/*`, `tools/bus.py` |
| IORS: radius/day ladder for FIRMS, CQ relaxation, CRAG re-query, early stop | `agents/workers.py` |
| CRM: response schema per intent, evidence→section mapping, safety override | `agents/synthesis.py`, `agents/prompts.py` |
| IALT: intent/urgency/role-conditioned prompts | `agents/prompts.py` |
| Verifier (cites exist, every claim cited, every hazard reported; optional LLM check) | `agents/synthesis.py` |
| SPARQL guard (read-only, LIMIT, ontology terms only, no SERVICE) | `kg/guard.py` |
| Bridge to ffonto-v2 (CQ01–CQ26, text-to-SPARQL, RAG, labelled examples) | `kg/ffonto_bridge.py` |
| Rules R09–R12 | `kg/rules_live.py`, `rules/*.rq` |
| Hotspot enrichment (place, district, protected area, land cover, fire context) | `live/enrich.py`, CQL10–CQL11 |
| FWI (Van Wagner 1987, latitude-adjusted day lengths) | `live/fwi.py` |

## Comparing models

Each LLM job is a slot in `config/models.yaml` (planner, sparql, synthesizer, verifier,
rag_grader, scene_graph, figure_reader). The harness changes the model in one slot and
keeps the others at baseline:

```bash
wfmas golden-import                                   # once: eval/datasets/golden_partA.jsonl (1,001 items)
wfmas-eval --slot planner --pool text --dataset eval/datasets/golden_partA.jsonl --split test --repeats 3
wfmas-eval --slot synthesizer --models qwen2.5:14b,llama3.1:8b,gemma4:12b --dataset eval/datasets/synth.jsonl
wfmas-eval --slot scene_graph --pool vision --dataset eval/datasets/scene.jsonl
wfmas-eval --slot sparql --pool text --dataset eval/datasets/sparql.jsonl     # needs GraphDB
wfmas-eval --slot e2e --models qwen2.5:14b,qwen3:14b --dataset eval/datasets/e2e.jsonl
```

### Live path: hotspot filter and rules R09–R12

```bash
wfmas golden-partb                                   # once: 220 scenarios + ~1,050 Part B questions
wfmas eval-filter                                    # filter vs gold categories (synthetic)
wfmas eval-rules                                     # R09–R12 in modes oracle / pipeline / nofilter
# real data: FIRMS standard-processing products carry a `type` column (0 = vegetation fire,
# 1 volcano, 2 static land source, 3 offshore); the filter runs without it and is scored against it
# 30 extra days are fetched first as history only (--warmup 30), as the live system has them
wfmas eval-filter --fetch-area=79.5,5.8,82.0,9.9 --end 2026-04-30 --days 60
wfmas eval-filter --fetch-area=4.5,4.0,8.5,6.5 --end 2026-05-31 --days 30 --sweep 3,4,5,6,8 \
                  --land-mask ne_10m_land.geojson --source VIIRS_SNPP_SP,VIIRS_NOAA20_SP
wfmas eval-filter --firms-csv fire_archive_SV-C2_*.csv         # or a FIRMS archive download
```

The synthetic sets check that the code meets its specification, including near every threshold
(a mutation test shows a 1 km or 2-day error is caught). The real SP data measures how well the
type-blind filter separates vegetation fires from static heat in the field. The `nofilter` mode
is the ablation: it shows how many false R09/R11 alarms the filter prevents.

Each run writes `runs/<time>_<slot>/items.jsonl`, `summary.csv` and `summary.md`: mean and
95% bootstrap CI per metric, p50/p95 latency, tokens per item, and exact McNemar tests
against the best model. The datasets in `eval/datasets/` are format examples; replace them
with your labelled sets (see `eval/datasets/README.md`). Check model tags in your Ollama
library before running; DeepSeek-VL2 and InternVL3 run through vLLM.

## Status

Tested here: 52 tests, including integration checks against the ffonto-v2 project (`FFONTO_V2_PATH`):
every term in the live CQs and rule inputs exists in FFOnto + the live module; FFOnto's 27 CQ queries
pass the SPARQL guard; the bridge loads CQ01–CQ26 and narrows CQ17 by record and CQ24 by the record's
event; the planner plans CQ24/CQ25/CQ17 + live checks for a selected record; the 1,001 labelled
questions import. Not run here: FIRMS, Open-Meteo, GraphDB, Ollama (this sandbox cannot reach them).
