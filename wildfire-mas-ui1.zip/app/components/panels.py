# app/components/panels.py
"""Rendering of each part of the screening page. Every function takes the Result as a dict."""

from __future__ import annotations

import html
import re

import pandas as pd
import streamlit as st

from . import view as V
from .style import (CATEGORY, DANGER_COLOR, DANGER_LABEL, DANGER_ORDER, KIND, RULE_NAME, UNKNOWN_CATEGORY,
                    kind_of_cite)

_BOLD = re.compile(r"\*\*(.+?)\*\*")


def _txt(s: str) -> str:
    """Escape model text, keeping **bold**."""
    return _BOLD.sub(r"<b>\1</b>", html.escape(str(s)))


def _cite(c: str, known: set[str]) -> str:
    color = KIND[kind_of_cite(c)][1]
    if c not in known:
        return f'<span class="wf-cite missing" title="not in the evidence ledger">{html.escape(c)}</span>'
    return f'<span class="wf-cite" style="background:{color}">{html.escape(c)}</span>'


# ---------------------------------------------------------------- header
def header(chips: list[tuple[str, bool]]) -> None:
    chip_html = "".join(f'<span class="wf-chip{" warn" if warn else ""}">{html.escape(t)}</span>' for t, warn in chips)
    st.markdown(
        f"""<div class="wf-header">
              <div><div class="t">Wildfire<span>·</span>MAS screening</div>
                   <div class="s">Satellite hotspots, fire weather and ontology rules, answered with cited evidence</div></div>
              <div class="wf-chips">{chip_html}</div>
            </div>""",
        unsafe_allow_html=True,
    )


def empty_state() -> None:
    st.markdown(
        """<div class="wf-empty"><b>No screening yet.</b><br/>
        Enter a place or coordinates and a question above, or pick an example.
        The answer, map, fire weather, rule hazards and the agents' trace appear here.</div>""",
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------- outcome banner
def banner(r: dict, meta: dict) -> None:
    o = V.outcome(r)
    color = V.OUTCOME_COLOR[o["level"]]
    c = V.context(r)
    where = c.get("label") or (meta.get("place") or "")
    chips = [f"intent: {r.get('intent', '?')}", f"urgency: {r.get('urgency', '?')}", f"role: {meta.get('role', '?')}"]
    if meta.get("when"):
        chips.append(meta["when"])
    if meta.get("replay"):
        chips.append("replayed from file")
    chip_html = " ".join(f'<span class="wf-chip">{html.escape(x)}</span>' for x in chips)
    demo = ' <span class="wf-chip warn">synthetic sample data</span>' if r.get("_demo") else ""
    st.markdown(
        f"""<div class="wf-banner" style="--c:{color}">
              <div class="k">{html.escape(o['kicker'])}</div>
              <div class="h">{html.escape(o['headline'])}</div>
              <div class="q">“{html.escape(r.get('question', ''))}”{(' · ' + html.escape(where)) if where else ''}</div>
              <div style="margin-top:.45rem">{chip_html}{demo}</div>
            </div>""",
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------- KPI strip
def _kpi(label: str, value: str, detail: str = "", extra: str = "") -> str:
    return (f'<div class="wf-kpi"><div class="l">{label}</div><div class="v">{value}</div>'
            f'<div class="d">{detail}</div>{extra}</div>')


def kpis(r: dict) -> None:
    fw, hb, rs, g, t = V.fwi_block(r), V.hotspot_block(r), V.rule_status(r), V.grounding(r), V.telemetry(r)
    tiles = []

    if fw:
        d = fw["danger"]
        col = DANGER_COLOR.get(d, "#475569")
        scale = "".join(f'<div class="{"on" if k == d else ""}" style="background:{DANGER_COLOR[k]}"></div>'
                        for k in DANGER_ORDER)
        trend = V.trend_direction(fw["summary"])
        fwi = V._f(fw["today"].get("fwi"))
        tiles.append(_kpi("Fire danger today",
                          f'<span class="pill" style="background:{col}">{DANGER_LABEL.get(d, d)}</span>',
                          f"FWI {fwi:.1f}" + (f" · 5-day trend {trend}" if trend else "") if fwi is not None else "",
                          f'<div class="wf-scale">{scale}</div>'))
    else:
        tiles.append(_kpi("Fire danger today", "—", "no fire-weather data in this answer"))

    if hb:
        rad = f"within {hb['radius_km']:g} km" if hb.get("radius_km") else "in the area"
        tiles.append(_kpi("Likely vegetation fires", f"{hb['likely']} <small>of {hb['total']} detections</small>",
                          f"{rad} · last {hb.get('days') or '?'} day(s)"))
    else:
        tiles.append(_kpi("Likely vegetation fires", "—", "no satellite data in this answer"))

    if rs["ran"]:
        evaluated = len(rs["fired"]) + len(rs["not_fired"]) + len(rs["unknown"])
        tiles.append(_kpi("Rule hazards (R09–R12)",
                          f"{len(rs['fired'])} <small>fired of {evaluated} checked</small>",
                          ("unknown (missing data): " + ", ".join(rs["unknown"])) if rs["unknown"]
                          else ", ".join(rs["fired"]) or "none fired"))
    else:
        tiles.append(_kpi("Rule hazards (R09–R12)", "—", "rules were not run for this question"))

    ev = V.evidence(r)
    rate = f"{g['rate'] * 100:.0f}%" if g["rate"] is not None else "—"
    tiles.append(_kpi("Evidence", f"{len(ev)} <small>items</small>",
                      f"{rate} of {g['sentences']} sentences cited"
                      + (f" · {len(r.get('issues') or [])} verifier note(s)" if r.get("issues") else "")))

    tiles.append(_kpi("Response", f"{t['total_s']:.1f} <small>s</small>",
                      f"{t['llm_calls']} LLM · {t['tool_calls']} tool calls · {t['tokens']:,} tokens"))

    for col, tile in zip(st.columns(len(tiles)), tiles):
        col.markdown(tile, unsafe_allow_html=True)


# ---------------------------------------------------------------- answer
def answer(r: dict) -> None:
    known = {e.get("id") for e in V.evidence(r)}
    secs = V.sections(r)
    if not secs:
        st.markdown(r.get("answer_markdown") or "_No answer was returned._")
        return
    out = []
    for i, s in enumerate(secs):
        body = " ".join(_txt(x.get("text", "").strip()) + "".join(_cite(str(c), known) for c in (x.get("cites") or []))
                        for x in (s.get("sentences") or []) if str(x.get("text", "")).strip())
        lead = " lead" if i == 0 and str(s.get("title", "")).lower() in ("answer", "reply", "clarification") else ""
        out.append(f'<div class="wf-sec{lead}"><div class="st">{html.escape(str(s.get("title", "")))}</div>'
                   f'<div class="body">{body}</div></div>')
    st.markdown("".join(out), unsafe_allow_html=True)
    for issue in r.get("issues") or []:
        st.caption(f"⚠ Verifier: {issue}")
    with st.expander("Answer as plain text (copy)"):
        st.code(r.get("answer_markdown") or "", language="markdown")


# ---------------------------------------------------------------- hazards
def hazards(r: dict) -> None:
    hz, rs = V.hazards(r), V.rule_status(r)
    if not rs["ran"] and not hz:
        st.caption("The planner did not run the hazard rules for this question.")
        return
    for h in hz:
        acts = "".join(f"<li>{html.escape(a)}</li>" for a in h["actions"])
        st.markdown(
            f"""<div class="wf-haz"><div class="top"><span class="code">{html.escape(h['rule'])}</span>
                <span class="n">{html.escape(h['name'])}</span>
                <span class="wf-note" style="margin-left:auto">evidence {html.escape(str(h['id']))}</span></div>
                <div class="x">{_txt(h['explanation'])}</div>
                {('<div class="al">Recommended actions</div><ul>' + acts + '</ul>') if acts else ''}</div>""",
            unsafe_allow_html=True,
        )
    rows = [f'<div class="wf-rule-row"><span class="code">{c}</span><span class="ok">not fired</span>'
            f'<span>{html.escape(RULE_NAME.get(c, ""))}: hazard absent on current data</span></div>'
            for c in rs["not_fired"]]
    rows += [f'<div class="wf-rule-row"><span class="code">{c}</span><span class="unk">unknown</span>'
             f'<span>{html.escape(RULE_NAME.get(c, ""))}: could not be evaluated (missing input data)</span></div>'
             for c in rs["unknown"]]
    if rows:
        st.markdown("".join(rows), unsafe_allow_html=True)


# ---------------------------------------------------------------- tab: fire weather
def fire_weather_tab(r: dict, classes: list[dict], classes_from_settings: bool) -> None:
    fw = V.fwi_block(r)
    if not fw:
        st.info("This answer did not use fire-weather data. Ask about fire danger, FWI or the trend to get it.")
        return
    t = fw["today"]
    left, right = st.columns([1.6, 1])
    with left:
        st.markdown(f"**Fire Weather Index, last {len(fw['trend'])} days**")
        df = pd.DataFrame([{"date": x.get("date"), "FWI": V._f(x.get("fwi"))} for x in fw["trend"]])
        if not df.empty:
            try:
                import altair as alt
                lo, hi = 0.0, max(float(df["FWI"].max()) * 1.25, 10.0)
                bands, prev = [], 0.0
                for c in classes:
                    top = min(float(c["max"]), hi)
                    if prev < hi:
                        bands.append({"y": prev, "y2": top, "cls": DANGER_LABEL.get(c["name"], c["name"]),
                                      "color": DANGER_COLOR.get(c["name"], "#999")})
                    prev = float(c["max"])
                bdf = pd.DataFrame(bands)
                band = alt.Chart(bdf).mark_rect(opacity=0.13).encode(
                    y=alt.Y("y:Q", scale=alt.Scale(domain=[lo, hi]), title="FWI"), y2="y2:Q",
                    color=alt.Color("color:N", scale=None), tooltip=["cls:N"])
                line = alt.Chart(df).mark_line(point=alt.OverlayMarkDef(size=60, filled=True), color="#1c1917").encode(
                    x=alt.X("date:N", title=None, axis=alt.Axis(labelAngle=0)),
                    y=alt.Y("FWI:Q", scale=alt.Scale(domain=[lo, hi])),
                    tooltip=["date:N", alt.Tooltip("FWI:Q", format=".1f")])
                st.altair_chart((band + line).properties(height=260), use_container_width=True)
            except ImportError:
                st.line_chart(df.set_index("date"))
        trend = V.trend_direction(fw["summary"])
        st.caption((f"Trend decided by code (least-squares slope, 10 % dead band): **{trend}**. " if trend else "")
                   + ("Bands: danger classes from settings.yaml." if classes_from_settings
                      else "Bands: default class limits (settings.yaml not readable)."))
    with right:
        d = fw["danger"]
        st.markdown(f"**Today ({t.get('date', '')})** · "
                    f"<span class='wf-chip' style='background:{DANGER_COLOR.get(d, '#475569')};color:#fff;border:none'>"
                    f"{DANGER_LABEL.get(d, d)}</span>", unsafe_allow_html=True)
        comp = [("FWI", "Fire Weather Index", "fwi"), ("ISI", "Initial Spread Index", "isi"),
                ("BUI", "Buildup Index", "bui"), ("FFMC", "Fine Fuel Moisture Code", "ffmc"),
                ("DMC", "Duff Moisture Code", "dmc"), ("DC", "Drought Code", "dc")]
        st.dataframe(pd.DataFrame([{"Index": a, "Meaning": b, "Value": V._f(t.get(k))} for a, b, k in comp]),
                     hide_index=True, use_container_width=True,
                     column_config={"Value": st.column_config.NumberColumn(format="%.1f")})
        w = st.columns(4)
        w[0].metric("Temp", f"{V._f(t.get('temp')) or 0:.0f} °C")
        w[1].metric("RH", f"{V._f(t.get('rh')) or 0:.0f} %")
        w[2].metric("Wind", f"{V._f(t.get('wind')) or 0:.0f} km/h")
        w[3].metric("Rain 24 h", f"{V._f(t.get('rain')) or 0:.1f} mm")
        st.caption(f"Noon weather; {fw['source']}. Evidence {fw['id']}.")


# ---------------------------------------------------------------- tab: detections
def detections_tab(r: dict) -> None:
    hb = V.hotspot_block(r)
    if not hb:
        st.info("This answer did not use satellite hotspot data.")
        return
    cats = hb["by_category"]
    if cats:
        cols = st.columns(min(len(cats), 6))
        for col, (k, v) in zip(cols, sorted(cats.items(), key=lambda kv: -kv[1])):
            col.metric(CATEGORY.get(k, UNKNOWN_CATEGORY)[0], v)
    df = pd.DataFrame(hb["rows"])
    if df.empty:
        st.caption("No detections returned.")
        return
    labels = {k: v[0] for k, v in CATEGORY.items()}
    df["category"] = df["category"].map(lambda c: labels.get(c, c))
    only = st.toggle("Likely vegetation fires only", value=False)
    if only:
        df = df[df["likely_fire"]]
    st.dataframe(
        df[["category", "time_utc", "distance_km", "frp_mw", "confidence", "source", "where", "reason",
            "latitude", "longitude"]],
        hide_index=True, use_container_width=True, height=min(420, 38 + 35 * len(df)),
        column_config={
            "category": "Filter category", "time_utc": "Observed (UTC)",
            "distance_km": st.column_config.NumberColumn("Distance km", format="%.1f"),
            "frp_mw": st.column_config.NumberColumn("FRP MW", format="%.1f"),
            "where": "Land cover / place", "reason": "Why this category",
            "latitude": st.column_config.NumberColumn("Lat", format="%.4f"),
            "longitude": st.column_config.NumberColumn("Lon", format="%.4f"),
        },
    )
    extra = f" Showing the first {len(hb['rows'])}; {hb['truncated']} more not listed." if hb["truncated"] else ""
    st.caption(f"NASA FIRMS ({', '.join(hb['sources']) or 'n/a'}), fetched {hb['fetched_at']} UTC. "
               f"The hotspot filter separates likely vegetation fires from static, volcanic and offshore heat sources."
               + extra)


# ---------------------------------------------------------------- tab: evidence
def evidence_tab(r: dict) -> None:
    ev = V.evidence(r)
    if not ev:
        st.info("No evidence was collected for this answer.")
        return
    cited = V.cited_ids(r)
    kinds = sorted({e.get("kind") for e in ev})
    c1, c2 = st.columns([3, 1])
    pick = c1.multiselect("Kinds", kinds, default=kinds, format_func=lambda k: KIND.get(k, (k,))[0])
    only_cited = c2.toggle("Cited only", value=False)
    for e in ev:
        if e.get("kind") not in pick or (only_cited and e.get("id") not in cited):
            continue
        name, _ = KIND.get(e.get("kind"), (e.get("kind"), "#666"))
        flag = " · 🛡 safety-critical" if e.get("safety_critical") else ""
        used = "cited" if e.get("id") in cited else "not cited"
        with st.expander(f"[{e.get('id')}] {name} · {e.get('source', '')} · {used}{flag}"):
            st.markdown(f"<div class='wf-note'>step {html.escape(str(e.get('step', '')))}</div>",
                        unsafe_allow_html=True)
            st.text(e.get("summary", ""))
            if e.get("query"):
                st.markdown("**SPARQL**")
                st.code(e["query"], language="sparql")
            d = e.get("data")
            if isinstance(d, list) and d and all(isinstance(x, dict) for x in d):
                st.dataframe(pd.DataFrame(d), hide_index=True, use_container_width=True)
            elif d not in (None, [], {}):
                with st.popover("Raw payload") if hasattr(st, "popover") else st.container():
                    st.json(d, expanded=False)


# ---------------------------------------------------------------- tab: agent trace
AGENT_COLOR = {"resolve": "#475569", "live_data": "#0f766e", "kg": "#4338ca", "risk": "#b91c1c", "rag": "#a16207"}


def trace_tab(r: dict) -> None:
    waves = V.plan_waves(r)
    plan = r.get("plan") or {}
    st.markdown(f"**Plan** · intent `{plan.get('intent', r.get('intent'))}` · urgency `{plan.get('urgency', '?')}` · "
                f"{sum(len(w) for w in waves)} steps in {len(waves)} parallel wave(s)")
    if waves:
        cols = st.columns(len(waves) + 2)
        for i, (col, wave) in enumerate(zip(cols, waves)):
            cards = []
            for s in wave:
                res = s.get("result") or {}
                ok = res.get("ok")
                c = AGENT_COLOR.get(s.get("agent"), "#64748b") if ok is not False else "#b91c1c"
                status = "✓" if ok else ("✗" if ok is False else "·")
                evs = ", ".join(res.get("evidence") or [])
                err = f'<div class="er">{html.escape(str(res.get("error")))}</div>' if res.get("error") else ""
                cards.append(f'<div class="wf-step" style="--c:{c}"><div class="a">{status} {html.escape(str(s.get("id")))}'
                             f' · {html.escape(str(s.get("agent")))}</div>'
                             f'<div class="tk">{html.escape(str(s.get("task", "")))[:140]}</div>'
                             f'{("<div>→ " + html.escape(evs) + "</div>") if evs else ""}{err}</div>')
            col.markdown(f'<div class="wf-wave"><div class="wl">Wave {i + 1}</div>{"".join(cards)}</div>',
                         unsafe_allow_html=True)
        t = V.telemetry(r)
        cols[-2].markdown(
            f'<div class="wf-wave"><div class="wl">Synthesize + verify</div>'
            f'<div class="wf-step" style="--c:#7c3aed"><div class="a">synthesizer</div>'
            f'<div class="tk">CRM sections, every sentence cited</div></div>'
            f'<div class="wf-step" style="--c:#7c3aed"><div class="a">verifier</div>'
            f'<div class="tk">{t["rewrites"]} rewrite(s); {len(r.get("issues") or [])} note(s)</div></div></div>',
            unsafe_allow_html=True)
        conf = f"{t['confidence']:.2f}" if t["confidence"] is not None else "n/a"
        cols[-1].markdown(
            f'<div class="wf-wave"><div class="wl">Answer</div><div class="wf-step" style="--c:#1c1917">'
            f'<div class="a">{len(V.sections(r))} sections</div><div class="tk">self-reported confidence {conf}</div>'
            f'</div></div>', unsafe_allow_html=True)

    notes = [(s.get("id"), s.get("agent"), n) for s in (r.get("steps") or []) for n in (s.get("notes") or [])]
    if notes:
        with st.expander(f"Agent notes ({len(notes)}) — IORS rounds, rule derivations, fallbacks"):
            for sid, ag, n in notes:
                st.markdown(f"- `{sid}` **{ag}**: {n}")

    t = V.telemetry(r)
    st.markdown("**Time per stage**")
    stages = [(k, v) for k, v in t["timings"].items() if k != "total" and V._f(v) is not None]
    if stages:
        sdf = pd.DataFrame(stages, columns=["stage", "seconds"])
        try:
            import altair as alt
            st.altair_chart(alt.Chart(sdf).mark_bar(color="#c2410c").encode(
                x=alt.X("seconds:Q", title="seconds"), y=alt.Y("stage:N", sort=None, title=None),
                tooltip=["stage", alt.Tooltip("seconds:Q", format=".2f")]).properties(height=36 * len(sdf) + 20),
                use_container_width=True)
        except ImportError:
            st.bar_chart(sdf.set_index("stage"))
    c1, c2 = st.columns(2)
    with c1:
        st.markdown(f"**LLM calls** · {t['prompt_tokens']:,} prompt + {t['completion_tokens']:,} completion tokens")
        if r.get("llm_calls"):
            st.dataframe(pd.DataFrame(r["llm_calls"]), hide_index=True, use_container_width=True)
    with c2:
        st.markdown(f"**Tool calls** · {t['tool_calls']}" + (f" ({t['failed_tools']} failed)" if t["failed_tools"] else ""))
        if r.get("tool_calls"):
            tdf = pd.DataFrame(r["tool_calls"])
            if "args" in tdf:
                tdf["args"] = tdf["args"].map(lambda a: ", ".join(f"{k}={v}" for k, v in (a or {}).items())
                                              if isinstance(a, dict) else str(a))
            st.dataframe(tdf, hide_index=True, use_container_width=True)


# ---------------------------------------------------------------- tab: conversation
def conversation_tab(history: list[dict]) -> None:
    if not history:
        st.caption("Questions asked in this session appear here.")
        return
    for h in history:
        with st.chat_message("user"):
            st.markdown(h["question"])
            st.caption(h.get("when", ""))
        with st.chat_message("assistant", avatar="🔥"):
            st.markdown(h["result"].get("answer_markdown") or "_no answer_")
