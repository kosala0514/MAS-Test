# app/components/view.py
"""Turn an orchestrator Result into what the UI shows. No Streamlit here, so it can be tested alone.

Field names follow the real schema:
  * Result (orchestrator.py): answer_markdown, sections, intent, urgency, plan, steps, evidence,
    tool_calls, llm_calls, issues, timings, context, confidence, rewrites
  * evidence items are dicts: id, kind, source, summary, query, safety_critical, step, data
  * live hotspot payload (toolkit firms.get_hotspots): total, likely_wildfire, by_category, sources,
    fetched_at, hotspots[], _radius_km, _days, truncated
  * hotspot (live/firms.py Hotspot.to_dict): latitude, longitude, acq_datetime, source, satellite,
    confidence_raw, confidence_score, frp, category, wildfire_evidence, reasons, enrichment
  * FWI payload (live/weather.py FWIReport.to_dict): today{date, fwi, ffmc, ...}, danger, trend[], source
  * rule payload (risk agent): rule, type, explanation, site, actions
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import asdict, is_dataclass
from typing import Any

from .style import DANGER_ORDER, HAZARD


# ---------------------------------------------------------------- normalise
def to_dict(result: Any) -> dict | None:
    """Accept a Result dataclass, a dict (e.g. loaded from `wfmas ask --json`), or a JSON string."""
    if result is None:
        return None
    if is_dataclass(result):
        return json.loads(json.dumps(asdict(result), default=str))
    if isinstance(result, str):
        return json.loads(result)
    if isinstance(result, dict):
        return result
    raise TypeError(f"unsupported result type {type(result).__name__}")


def _f(x) -> float | None:
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def haversine_km(lat1, lon1, lat2, lon2) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def evidence(r: dict) -> list[dict]:
    return [e for e in (r.get("evidence") or []) if isinstance(e, dict)]


def context(r: dict) -> dict:
    return r.get("context") or {}


def query_point(r: dict) -> tuple[float, float] | None:
    c = context(r)
    lat, lon = _f(c.get("lat")), _f(c.get("lon"))
    if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180):
        return None
    return lat, lon


# ---------------------------------------------------------------- live data
def hotspot_block(r: dict) -> dict | None:
    """The (last) FIRMS evidence item, with a flat hotspot list ready for the map and table."""
    blocks = [e for e in evidence(r) if e.get("kind") == "live" and isinstance(e.get("data"), dict)
              and isinstance(e["data"].get("hotspots"), list)]
    if not blocks:
        return None
    e = blocks[-1]
    d = e["data"]
    q = query_point(r)
    rows = []
    for h in d["hotspots"]:
        if not isinstance(h, dict):
            continue
        lat, lon = _f(h.get("latitude")), _f(h.get("longitude"))
        if lat is None or lon is None:
            continue
        enr = h.get("enrichment") or {}
        reasons = h.get("reasons") or []
        rows.append({
            "latitude": lat,
            "longitude": lon,
            "category": h.get("category") or "unknown",
            "likely_fire": bool(h.get("wildfire_evidence")),
            "time_utc": str(h.get("acq_datetime") or "")[:16].replace("T", " "),
            "frp_mw": _f(h.get("frp")),
            "confidence": h.get("confidence_raw"),
            "confidence_score": _f(h.get("confidence_score")),
            "source": h.get("source") or "",
            "satellite": h.get("satellite") or "",
            "distance_km": round(haversine_km(q[0], q[1], lat, lon), 1) if q else None,
            "reason": reasons[0] if reasons else "",
            "where": enr.get("summary", "") if isinstance(enr, dict) else "",
        })
    rows.sort(key=lambda x: (not x["likely_fire"], x["distance_km"] if x["distance_km"] is not None else 1e9))
    return {
        "id": e.get("id"),
        "total": d.get("total", len(rows)),
        "likely": d.get("likely_wildfire", sum(x["likely_fire"] for x in rows)),
        "by_category": d.get("by_category") or {},
        "by_context": d.get("by_context") or {},
        "radius_km": _f(d.get("_radius_km")) or _f(context(r).get("hotspot_radius_km")),
        "days": d.get("_days", d.get("days")),
        "sources": d.get("sources") or [],
        "fetched_at": str(d.get("fetched_at") or "")[:16].replace("T", " "),
        "truncated": d.get("truncated") or 0,
        "rows": rows,
    }


def fwi_block(r: dict) -> dict | None:
    for e in evidence(r):
        d = e.get("data")
        if e.get("kind") == "live" and isinstance(d, dict) and isinstance(d.get("today"), dict) and "danger" in d:
            trend = [t for t in (d.get("trend") or []) if isinstance(t, dict) and _f(t.get("fwi")) is not None]
            return {"id": e.get("id"), "today": d["today"], "danger": d.get("danger"), "trend": trend,
                    "source": d.get("source", e.get("source", "")), "summary": e.get("summary", "")}
    return None


def trend_direction(summary: str) -> str | None:
    """The trend word decided by code (live/trend.py) is already in the FWI evidence text."""
    s = summary.lower()
    for w in ("rising", "falling", "about the same"):
        if w in s:
            return w
    return None


# ---------------------------------------------------------------- rules
def hazards(r: dict) -> list[dict]:
    out = []
    for e in evidence(r):
        if e.get("kind") != "rule":
            continue
        d = e.get("data") if isinstance(e.get("data"), dict) else {}
        t = d.get("type", "")
        name, code = HAZARD.get(t, (re.sub(r"(?<!^)(?=[A-Z])", " ", t).capitalize() or "Hazard", d.get("rule", "")))
        out.append({"id": e.get("id"), "rule": d.get("rule") or code, "type": t, "name": name,
                    "explanation": d.get("explanation") or e.get("summary", ""),
                    "actions": [a for a in (d.get("actions") or []) if a], "site": d.get("site")})
    return out


def rule_status(r: dict) -> dict:
    """fired / not_fired / unknown rule codes, from the risk agent's closed-world evidence."""
    fired = sorted({h["rule"] for h in hazards(r) if h["rule"]})
    not_fired, unknown, ran = [], [], False
    for e in evidence(r):
        if e.get("kind") != "kg" or "R09" not in str(e.get("source", "")):
            continue
        ran = True
        d = e.get("data")
        if isinstance(d, dict) and "not_fired" in d:
            not_fired = list(d.get("not_fired") or [])
        if "could not be evaluated" in str(e.get("summary", "")):
            unknown = sorted(set(re.findall(r"R\d\d", e.get("summary", ""))))
    if fired:
        ran = True
    return {"ran": ran, "fired": fired, "not_fired": [x for x in not_fired if x not in fired],
            "unknown": [x for x in unknown if x not in fired]}


# ---------------------------------------------------------------- answer
def sections(r: dict) -> list[dict]:
    secs = [s for s in (r.get("sections") or []) if isinstance(s, dict)]
    return secs


def cited_ids(r: dict) -> set[str]:
    out = set()
    for s in sections(r):
        for x in s.get("sentences") or []:
            out |= {str(c) for c in (x.get("cites") or [])}
    return out


def grounding(r: dict) -> dict:
    """Share of answer sentences that carry citations which exist in the evidence ledger."""
    ids = {e.get("id") for e in evidence(r)}
    n = ok = 0
    for s in sections(r):
        for x in s.get("sentences") or []:
            if not str(x.get("text", "")).strip():
                continue
            n += 1
            cites = x.get("cites") or []
            if cites and all(c in ids for c in cites):
                ok += 1
    return {"sentences": n, "grounded": ok, "rate": (ok / n) if n else None}


# ---------------------------------------------------------------- outcome (never a risk score)
def outcome(r: dict) -> dict:
    """A plain statement of what the evidence shows. Deliberately not a numeric risk score."""
    hz = hazards(r)
    hb = hotspot_block(r)
    intent = r.get("intent")
    if intent == "chitchat" or (not evidence(r) and sections(r) and sections(r)[0].get("title") == "Clarification"):
        return {"level": "info", "kicker": "Clarification needed" if intent != "chitchat" else "Reply",
                "headline": "The system needs more information to screen this request"
                if intent != "chitchat" else "No screening was required"}
    if hz:
        names = ", ".join(dict.fromkeys(h["name"] for h in hz))
        return {"level": "hazard", "kicker": f"{len(hz)} rule hazard{'s' if len(hz) != 1 else ''} detected",
                "headline": names}
    if hb and hb["likely"]:
        return {"level": "watch", "kicker": "Fire activity, no rule hazard",
                "headline": f"{hb['likely']} likely vegetation fire(s) in the search area, none triggering R09–R12"}
    if hb is not None or rule_status(r)["ran"]:
        return {"level": "clear", "kicker": "No hazard found",
                "headline": "No likely wildfire and no rule hazard in the screened area"}
    return {"level": "info", "kicker": "Knowledge answer", "headline": "Answered from the knowledge graph and documents"}


OUTCOME_COLOR = {"hazard": "#b91c1c", "watch": "#ec7a1c", "clear": "#3f6212", "info": "#475569"}


# ---------------------------------------------------------------- telemetry and plan
def telemetry(r: dict) -> dict:
    llm = [c for c in (r.get("llm_calls") or []) if isinstance(c, dict)]
    tools = [c for c in (r.get("tool_calls") or []) if isinstance(c, dict)]
    pt = sum(int(c.get("prompt_tokens") or 0) for c in llm)
    ct = sum(int(c.get("completion_tokens") or 0) for c in llm)
    models = sorted({c.get("model") for c in llm if c.get("model")})
    return {"total_s": _f((r.get("timings") or {}).get("total")) or 0.0, "timings": r.get("timings") or {},
            "llm_calls": len(llm), "tool_calls": len(tools), "prompt_tokens": pt, "completion_tokens": ct,
            "tokens": pt + ct, "models": models, "failed_tools": sum(1 for t in tools if not t.get("ok", True)),
            "rewrites": int(r.get("rewrites") or 0), "confidence": _f(r.get("confidence"))}


def plan_waves(r: dict) -> list[list[dict]]:
    """Plan steps grouped into the parallel waves the orchestrator runs, joined with each step's result."""
    steps = [s for s in ((r.get("plan") or {}).get("steps") or []) if isinstance(s, dict)]
    res = {s.get("id"): s for s in (r.get("steps") or []) if isinstance(s, dict)}
    done, left, waves = set(), list(steps), []
    while left:
        wave = [s for s in left if set(s.get("after") or []) <= done]
        if not wave:            # malformed plan: show the rest as one wave instead of looping
            wave = left
        waves.append([{**s, "result": res.get(s.get("id"))} for s in wave])
        done |= {s.get("id") for s in wave}
        left = [s for s in left if s.get("id") not in done]
    return waves


def danger_rank(name: str | None) -> int:
    return DANGER_ORDER.index(name) if name in DANGER_ORDER else -1
