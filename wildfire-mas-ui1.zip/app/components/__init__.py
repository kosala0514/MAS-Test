"""UI components for the Wildfire-MAS Streamlit console."""
