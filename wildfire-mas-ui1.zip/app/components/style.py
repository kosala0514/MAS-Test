# app/components/style.py
"""Colours, labels and CSS shared by every panel.

Colour carries meaning in two places only:
  * the FWI danger class (standard blue -> green -> yellow -> orange -> red -> purple scale)
  * the hotspot category on the map
Everything else stays neutral so those two read at a glance.
"""

# ---------------------------------------------------------------- FWI danger classes
DANGER_ORDER = ["VeryLow", "Low", "Moderate", "High", "VeryHigh", "Extreme"]
DANGER_COLOR = {
    "VeryLow": "#2b83ba",
    "Low": "#3f9b3a",
    "Moderate": "#d4a900",
    "High": "#ec7a1c",
    "VeryHigh": "#d7301f",
    "Extreme": "#7a0177",
}
DANGER_LABEL = {
    "VeryLow": "Very low", "Low": "Low", "Moderate": "Moderate",
    "High": "High", "VeryHigh": "Very high", "Extreme": "Extreme",
}
# Used only when config/settings.yaml (danger.fwi_classes) cannot be read; the UI says so.
FALLBACK_FWI_CLASSES = [
    {"name": "VeryLow", "max": 5.2}, {"name": "Low", "max": 11.2},
    {"name": "Moderate", "max": 21.3}, {"name": "High", "max": 38.0},
    {"name": "VeryHigh", "max": 50.0}, {"name": "Extreme", "max": 1e9},
]

# ---------------------------------------------------------------- hotspot categories (live/classify.py)
CATEGORY = {
    "likely_vegetation_fire": ("Likely vegetation fire", (226, 61, 30)),
    "low_confidence": ("Low-confidence detection", (240, 168, 38)),
    "persistent_static_source": ("Persistent static source", (124, 94, 166)),
    "static_land_source": ("Industrial / static land source", (92, 96, 112)),
    "volcanic": ("Volcanic", (139, 87, 42)),
    "offshore": ("Offshore (platform / flare)", (38, 120, 178)),
}
UNKNOWN_CATEGORY = ("Unclassified", (150, 150, 150))

# ---------------------------------------------------------------- rule hazards (R09-R12)
HAZARD = {
    "NearbyActiveFire": ("Nearby active fire", "R09"),
    "SpreadingFire": ("Spreading fire", "R10"),
    "ElevatedDangerNearActiveFire": ("Danger raised by a nearby fire", "R11"),
    "SatelliteSceneConflict": ("Satellite data contradicts the image", "R12"),
}
RULE_NAME = {code: name for name, code in HAZARD.values()}

# ---------------------------------------------------------------- evidence kinds (EvidenceLedger prefixes)
KIND = {
    "live": ("Live data", "#0f766e"),
    "rule": ("Rule", "#b91c1c"),
    "kg": ("Knowledge graph", "#4338ca"),
    "doc": ("Document", "#6b7280"),
    "figure": ("Figure", "#a16207"),
    "ontology": ("Ontology", "#7c3aed"),
}


def kind_of_cite(cite: str) -> str:
    c = cite.upper()
    if c.startswith("LIVE"):
        return "live"
    if c.startswith("KG"):
        return "kg"
    if c[:1] == "R" and c[1:3].isdigit():
        return "rule"
    if c.startswith("D"):
        return "doc"
    if c.startswith("F"):
        return "figure"
    if c.startswith("O"):
        return "ontology"
    return "doc"


CSS = """
<style>
:root {
  --wf-ink: #1c1917;
  --wf-muted: #6b6560;
  --wf-line: #e7e2dc;
  --wf-card: #ffffff;
  --wf-soft: #f6f3ef;
  --wf-ember: #c2410c;
}
.block-container { padding-top: 1.2rem; padding-bottom: 3rem; max-width: 1640px; }
h1, h2, h3, h4 { letter-spacing: -0.01em; }

/* header */
.wf-header { display:flex; align-items:flex-end; justify-content:space-between; gap:1rem;
  border-bottom: 1px solid var(--wf-line); padding: 0 0 0.8rem 0; margin-bottom: 1rem; }
.wf-header .t { font-size: 1.55rem; font-weight: 700; color: var(--wf-ink); line-height: 1.15; }
.wf-header .t span { color: var(--wf-ember); }
.wf-header .s { color: var(--wf-muted); font-size: 0.9rem; margin-top: 0.15rem; }
.wf-chips { display:flex; flex-wrap:wrap; gap: 0.35rem; justify-content:flex-end; }
.wf-chip { display:inline-block; font-size: 0.75rem; padding: 0.18rem 0.55rem; border-radius: 999px;
  border: 1px solid var(--wf-line); background: var(--wf-soft); color: #44403c; white-space: nowrap; }
.wf-chip.warn { background:#fff4e5; border-color:#f5c27a; color:#8a4b00; }

/* outcome banner */
.wf-banner { border: 1px solid var(--wf-line); border-left: 6px solid var(--c); border-radius: 10px;
  background: var(--wf-card); padding: 0.85rem 1.1rem; margin: 0.2rem 0 0.9rem 0; }
.wf-banner .k { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .06em; color: var(--c); font-weight: 700; }
.wf-banner .h { font-size: 1.2rem; font-weight: 700; color: var(--wf-ink); margin: 0.1rem 0; }
.wf-banner .q { color: var(--wf-muted); font-size: 0.9rem; }

/* KPI tiles */
.wf-kpi { border: 1px solid var(--wf-line); border-radius: 10px; background: var(--wf-card);
  padding: 0.7rem 0.9rem; height: 100%; min-height: 104px; }
.wf-kpi .l { font-size: 0.74rem; color: var(--wf-muted); text-transform: uppercase; letter-spacing: .05em; }
.wf-kpi .v { font-size: 1.55rem; font-weight: 700; color: var(--wf-ink); line-height: 1.2; margin-top: 0.15rem; }
.wf-kpi .v small { font-size: 0.85rem; font-weight: 500; color: var(--wf-muted); }
.wf-kpi .d { font-size: 0.8rem; color: var(--wf-muted); margin-top: 0.15rem; }
.wf-kpi .pill { display:inline-block; color:#fff; border-radius: 6px; padding: 0.05rem 0.5rem; }

/* danger scale strip */
.wf-scale { display:flex; gap:2px; margin-top: 0.4rem; }
.wf-scale div { flex:1; height: 6px; border-radius: 2px; opacity: 0.25; }
.wf-scale div.on { opacity: 1; height: 8px; margin-top:-1px; }

/* answer */
.wf-sec { margin: 0 0 0.85rem 0; }
.wf-sec .st { font-size: 0.78rem; text-transform: uppercase; letter-spacing: .06em; color: var(--wf-muted);
  font-weight: 700; margin-bottom: 0.25rem; }
.wf-sec.lead { background: var(--wf-soft); border-radius: 8px; padding: 0.7rem 0.85rem; }
.wf-sec.lead .body { font-size: 1.02rem; color: var(--wf-ink); }
.wf-sec .body { line-height: 1.55; color: #292524; }
.wf-cite { display:inline-block; font-size: 0.68rem; font-weight: 600; padding: 0 0.32rem; margin-left: 0.15rem;
  border-radius: 4px; color: #fff; vertical-align: 1px; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.wf-cite.missing { background: #fff !important; color: #b91c1c; border: 1px dashed #b91c1c; }

/* hazard cards */
.wf-haz { border: 1px solid #f3c4bc; border-left: 5px solid #b91c1c; background: #fff7f5; border-radius: 9px;
  padding: 0.65rem 0.85rem; margin-bottom: 0.55rem; }
.wf-haz .top { display:flex; align-items:center; gap: 0.45rem; }
.wf-haz .code { font-family: ui-monospace, monospace; font-size: 0.72rem; background:#b91c1c; color:#fff;
  border-radius: 4px; padding: 0.02rem 0.35rem; }
.wf-haz .n { font-weight: 700; color: #7f1d1d; }
.wf-haz .x { color: #44403c; font-size: 0.88rem; margin: 0.3rem 0 0.2rem 0; }
.wf-haz ul { margin: 0.15rem 0 0 1.1rem; padding: 0; font-size: 0.88rem; }
.wf-haz .al { font-size: 0.72rem; text-transform: uppercase; letter-spacing: .05em; color: #7f1d1d; font-weight: 700; margin-top: 0.3rem; }

.wf-rule-row { display:flex; gap: 0.5rem; align-items: baseline; font-size: 0.88rem; padding: 0.3rem 0;
  border-bottom: 1px dashed var(--wf-line); }
.wf-rule-row:last-child { border-bottom: none; }
.wf-rule-row .code { font-family: ui-monospace, monospace; font-size: 0.72rem; border-radius: 4px; padding: 0.02rem 0.35rem;
  border: 1px solid var(--wf-line); background: var(--wf-soft); white-space: nowrap; }
.wf-rule-row .ok { color: #3f6212; font-weight: 600; white-space: nowrap; }
.wf-rule-row .unk { color: #8a4b00; font-weight: 600; white-space: nowrap; }

/* legend */
.wf-legend { display:flex; flex-wrap:wrap; gap: 0.3rem 0.9rem; font-size: 0.8rem; color: #44403c; margin: 0.35rem 0 0.2rem 0; }
.wf-legend i { display:inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 0.3rem; vertical-align: -1px; }
.wf-legend i.ring { background: transparent !important; border: 2px solid #1d4ed8; }

/* plan waves */
.wf-wave { border: 1px solid var(--wf-line); border-radius: 9px; padding: 0.55rem; background: var(--wf-soft); height: 100%; }
.wf-wave .wl { font-size: 0.72rem; text-transform: uppercase; color: var(--wf-muted); letter-spacing: .05em; margin-bottom: .35rem; }
.wf-step { background: #fff; border: 1px solid var(--wf-line); border-left: 4px solid var(--c); border-radius: 7px;
  padding: 0.4rem 0.55rem; margin-bottom: 0.4rem; font-size: 0.82rem; }
.wf-step .a { font-weight: 700; }
.wf-step .tk { color: var(--wf-muted); }
.wf-step .er { color: #b91c1c; }

.wf-empty { border: 1px dashed var(--wf-line); border-radius: 12px; padding: 1.6rem; text-align: center; color: var(--wf-muted); background: var(--wf-card); }
.wf-empty b { color: var(--wf-ink); }
.wf-note { color: var(--wf-muted); font-size: 0.8rem; }
</style>
"""


def inject_css() -> None:
    import streamlit as st
    st.markdown(CSS, unsafe_allow_html=True)
