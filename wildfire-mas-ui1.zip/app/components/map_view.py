# app/components/map_view.py
"""Hotspot map: detections coloured by filter category, sized by fire radiative power,
with the query point and the search radius actually used (IORS may have widened it)."""

from __future__ import annotations

import html
import math

import streamlit as st

from .style import CATEGORY, UNKNOWN_CATEGORY
from .view import hotspot_block, query_point

DEFAULT_CENTER = (7.8731, 80.7718)   # Sri Lanka


def _zoom_for(radius_km: float | None, has_points: bool) -> float:
    if radius_km:
        # roughly fits the search circle in a ~600 px tall map
        return max(4.0, min(12.0, math.log2(40000 / (radius_km * 2.6))))
    return 7.0 if has_points else 6.5


def _tip(row: dict) -> str:
    label, _ = CATEGORY.get(row["category"], UNKNOWN_CATEGORY)
    parts = [f"<b>{html.escape(label)}</b>", f"{row['time_utc']} UTC"]
    if row.get("distance_km") is not None:
        parts.append(f"{row['distance_km']} km from query point")
    if row.get("frp_mw") is not None:
        parts.append(f"FRP {row['frp_mw']:.1f} MW")
    parts.append(f"Confidence {html.escape(str(row.get('confidence') or 'n/a'))} · {html.escape(row.get('source') or '')}")
    if row.get("where"):
        parts.append(html.escape(row["where"])[:160])
    if row.get("reason"):
        parts.append(f"<i>{html.escape(row['reason'])[:160]}</i>")
    return "<br/>".join(parts)


def legend_html(present: set[str]) -> str:
    items = []
    for key, (label, rgb) in CATEGORY.items():
        if key in present:
            items.append(f'<span><i style="background:rgb{rgb}"></i>{label}</span>')
    items.append('<span><i style="background:#1d4ed8"></i>Query point</span>')
    items.append('<span><i class="ring"></i>Search radius</span>')
    return '<div class="wf-legend">' + "".join(items) + "</div>"


def render_map(r: dict, height: int = 560) -> None:
    try:
        import pydeck as pdk
    except ImportError:
        st.warning("pydeck is not installed, so the map cannot be drawn (`pip install pydeck`).")
        return

    hb = hotspot_block(r)
    q = query_point(r)
    rows = hb["rows"] if hb else []
    radius_km = hb["radius_km"] if hb else None

    layers = []
    if q and radius_km:
        layers.append(pdk.Layer(
            "ScatterplotLayer", id="search-radius",
            data=[{"lat": q[0], "lon": q[1], "tip": f"<b>Search radius</b><br/>{radius_km:g} km"
                   + (f" over {hb['days']} day(s)" if hb and hb.get("days") else "")}],
            get_position="[lon, lat]", get_radius=radius_km * 1000, radius_units="meters",
            filled=True, get_fill_color=[29, 78, 216, 18], stroked=True,
            get_line_color=[29, 78, 216, 170], line_width_min_pixels=2, pickable=False,
        ))
    if rows:
        data = []
        for row in rows:
            _, rgb = CATEGORY.get(row["category"], UNKNOWN_CATEGORY)
            frp = row.get("frp_mw") or 0.0
            data.append({**row, "r": rgb[0], "g": rgb[1], "b": rgb[2],
                         "a": 235 if row["likely_fire"] else 170,
                         # area ~ FRP, clamped so one big fire does not hide the rest
                         "px": 5 + min(11, 2.2 * math.sqrt(max(frp, 0.0))),
                         "tip": _tip(row)})
        # draw non-fires first so likely fires sit on top
        data.sort(key=lambda d: d["likely_fire"])
        layers.append(pdk.Layer(
            "ScatterplotLayer", id="hotspots", data=data,
            get_position="[longitude, latitude]", get_fill_color="[r, g, b, a]",
            get_radius="px", radius_units="pixels", stroked=True,
            get_line_color=[255, 255, 255, 230], line_width_min_pixels=1,
            pickable=True, auto_highlight=True,
        ))
    if q:
        layers.append(pdk.Layer(
            "ScatterplotLayer", id="query-point",
            data=[{"lat": q[0], "lon": q[1],
                   "tip": f"<b>{html.escape(str((r.get('context') or {}).get('label') or 'Query point'))}</b>"
                          f"<br/>{q[0]:.4f}, {q[1]:.4f}"}],
            get_position="[lon, lat]", get_radius=7, radius_units="pixels",
            get_fill_color=[29, 78, 216, 255], stroked=True, get_line_color=[255, 255, 255, 255],
            line_width_min_pixels=2, pickable=True,
        ))

    if q:
        center = q
    elif rows:
        lats = sorted(x["latitude"] for x in rows)
        lons = sorted(x["longitude"] for x in rows)
        center = (lats[len(lats) // 2], lons[len(lons) // 2])
    else:
        center = DEFAULT_CENTER

    view = pdk.ViewState(latitude=center[0], longitude=center[1],
                         zoom=_zoom_for(radius_km if q else None, bool(rows)), pitch=0)
    style = getattr(getattr(pdk, "map_styles", None), "CARTO_LIGHT", "light")
    deck = pdk.Deck(
        layers=layers, initial_view_state=view, map_provider="carto", map_style=style,
        tooltip={"html": "{tip}", "style": {"backgroundColor": "#1c1917", "color": "white",
                                             "fontSize": "12px", "maxWidth": "320px"}},
    )
    # `height` and selection arguments differ between Streamlit versions; the plain call works everywhere.
    try:
        st.pydeck_chart(deck, use_container_width=True, height=height)
    except TypeError:
        st.pydeck_chart(deck, use_container_width=True)

    present = {x["category"] for x in rows}
    st.markdown(legend_html(present), unsafe_allow_html=True)
    if not rows:
        st.caption("No satellite detections were returned for this request."
                   if hb else "This answer used no live hotspot data.")
