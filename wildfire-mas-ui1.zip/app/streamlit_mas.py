# app/streamlit_mas.py
"""Wildfire-MAS screening console.

    streamlit run app/streamlit_mas.py

Ask a question about a place (or coordinates / a stored record); the page shows the outcome,
a KPI strip, the hotspot map, the cited answer, rule hazards with actions, and tabs for fire
weather, detections, evidence and the agents' trace. Saved traces from `wfmas ask --json out.json`
can be opened from the sidebar without running any model.
"""

from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime

import streamlit as st

from components import panels as P
from components import view as V
from components.map_view import render_map
from components.style import FALLBACK_FWI_CLASSES, inject_css

st.set_page_config(page_title="Wildfire-MAS screening", page_icon="🔥", layout="wide",
                   initial_sidebar_state="expanded")
inject_css()

# ---------------------------------------------------------------- state
for k, v in {"history": [], "active": None, "error": None,
             "q_text": "", "q_place": "", "q_lat": None, "q_lon": None, "q_role": "analyst",
             "q_record": "", "q_area": ""}.items():
    st.session_state.setdefault(k, v)

EXAMPLES = [
    ("Fires nearby?", "Are there any active wildfires near Anuradhapura right now?", "Anuradhapura"),
    ("Danger today", "What is today's fire danger level near Sigiriya?", "Sigiriya"),
    ("Hazards + actions", "Which hazards are there near Wilpattu National Park and what should crews do?",
     "Wilpattu National Park"),
    ("Danger trend", "Is the fire danger rising over the last five days near Badulla?", "Badulla"),
    ("Not wildfires?", "Are some of the heat detections near Hambantota not wildfires?", "Hambantota"),
    ("Concept", "What does the Fire Weather Index measure?", ""),
]


def _use_example(q: str, place: str) -> None:
    st.session_state.update(q_text=q, q_place=place, q_lat=None, q_lon=None, q_record="", q_area="")


# ---------------------------------------------------------------- backend (lazy, so replay works without it)
@st.cache_resource(show_spinner="Starting agents, tools and knowledge graph…")
def get_orchestrator():
    from wildfire_mas.orchestrator import build
    return build()


@st.cache_data(show_spinner=False)
def fwi_classes() -> tuple[list[dict], bool]:
    try:
        from wildfire_mas.config import get_settings
        c = get_settings().get("danger.fwi_classes")
        if isinstance(c, list) and c and all("name" in x and "max" in x for x in c):
            return c, True
    except Exception:  # noqa: BLE001 - UI must still render without the backend
        pass
    return FALLBACK_FWI_CLASSES, False


def run_screening(q: dict) -> dict:
    from wildfire_mas.agents.state import Request
    req = Request(q["question"], record=q["record"] or None, lat=q["lat"], lon=q["lon"],
                  place=q["place"] or None, area=q["area"] or None, role=q["role"])
    res = asyncio.run(get_orchestrator().ask(req))
    return V.to_dict(res)


def _add(result: dict, meta: dict) -> None:
    st.session_state.history.append({"question": result.get("question", meta.get("question", "")),
                                     "when": meta["when"], "result": result, "meta": meta})
    st.session_state.active = len(st.session_state.history) - 1


# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.markdown("### Screenings")
    hist = st.session_state.history
    if hist:
        labels = [f"{i + 1}. {h['question'][:46]}{'…' if len(h['question']) > 46 else ''}" for i, h in enumerate(hist)]
        pick = st.radio("Open", list(range(len(hist))), index=st.session_state.active or 0,
                        format_func=lambda i: labels[i], label_visibility="collapsed")
        st.session_state.active = pick
        a, b = st.columns(2)
        cur = hist[pick]["result"]
        a.download_button("Save trace", json.dumps(cur, indent=2, default=str), file_name="wfmas_trace.json",
                          mime="application/json", use_container_width=True)
        if b.button("Clear all", use_container_width=True):
            st.session_state.history, st.session_state.active = [], None
            st.rerun()
    else:
        st.caption("Nothing yet. Each question you run is kept here for this session.")

    st.divider()
    st.markdown("### Open a saved trace")
    up = st.file_uploader("JSON from `wfmas ask --json` or *Save trace*", type=["json"],
                          label_visibility="collapsed")
    up_id = (getattr(up, "file_id", None) or up.name) if up is not None else None
    if up is not None and st.session_state.get("_loaded") != up_id:
        try:
            data = V.to_dict(json.loads(up.getvalue().decode("utf-8")))
            if not isinstance(data, dict) or "answer_markdown" not in data:
                raise ValueError("not a Wildfire-MAS result")
            _add(data, {"when": "from file " + up.name, "replay": True, "role": "?"})
            st.session_state["_loaded"] = up_id
            st.rerun()
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not open {up.name}: {exc}")

    st.divider()
    st.caption("Research decision-support prototype. Screening results are not an official fire warning; "
               "confirm with the Forest Department / DMC before acting.")

# ---------------------------------------------------------------- header
active = st.session_state.history[st.session_state.active]["result"] \
    if st.session_state.active is not None and st.session_state.history else None
models = V.telemetry(active)["models"] if active else []
chips = [(f"model: {', '.join(models) if models else os.environ.get('LLM_MODEL', 'models.yaml')}", False),
         ("FIRMS · Open-Meteo · FFOnto", False)]
if not fwi_classes()[1]:
    chips.append(("backend config not found", True))
P.header(chips)

# ---------------------------------------------------------------- query
with st.container(border=True):
    ex = st.columns(len(EXAMPLES))
    for col, (label, q, place) in zip(ex, EXAMPLES):
        col.button(label, on_click=_use_example, args=(q, place), use_container_width=True, help=q)
    with st.form("query", border=False):
        st.text_area("Question", key="q_text", height=72,
                     placeholder="e.g. Are there any active wildfires near Anuradhapura right now?")
        c = st.columns([2.2, 1, 1, 1.2, 0.9])
        c[0].text_input("Place", key="q_place", placeholder="Forest, reserve, town")
        c[1].number_input("Latitude", key="q_lat", min_value=-90.0, max_value=90.0, value=None, format="%.4f")
        c[2].number_input("Longitude", key="q_lon", min_value=-180.0, max_value=180.0, value=None, format="%.4f")
        c[3].selectbox("Answer for", ["analyst", "incident_commander", "public"], key="q_role",
                       format_func=lambda x: x.replace("_", " ").capitalize())
        with st.expander("Record or area (optional)"):
            d = st.columns(2)
            d[0].text_input("Stored record IRI", key="q_record", placeholder="image / audio record in FFOnto")
            d[1].text_input("Area", key="q_area", placeholder="w,s,e,n · ISO3 code · world")
        c[4].markdown("<div style='height:1.75rem'></div>", unsafe_allow_html=True)
        go = c[4].form_submit_button("Screen", type="primary", use_container_width=True)

if go:
    q = {"question": st.session_state.q_text.strip(), "place": st.session_state.q_place.strip(),
         "lat": st.session_state.q_lat, "lon": st.session_state.q_lon, "role": st.session_state.q_role,
         "record": st.session_state.q_record.strip(), "area": st.session_state.q_area.strip()}
    if not q["question"]:
        st.warning("Type a question first.")
    elif (q["lat"] is None) != (q["lon"] is None):
        st.warning("Give both latitude and longitude, or neither.")
    else:
        with st.status("Planning, gathering evidence, applying rules, writing and verifying…", expanded=False) as s:
            try:
                res = run_screening(q)
                _add(res, {**q, "when": datetime.now().strftime("%H:%M:%S"), "replay": False})
                st.session_state.error = None
                s.update(label=f"Done in {V.telemetry(res)['total_s']:.1f} s", state="complete")
            except Exception as exc:  # noqa: BLE001
                st.session_state.error = f"{type(exc).__name__}: {exc}"
                s.update(label="Screening failed", state="error")
        if st.session_state.error is None:
            st.rerun()      # outside try: re-render the page with the new result

if st.session_state.error:
    st.error(f"Screening failed — {st.session_state.error}")
    st.caption("Check that Ollama is running with the configured model, GraphDB is reachable, and FIRMS_MAP_KEY is in .env.")

# ---------------------------------------------------------------- result
if st.session_state.active is None or not st.session_state.history:
    P.empty_state()
    st.stop()

entry = st.session_state.history[st.session_state.active]
r, meta = entry["result"], {**entry.get("meta", {}), "when": entry.get("when")}

P.banner(r, meta)
P.kpis(r)
st.write("")

left, right = st.columns([1.25, 1], gap="large")
with left:
    render_map(r, height=540)
with right:
    st.markdown("#### Answer")
    P.answer(r)
    if V.rule_status(r)["ran"] or V.hazards(r):
        st.markdown("#### Hazards and rule check")
        P.hazards(r)

st.write("")
t_fw, t_det, t_ev, t_tr, t_conv = st.tabs(["Fire weather", "Detections", "Evidence", "Agent trace", "Conversation"])
with t_fw:
    classes, from_settings = fwi_classes()
    P.fire_weather_tab(r, classes, from_settings)
with t_det:
    P.detections_tab(r)
with t_ev:
    P.evidence_tab(r)
with t_tr:
    P.trace_tab(r)
with t_conv:
    P.conversation_tab(st.session_state.history)
