# Wildfire-MAS screening console (ui1)

```bash
cd ~/Documents/wildfire-mas
source .venv/bin/activate
pip install "streamlit>=1.36" pydeck        # altair comes with streamlit
export LLM_MODEL=qwen2.5:14b-8k
streamlit run app/streamlit_mas.py
```

## Layout
1. **Question bar** — example buttons, question, place / lat-lon, role; record IRI and area under "Record or area".
2. **Outcome banner** — what the evidence shows (hazards / fire activity / clear / clarification). Not a risk score.
3. **KPI strip** — FWI danger class with the 6-class scale, likely fires vs all detections (radius actually used),
   rules fired / checked / unknown, evidence + share of cited sentences, time / LLM calls / tokens.
4. **Map | Answer** — detections coloured by filter category and sized by FRP, search radius ring, query point;
   answer sections with coloured citation badges (dashed red = cite not in the ledger), hazard cards with actions,
   rules that did not fire and rules that could not run.
5. **Tabs** — Fire weather (7-day FWI on danger bands from settings.yaml, components, noon weather),
   Detections (filterable table, distance, reason), Evidence (filter by kind / cited, SPARQL, payload),
   Agent trace (plan waves, notes incl. IORS rounds, time per stage, LLM and tool calls), Conversation.

## Replay without models
`wfmas ask "..." --place Sigiriya --json out.json`, then open `out.json` from the sidebar ("Open a saved trace").
Every screening can be saved with "Save trace" — useful for thesis screenshots and the viva.

`app/samples/SYNTHETIC_demo_trace.json` is **invented data** for trying the layout only (the banner says
"synthetic sample data"). Never use it for screenshots of results.

## What changed vs the previous version
- Map: removed `on_select` / `selection_mode` (only in newer Streamlit, likely why the map broke);
  correct hotspot fields (`acq_datetime`, `confidence_raw`, `category`, `reasons`, `enrichment`); category colours.
- Location and question in one form (no separate "Apply configuration" step that was easy to forget).
- `st.rerun()` moved out of the `try` block.
- Backend imported lazily, so saved traces open even when Ollama / GraphDB are down.
