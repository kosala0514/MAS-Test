"""FFOnto question answering: natural language -> CQ/SPARQL over GraphDB -> natural-language answer."""
