# RAG documents

Put the documents for general-knowledge answers here, for example:
- wildfire safety and evacuation guidance
- FWI system documentation (its charts and tables are indexed too)
- firefighting tactics / PPE manuals
- smoke and health guidance

Supported: .pdf (text, tables AND figures/charts/maps/diagrams, with `pip install pymupdf`), .txt, .md,
and .png/.jpg/.jpeg/.webp (indexed as figures, e.g. an infographic).

Then rebuild the index:  python -m qa.build_index --docs-only
Figures are described once by the vision model (`ollama pull qwen2.5vl:7b`) and cached in
qa/index/figure_descriptions.jsonl. This README is not indexed.
