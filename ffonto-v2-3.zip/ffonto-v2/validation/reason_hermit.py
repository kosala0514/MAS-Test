#!/usr/bin/env python3
"""
reason_hermit.py — run the HermiT reasoner from Python (no Protégé, no ROBOT).

Uses owlready2, which ships HermiT inside the package. It still needs a Java runtime
(`java -version` must work); install with:  pip install owlready2

    python validation/reason_hermit.py            # schema + data + negative tests
    python validation/reason_hermit.py --schema   # ontology modules only

Checks:
  1. schema   : core + vocabulary + danger rules are consistent, no unsatisfiable classes
  2. data     : the knowledge graph (data/kg_inferred.ttl) is consistent with the schema
  3. negative : every file in validation/owl-negative/ is detected as INCONSISTENT
Inferred types are written to build/hermit_inferred_types.tsv.
"""
import argparse, sys
from pathlib import Path
from rdflib import Graph

try:
    import owlready2
    from owlready2 import World, sync_reasoner_hermit, OwlReadyInconsistentOntologyError
except ImportError:
    sys.exit("pip install owlready2   (and make sure Java is installed: java -version)")

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
MODULES = ["ffonto-core.ttl", "ffonto-vocab.ttl", "danger-rules.ttl"]
# owlready2.JAVA_EXE = "/usr/lib/jvm/java-17-openjdk-amd64/bin/java"   # set if java is not on PATH


def to_ntriples(extra_files, name):
    """Merge the ontology modules (+ extra files) with rdflib and write N-Triples for owlready2."""
    g = Graph()
    for f in MODULES:
        g.parse(ROOT / "ontology" / f, format="turtle")
    for f in extra_files:
        g.parse(f, format="turtle")
    BUILD.mkdir(exist_ok=True)
    out = BUILD / f"{name}.nt"
    g.serialize(out, format="nt", encoding="utf-8")
    return out, len(g)


def run_hermit(nt_path):
    """Return (consistent: bool, unsatisfiable: list, world)."""
    w = World()
    onto = w.get_ontology("http://purl.org/ffonto/validation").load(
        fileobj=open(nt_path, "rb"), format="ntriples")
    try:
        with onto:
            sync_reasoner_hermit(w, infer_property_values=False, debug=0)
    except OwlReadyInconsistentOntologyError:
        return False, [], w
    unsat = [c.iri for c in w.inconsistent_classes()]
    return True, unsat, w


def check(label, extra, name):
    nt, n = to_ntriples(extra, name)
    consistent, unsat, w = run_hermit(nt)
    print(f"\n=== {label}  ({n} triples)")
    if not consistent:
        print("    FAIL: ontology is INCONSISTENT")
        print("    (for an explanation run ROBOT `explain`, or open build/%s.nt in Protégé)" % name)
        return False, w
    if unsat:
        print(f"    FAIL: {len(unsat)} unsatisfiable classes:")
        for c in unsat:
            print("      -", c)
        return False, w
    print("    PASS: consistent, no unsatisfiable classes")
    return True, w


def dump_inferred_types(w):
    rows = []
    for ind in w.individuals():
        asserted = set(ind.is_a)
        for cls in ind.INDIRECT_is_a:
            if cls not in asserted and hasattr(cls, "iri") and cls.iri.startswith(("http://purl.org/ffonto",
                                                                                   "http://www.w3.org/ns/")):
                rows.append(f"{ind.iri}\t{cls.iri}")
    (BUILD / "hermit_inferred_types.tsv").write_text("individual\tinferred_class\n" + "\n".join(sorted(rows)),
                                                    encoding="utf-8")
    print(f"    {len(rows)} inferred type assertions -> build/hermit_inferred_types.tsv")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--schema", action="store_true", help="only check the ontology modules")
    a = ap.parse_args()
    ok = True

    passed, _ = check("1. Schema (core + vocabulary + danger rules)", [], "schema")
    ok &= passed
    if a.schema:
        sys.exit(0 if ok else 1)

    kg = ROOT / "data" / "kg_inferred.ttl"
    if kg.exists():
        passed, w = check("2. Data (knowledge graph + schema)", [kg], "schema_with_data")
        ok &= passed
        if passed:
            dump_inferred_types(w)
    else:
        print("\n=== 2. Data: SKIP – run `python scripts/run_cqs.py` first to create data/kg_inferred.ttl")

    print("\n=== 3. Negative tests (each must be INCONSISTENT)")
    for t in sorted((ROOT / "validation" / "owl-negative").glob("*.ttl")):
        nt, _ = to_ntriples([t], "negative")
        consistent, unsat, _ = run_hermit(nt)
        if consistent and not unsat:
            print(f"    FAIL: {t.name} was NOT detected")
            ok = False
        else:
            print(f"    PASS: {t.name} detected")

    print("\nALL HERMIT CHECKS PASSED" if ok else "\nSOME HERMIT CHECKS FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
