#!/usr/bin/env python3
"""
Scene-graph extraction with a local vision-language model (Ollama, default qwen2.5vl:7b).

For every image it writes
    data/scenes/scene_<stem>.json   entities (kind, count, state, activity, wears, position, relations) + attributes
and, if no image record exists yet for that file,
    data/raw/image_<stem>.json      a minimal image record (id, file, checksum, size) that the scene links to.
Then run  python scripts/lift.py  and reload GraphDB.

    python scripts/extract_scenes.py --images ~/datasets/ForestFire-VQA/images
    python scripts/extract_scenes.py --images DIR --limit 20          # try a few first
    python scripts/extract_scenes.py --images DIR --only forest_fire_020 forest_fire_093
    python scripts/extract_scenes.py --images DIR --overwrite         # redo existing scenes

The answer is constrained by a JSON schema whose enums come from the vocabulary (via prompts/scene_extraction_prompt.md),
so the model can only use concept names the ontology knows. Progress is resumable: existing scenes are skipped.
A log of every image (seconds, entity count, errors) is written to data/scenes/_extract_log.csv.
"""
import argparse
import base64
import csv
import hashlib
import io
import json
import re
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PROMPT_FILE = ROOT / "prompts" / "scene_extraction_prompt.md"
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
RELATIONS = ["near", "advancing_toward", "reached", "protects", "blocks"]


# ------------------------------------------------------------------ vocabulary from the generated prompt
def read_prompt():
    if not PROMPT_FILE.exists():
        sys.exit("prompts/scene_extraction_prompt.md not found – run: python scripts/make_prompt.py > prompts/scene_extraction_prompt.md")
    text = PROMPT_FILE.read_text(encoding="utf-8")
    body = text.split("\n---\n", 1)[-1].strip()
    return body


def section(body, title):
    m = re.search(rf"^## {re.escape(title)}[^\n]*\n(.*?)(?=^## |\Z)", body, flags=re.M | re.S)
    return m.group(1) if m else ""


def names(text):
    out = []
    for line in text.splitlines():
        line = re.sub(r"^\s*-\s*\*\*[^*]+\*\*:\s*", "", line.strip())
        out += [n.strip() for n in line.split(",") if re.fullmatch(r"[A-Za-z][A-Za-z0-9]*", n.strip())]
    return sorted(set(out))


def vocabulary(body):
    props = {}
    for line in section(body, "PROPERTY").splitlines():
        m = re.match(r"\s*-\s*\*\*(\w+)\*\*:\s*(.+)", line)
        if m:
            props[m.group(1)] = [v.strip() for v in m.group(2).split(",") if v.strip()]
    v = {"kind": names(section(body, "KIND")), "state": names(section(body, "STATE")),
         "activity": names(section(body, "ACTIVITY")), "wears": names(section(body, "PPE")),
         "position": names(section(body, "POSITION")), "properties": props}
    if not v["kind"] or not props:
        sys.exit("could not read the vocabulary lists from the prompt file – regenerate it with make_prompt.py")
    return v


def schema(v):
    arr = lambda enum: {"type": "array", "items": {"type": "string", "enum": enum}}
    ids = {"type": "array", "items": {"type": "string"}}
    entity = {"type": "object",
              "properties": {"id": {"type": "string"}, "kind": {"type": "string", "enum": v["kind"]},
                             "count": {"type": "integer"}, "state": arr(v["state"]), "activity": arr(v["activity"]),
                             "wears": arr(v["wears"]), "position": {"type": "string", "enum": v["position"]},
                             **{r: ids for r in RELATIONS}},
              "required": ["id", "kind"]}
    attrs = {"type": "object", "properties": {p: {"type": "string", "enum": vals} for p, vals in v["properties"].items()},
             "additionalProperties": False}
    return {"type": "object", "properties": {"entities": {"type": "array", "items": entity}, "attributes": attrs},
            "required": ["entities", "attributes"]}


# ------------------------------------------------------------------ image records
def existing_records(raw_dir):
    """file stem -> record_uuid for image records that already exist in data/raw."""
    out = {}
    for p in Path(raw_dir).glob("*.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if str(d.get("modality", "")).lower() != "image" or not d.get("record_uuid"):
            continue
        uri = (d.get("provenance") or {}).get("uri") or ""
        for key in {Path(uri).stem, str(d.get("image_id") or "")}:
            if key:
                out[key.lower()] = d["record_uuid"]
    return out


def image_bytes(path, max_side):
    """JPEG bytes, downscaled so the longest side is <= max_side (keeps GPU memory and time down)."""
    try:
        from PIL import Image
    except ImportError:
        return Path(path).read_bytes(), None
    im = Image.open(path)
    size = im.size
    im = im.convert("RGB")
    if max(im.size) > max_side:
        im.thumbnail((max_side, max_side))
    buf = io.BytesIO()
    im.save(buf, format="JPEG", quality=90)
    return buf.getvalue(), size


def minimal_image_record(path, size):
    data = Path(path).read_bytes()
    rec = {
        "schema_version": "1.0.0",
        "record_uuid": str(uuid.uuid5(uuid.NAMESPACE_URL, "ffonto:image:" + Path(path).name)),
        "modality": "Image",
        "image_id": Path(path).stem,
        "event_id": None,
        "source": "ForestFire-VQA",
        "capture_time_utc": None,
        "labels": [],
        "provenance": {"uri": str(Path(path).resolve()), "checksum_sha256": hashlib.sha256(data).hexdigest()},
        "license": None,
    }
    if size:
        rec["image_size_px"] = {"width": size[0], "height": size[1]}
    return rec


# ------------------------------------------------------------------ model call
def ask_vlm(url, model, prompt, img, fmt, timeout):
    import requests
    payload = {"model": model, "stream": False, "format": fmt, "options": {"temperature": 0},
               "messages": [{"role": "system", "content": prompt},
                            {"role": "user", "content": "Annotate this image. Return the JSON object only.",
                             "images": [base64.b64encode(img).decode("ascii")]}]}
    r = requests.post(f"{url}/api/chat", json=payload, timeout=timeout)
    if r.status_code >= 300:
        raise RuntimeError(f"Ollama {r.status_code}: {r.text[:300]}")
    return json.loads(r.json()["message"]["content"])


def clean(answer, v):
    """Keep only valid names, unique ids and relations that point to existing entities."""
    ents, seen = [], set()
    for i, e in enumerate(answer.get("entities") or []):
        if e.get("kind") not in v["kind"]:
            continue
        eid = str(e.get("id") or f"e{i + 1}")
        if eid in seen:
            eid = f"e{i + 1}_{len(seen)}"
        seen.add(eid)
        out = {"id": eid, "kind": e["kind"]}
        if isinstance(e.get("count"), int) and e["count"] > 0:
            out["count"] = e["count"]
        for key in ("state", "activity", "wears"):
            vals = sorted({x for x in (e.get(key) or []) if x in v[key]})
            if vals:
                out[key] = vals
        if e.get("position") in v["position"]:
            out["position"] = e["position"]
        out["_rel"] = {r: [str(x) for x in (e.get(r) or [])] for r in RELATIONS}
        ents.append(out)
    for e in ents:
        for r, targets in e.pop("_rel").items():
            t = [x for x in targets if x in seen and x != e["id"]]
            if t:
                e[r] = t
    attrs = {p: val for p, val in (answer.get("attributes") or {}).items()
             if p in v["properties"] and val in v["properties"][p]}
    return ents, attrs


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", required=True, help="folder with the dataset images (searched recursively)")
    ap.add_argument("--model", default="qwen2.5vl:7b")
    ap.add_argument("--ollama", default="http://localhost:11434")
    ap.add_argument("--raw-dir", default=str(ROOT / "data" / "raw"))
    ap.add_argument("--scenes-dir", default=str(ROOT / "data" / "scenes"))
    ap.add_argument("--only", nargs="*", help="image stems to process (e.g. forest_fire_020)")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--overwrite", action="store_true")
    ap.add_argument("--max-side", type=int, default=1024)
    ap.add_argument("--timeout", type=int, default=300)
    a = ap.parse_args()

    prompt = read_prompt()
    v = vocabulary(prompt)
    fmt = schema(v)
    images = sorted(p for p in Path(a.images).expanduser().rglob("*") if p.suffix.lower() in IMAGE_EXT)
    if a.only:
        wanted = {s.lower() for s in a.only}
        images = [p for p in images if p.stem.lower() in wanted]
    if not images:
        sys.exit(f"no images found in {a.images}")
    raw_dir, scenes_dir = Path(a.raw_dir), Path(a.scenes_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)
    scenes_dir.mkdir(parents=True, exist_ok=True)
    records = existing_records(raw_dir)
    log_path = scenes_dir / "_extract_log.csv"
    new_log = not log_path.exists()
    done = 0
    with log_path.open("a", newline="", encoding="utf-8") as lf:
        log = csv.writer(lf)
        if new_log:
            log.writerow(["image", "status", "seconds", "entities", "attributes", "detail"])
        for p in images:
            if a.limit and done >= a.limit:
                break
            out = scenes_dir / f"scene_{p.stem}.json"
            if out.exists() and not a.overwrite:
                continue
            t0 = time.time()
            try:
                img, size = image_bytes(p, a.max_side)
                rid = records.get(p.stem.lower())
                if not rid:
                    rec = minimal_image_record(p, size)
                    (raw_dir / f"image_{p.stem}.json").write_text(json.dumps(rec, indent=1), encoding="utf-8")
                    rid = records[p.stem.lower()] = rec["record_uuid"]
                ents, attrs = clean(ask_vlm(a.ollama, a.model, prompt, img, fmt, a.timeout), v)
                scene = {"scene_id": f"scene_{p.stem}", "image_record_uuid": rid,
                         "extractor": {"model_name": a.model, "model_version": "ollama"},
                         "human_validated": False, "entities": ents, "attributes": attrs}
                out.write_text(json.dumps(scene, indent=1), encoding="utf-8")
                sec = time.time() - t0
                log.writerow([p.name, "ok", f"{sec:.1f}", len(ents), len(attrs), ""])
                done += 1
                print(f"[{done}] {p.name}: {len(ents)} entities, {len(attrs)} attributes ({sec:.1f}s)")
            except Exception as e:                   # one bad image never stops the batch
                log.writerow([p.name, "error", f"{time.time() - t0:.1f}", 0, 0, str(e)[:300]])
                print(f"  ! {p.name}: {e}")
            lf.flush()
    print(f"\n{done} scenes written to {scenes_dir}. Next: python scripts/lift.py && python graphdb/load_graphdb.py")


if __name__ == "__main__":
    main()
