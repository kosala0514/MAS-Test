"""Compact text-to-SPARQL: the fallback when no competency question (CQ) fits the question.

Goal: a correct, standard SPARQL query from a prompt that uses only 30-40 % of the model's context window.

Pipeline (one LLM call, at most `max_repairs` more):

  1  Catalog (built once, cached): structure-aware chunks of the knowledge sources
       class cards     one per ontology class:   ffo:SatelliteHotspot ⊂ ffo:Observation – label
       property cards  one per property:         ffo:acquiredAt: ffo:SatelliteHotspot → xsd:dateTime
       concept cards   one per SKOS concept:     ffv:Smoke "smoke" (alt: plume) ⊂ ffv:FireSign
       query cards     one per tested CQ:        CQ19 · question · vars · terms used   (+ full text kept outside)
  2  Retrieval and schema linking (no LLM): lexical match of the question against the cards (word stems,
     camelCase split, labels), boosted by the planner's CQ hints; then 1-hop expansion around the linked
     classes and the properties the top query uses
  3  Pruning: only the rule blocks that apply (selected record, date, live data, concept hierarchy);
     duplicate and superseded cards dropped
  4  Compression (deterministic, lossless for the query's meaning): the top query becomes a skeleton
     (no PREFIX lines, comments, label OPTIONALs, LIMIT); schema as one-line cards; prefixes added by code
  5  Memory pointers: the other candidate queries enter the prompt only as cards (id + summary); their
     full text stays in the catalog. In "patch" mode the model answers with a base query id plus edits,
     and code fetches the query by that pointer and applies the edits
  6  Token budget: blocks are added by priority until the prompt reaches `budget_share` of the context
     window (default 35 % of 8,192); whole cards only, never cut in the middle; required blocks always kept
  7  LLM call (sparql slot, JSON): {"sparql": ...} or {"base": "CQ19", "edits": [...]}
  8  Context binding by code: ?record, ?site, ?eventCode, ?date and the bounding box are bound with
     VALUES, so the model never writes an IRI, code or number it could get wrong
  9  Static check before execution: read-only form, balanced braces, every ffo:/ffv: term exists (with a
     closest-match suggestion), projected variables occur in WHERE, ?record used when a record is selected
 10  Execution through the guarded tool; repair once with exact feedback (static problems, GraphDB error,
     0 rows, or too many rows for one record)
"""
from __future__ import annotations

import difflib
import json
import math
import re
from dataclasses import asdict, dataclass, field

CHARS_PER_TOKEN = 3.0          # conservative for SPARQL/IRIs (prose is ~4); real counts come back from Ollama
STD_PREFIXES = {
    "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "xsd": "http://www.w3.org/2001/XMLSchema#", "owl": "http://www.w3.org/2002/07/owl#",
    "skos": "http://www.w3.org/2004/02/skos/core#", "prov": "http://www.w3.org/ns/prov#",
    "sosa": "http://www.w3.org/ns/sosa/", "geo": "http://www.opengis.net/ont/geosparql#",
    "dcterms": "http://purl.org/dc/terms/",
}
STOP = {"the", "a", "an", "of", "and", "or", "is", "are", "was", "were", "in", "on", "at", "to", "for", "with", "by",
        "from", "this", "that", "it", "its", "be", "as", "there", "any", "what", "which", "how", "many", "much",
        "does", "do", "did", "has", "have", "had", "can", "show", "list", "give", "me", "all", "about", "near",
        "record", "selected", "image", "audio", "please", "tell", "visible", "some"}
_PNAME = re.compile(r"(?<![\w<\"'#])((?:ffo|ffv|ffonto|ffontov|skos|rdfs|rdf|xsd|owl|prov|sosa|geo|dcterms)):([A-Za-z_](?:[\w.-]*[\w-])?)")
_VAR = re.compile(r"\?([A-Za-z_]\w*)")


def est_tokens(text: str) -> int:
    return math.ceil(len(text or "") / CHARS_PER_TOKEN)


def _stems(text: str) -> set[str]:
    text = re.sub(r"([a-z])([A-Z])", r"\1 \2", text or "")          # camelCase -> camel Case
    words = re.findall(r"[a-zA-Z]{3,}", text.lower())
    return {w[:5] for w in words if w not in STOP}


# ------------------------------------------------------------------------------ 1 catalog (chunks)
@dataclass
class Card:
    kind: str                      # class | prop | concept | query
    id: str                        # ffo:SatelliteHotspot, CQ19, ...
    text: str                      # one compact line for the prompt
    words: list[str] = field(default_factory=list)
    links: list[str] = field(default_factory=list)   # related ids (domain/range, parent, terms used)
    full: str | None = None        # queries: the full tested SPARQL (pointer target)
    intents: list[str] = field(default_factory=list)


@dataclass
class Catalog:
    prefixes: dict[str, str]
    cards: list[Card]
    extra_terms: list[str] = field(default_factory=list)   # other declared ffo:/ffv: terms (individuals ...)

    @property
    def by_id(self) -> dict[str, Card]:
        if not hasattr(self, "_by"):
            self._by = {c.id: c for c in self.cards}
        return self._by

    def known_terms(self) -> set[str]:
        return {c.id for c in self.cards if c.kind in ("class", "prop", "concept")} | set(self.extra_terms)

    def to_dict(self) -> dict:
        return {"prefixes": self.prefixes, "cards": [asdict(c) for c in self.cards], "extra_terms": self.extra_terms}

    @staticmethod
    def from_dict(d: dict) -> "Catalog":
        return Catalog(d["prefixes"], [Card(**c) for c in d["cards"]], list(d.get("extra_terms") or []))

    def stats(self) -> dict:
        from collections import Counter

        n = Counter(c.kind for c in self.cards)
        full = sum(est_tokens(c.full or "") for c in self.cards if c.kind == "query")
        return {"cards": dict(n), "card_tokens": sum(est_tokens(c.text) for c in self.cards),
                "full_query_tokens": full}


def short(iri: str, prefixes: dict[str, str]) -> str:
    for p, ns in sorted(prefixes.items(), key=lambda kv: -len(kv[1])):
        if iri.startswith(ns):
            return f"{p}:{iri[len(ns):]}"
    return f"<{iri}>"


def build_catalog(class_rows: list[dict], prop_rows: list[dict], concept_rows: list[dict], queries: list[dict],
                  prefixes: dict[str, str], extra_iris: list[str] | None = None) -> Catalog:
    """Rows from the ontology / vocab graphs (see SCHEMA_QUERIES) and the tested queries:
    queries = [{id, question, sparql, intents?, examples?}]."""
    px = {**STD_PREFIXES, **prefixes}
    canon = {k: v for k, v in px.items() if k not in ("ffonto", "ffontov", "ffd")}   # ffo:/ffv: in the prompt
    s = lambda v: short(v, canon) if v else None  # noqa: E731
    cards: list[Card] = []
    cls: dict[str, dict] = {}
    for r in class_rows:
        c = s(r.get("c"))
        if not c or c.startswith("<"):
            continue
        e = cls.setdefault(c, {"label": r.get("label") or "", "sup": set()})
        if r.get("sup") and not str(r["sup"]).startswith("_:"):
            e["sup"].add(s(r["sup"]))
    for c, e in sorted(cls.items()):
        sup = ", ".join(sorted(x for x in e["sup"] if x and not x.startswith("<")))
        lab = (e["label"] or "")[:60]
        cards.append(Card("class", c, f"{c}{' ⊂ ' + sup if sup else ''}{' – ' + lab if lab else ''}",
                          sorted(_stems(c.split(':')[1] + ' ' + lab)), sorted(x for x in e["sup"] if x)))
    props: dict[str, dict] = {}
    for r in prop_rows:
        p = s(r.get("p"))
        if not p or p.startswith("<"):
            continue
        e = props.setdefault(p, {"label": r.get("label") or "", "dom": set(), "rng": set()})
        for k, key in (("domain", "dom"), ("range", "rng")):
            v = r.get(k)
            if v and not str(v).startswith("_:"):
                e[key].add(s(v))
    for p, e in sorted(props.items()):
        dom = " | ".join(sorted(e["dom"])) or "?"
        rng = " | ".join(sorted(e["rng"])) or "?"
        lab = (e["label"] or "")[:40]
        txt = f"{p}: {dom} → {rng}" + (f" ({lab})" if lab and lab.lower() != re.sub(r'([a-z])([A-Z])', r'\1 \2', p.split(':')[1]).lower() else "")
        cards.append(Card("prop", p, txt, sorted(_stems(p.split(':')[1] + ' ' + lab)), sorted(e["dom"] | e["rng"])))
    con: dict[str, dict] = {}
    for r in concept_rows:
        c = s(r.get("c"))
        if not c or c.startswith("<"):
            continue
        e = con.setdefault(c, {"pref": r.get("pref") or "", "alt": set(), "broader": set()})
        if r.get("alt"):
            e["alt"].add(str(r["alt"]))
        if r.get("broader"):
            e["broader"].add(s(r["broader"]))
    for c, e in sorted(con.items()):
        alt = ", ".join(sorted(e["alt"])[:3])
        b = ", ".join(sorted(e["broader"]))
        txt = f'{c} "{e["pref"]}"' + (f" (alt: {alt})" if alt else "") + (f" ⊂ {b}" if b else "")
        cards.append(Card("concept", c, txt, sorted(_stems(c.split(':')[1] + ' ' + e["pref"] + ' ' + alt)),
                          sorted(e["broader"])))
    for q in queries:
        sk = skeleton(q["sparql"])
        terms = sorted({f"{a}:{b}" for a, b in _PNAME.findall(sk) if a in ("ffo", "ffv", "ffonto", "ffontov")})
        terms = [t.replace("ffonto:", "ffo:").replace("ffontov:", "ffv:") for t in terms]
        vars_ = select_vars(q["sparql"])
        ex = " ".join(q.get("examples") or [])
        txt = f"{q['id']} · {q['question'][:90]} · returns {' '.join('?' + v for v in vars_[:6]) or '?'}" \
              + (f" · uses {', '.join(terms[:5])}" if terms else "")
        cards.append(Card("query", q["id"], txt, sorted(_stems(q["question"] + " " + ex)), terms, q["sparql"],
                          list(q.get("intents") or [])))
    extra = sorted({s(i) for i in extra_iris or [] if s(i) and not s(i).startswith("<")})
    extra = [t.replace("ffonto:", "ffo:").replace("ffontov:", "ffv:") for t in extra]
    return Catalog(px, cards, extra)


SCHEMA_QUERIES = {
    "classes": """PREFIX owl: <http://www.w3.org/2002/07/owl#> PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
SELECT ?c ?label ?sup WHERE {{ GRAPH <{onto}> {{ ?c a owl:Class . FILTER(isIRI(?c))
  OPTIONAL {{ ?c rdfs:label ?label FILTER(lang(?label) = "" || langMatches(lang(?label), "en")) }}
  OPTIONAL {{ ?c rdfs:subClassOf ?sup FILTER(isIRI(?sup)) }} }} }}""",
    "properties": """PREFIX owl: <http://www.w3.org/2002/07/owl#> PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
SELECT ?p ?label ?domain ?range WHERE {{ GRAPH <{onto}> {{
  VALUES ?k {{ owl:ObjectProperty owl:DatatypeProperty }} ?p a ?k . FILTER(isIRI(?p))
  OPTIONAL {{ ?p rdfs:label ?label FILTER(lang(?label) = "" || langMatches(lang(?label), "en")) }}
  OPTIONAL {{ {{ ?p rdfs:domain ?domain FILTER(isIRI(?domain)) }} UNION
             {{ ?p rdfs:domain/owl:unionOf/rdf:rest*/rdf:first ?domain }} }}
  OPTIONAL {{ {{ ?p rdfs:range ?range FILTER(isIRI(?range)) }} UNION
             {{ ?p rdfs:range/owl:unionOf/rdf:rest*/rdf:first ?range }} }} }} }}""",
    "concepts": """PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
SELECT ?c ?pref ?alt ?broader WHERE {{ GRAPH <{vocab}> {{ ?c a skos:Concept ; skos:prefLabel ?pref .
  FILTER(lang(?pref) = "" || langMatches(lang(?pref), "en"))
  OPTIONAL {{ ?c skos:altLabel ?alt FILTER(lang(?alt) = "" || langMatches(lang(?alt), "en")) }}
  OPTIONAL {{ ?c skos:broader ?broader }} }} }}""",
}


# ------------------------------------------------------------------------------ 4 compression
def skeleton(sparql: str) -> str:
    """The query's meaning without its boilerplate: no PREFIX lines, comments, label-only OPTIONALs, LIMIT,
    blank lines; whitespace collapsed."""
    lines = []
    for ln in (sparql or "").splitlines():
        s = ln.split(" #")[0].rstrip() if not ln.strip().startswith("#") else ""
        if not s.strip() or re.match(r"\s*PREFIX\s", s, re.I):
            continue
        if re.match(r"\s*OPTIONAL\s*\{\s*\?\w+\s+(rdfs:label|skos:prefLabel)\s+\?\w+\s*\.?\s*\}\s*$", s, re.I):
            continue
        lines.append(re.sub(r"\s+", " ", s.strip()))
    q = "\n".join(lines)
    return re.sub(r"\n?\s*LIMIT\s+\d+\s*$", "", q, flags=re.I)


def select_vars(sparql: str) -> list[str]:
    m = re.search(r"\bSELECT\s+(DISTINCT\s+|REDUCED\s+)?(.*?)\s*(WHERE|\{)", sparql or "", re.I | re.S)
    if not m or m.group(2).strip() == "*":
        return []
    out = []
    for v in re.findall(r"\(\s*[^()]*?\bAS\s+\?(\w+)\s*\)|\?(\w+)", m.group(2), re.I):
        name = v[0] or v[1]
        if name not in out:
            out.append(name)
    return out


# ------------------------------------------------------------------------------ 2 retrieval + linking
def rank(cards: list[Card], q_stems: set[str], boost: dict[str, float] | None = None) -> list[tuple[float, Card]]:
    boost = boost or {}
    out = []
    for c in cards:
        overlap = len(q_stems & set(c.words))
        score = overlap / (1 + 0.15 * len(c.words)) * 3 + overlap + boost.get(c.id, 0.0)
        if score > 0:
            out.append((score, c))
    return sorted(out, key=lambda x: (-x[0], x[1].id))


def link_schema(cat: Catalog, question: str, hints: list[str], intent: str | None = None,
                max_queries: int = 3, max_schema: int = 14, max_concepts: int = 8) -> dict:
    """Retrieve candidate queries, schema cards and concept cards for the question (no LLM)."""
    qs = _stems(question)
    by = cat.by_id
    queries = [c for c in cat.cards if c.kind == "query"]
    if intent:                                    # prune queries that never serve this intent (live CQs list them)
        queries = [c for c in queries if not c.intents or intent in c.intents]
    boost = {h: 6.0 - i for i, h in enumerate(hints[:5])}           # planner hints first, in their order
    ranked_q = [c for _, c in rank(queries, qs, boost)]
    seen, top_q = set(), []
    for c in ranked_q:                            # one card per distinct query
        if c.id not in seen:
            seen.add(c.id)
            top_q.append(c)
    top_q = top_q[:max_queries]
    concepts = [c for _, c in rank([c for c in cat.cards if c.kind == "concept"], qs)][:max_concepts]
    schema_pool = [c for c in cat.cards if c.kind in ("class", "prop")]
    ranked_s = [c for _, c in rank(schema_pool, qs)]
    chosen: list[Card] = []
    must = []
    if top_q:                                     # the top query's own terms are always worth knowing
        must = [by[t] for t in top_q[0].links if t in by and by[t].kind in ("class", "prop")]
    for c in must + ranked_s:
        if c not in chosen:
            chosen.append(c)
    # 1-hop expansion: domain/range classes of linked properties, properties of linked classes
    linked_classes = {c.id for c in chosen if c.kind == "class"} | {x for c in chosen if c.kind == "prop" for x in c.links}
    for cid in sorted(linked_classes):
        if cid in by and by[cid] not in chosen:
            chosen.append(by[cid])
    for c in schema_pool:
        if c.kind == "prop" and c not in chosen and set(c.links) & linked_classes and set(c.words) & qs:
            chosen.append(c)
    return {"queries": top_q, "schema": chosen[: max_schema + len(must)], "concepts": concepts}


# ------------------------------------------------------------------------------ 3 pruning: rule blocks
RULES_BASE = """You write one SPARQL 1.1 SELECT query for the FFOnto knowledge graph (GraphDB).
Use ONLY the classes, properties and concepts listed below; never invent a term.
Do not write PREFIX lines (they are added for you) and do not add LIMIT.
Use OPTIONAL for information that may be missing; use DISTINCT when rows can repeat."""
RULES_RECORD = "A record is selected: start the pattern from ?record (it is bound for you; never write its IRI)."
RULES_DATE = "A date is given: compare the record's date with ?date (bound for you as xsd:date)."
RULES_EVENT = "An event is given: match it with ?eventCode (bound for you)."
RULES_SITE = "A site is given: use ?site (bound for you)."
RULES_LIVE = ("Live satellite data: ?h a ffo:SatelliteHotspot ; ffo:latitude ?lat ; ffo:longitude ?lon ; "
              "ffo:acquiredAt ?t . The area is bound for you as ?lat_min ?lat_max ?lon_min ?lon_max: "
              "FILTER(?lat >= ?lat_min && ?lat <= ?lat_max && ?lon >= ?lon_min && ?lon <= ?lon_max).")
RULES_HIER = "Concepts form a hierarchy: use skos:broader* to include narrower concepts."
CONTRACT_WRITE = 'Reply JSON only: {"sparql": "<the query>"}'
CONTRACT_PATCH = ('Reply JSON only. Either adapt one listed query by id:\n'
                  '{"base": "<query id>", "edits": [{"replace": "<term or text>", "with": "<new>"} | '
                  '{"add": "<triple pattern or FILTER line>"} | {"remove": "<text of a line>"}], '
                  '"select": ["?var", ...] (optional)}\n'
                  'or, if no listed query is close, write a new one: {"sparql": "<the query>"}')


@dataclass
class Block:
    name: str
    text: str
    priority: int                 # 0 = required, then 1 (most useful) ... 9
    tokens: int = 0


def build_prompt(question: str, linked: dict, ctx: dict, mode: str = "write", context_window: int = 8192,
                 budget_share: float = 0.35, feedback: str | None = None) -> tuple[str, str, dict]:
    """Assemble system + user prompt under the token budget. Returns (system, user, stats)."""
    budget = int(context_window * budget_share)
    live = bool(ctx.get("bbox")) or any("SatelliteHotspot" in c.id or "Hotspot" in c.id for c in linked["schema"])
    rules = [RULES_BASE]
    if ctx.get("record"):
        rules.append(RULES_RECORD)
    if ctx.get("date"):
        rules.append(RULES_DATE)
    if ctx.get("event"):
        rules.append(RULES_EVENT)
    if ctx.get("site"):
        rules.append(RULES_SITE)
    if live:
        rules.append(RULES_LIVE)
    if any(c.links for c in linked["concepts"]):
        rules.append(RULES_HIER)
    system = "\n".join(rules) + "\n" + (CONTRACT_PATCH if mode == "patch" else CONTRACT_WRITE)
    blocks: list[Block] = [Block("question", f"Question: {question}", 0)]
    if feedback:
        blocks.append(Block("feedback", f"Your previous query had problems, fix them:\n{feedback}", 0))
    qs = linked["queries"]
    if qs:
        blocks.append(Block(f"example:{qs[0].id}", f"Closest tested query ({qs[0].id}: {qs[0].text.split(' · ')[1]}):\n"
                            f"{skeleton(qs[0].full or '')}", 1))
        for c in qs[1:]:
            blocks.append(Block(f"card:{c.id}", f"Other query (pointer only): {c.text}", 6))
    for i, c in enumerate(linked["schema"]):
        blocks.append(Block(f"schema:{c.id}", c.text, 2 if i < 6 else 4))
    for i, c in enumerate(linked["concepts"]):
        blocks.append(Block(f"concept:{c.id}", c.text, 3 if i < 4 else 5))
    for b in blocks:
        b.tokens = est_tokens(b.text) + 1
    used = est_tokens(system) + 8
    kept, dropped = [], []
    for b in sorted(blocks, key=lambda x: x.priority):      # stable: keeps relevance order inside a priority
        if b.priority == 0 or used + b.tokens <= budget:
            kept.append(b)
            used += b.tokens
        else:
            dropped.append(b.name)
    order = {"question": 0, "feedback": 9}
    sections = {"example": [], "card": [], "schema": [], "concept": []}
    for b in kept:
        k = b.name.split(":")[0]
        if k in sections:
            sections[k].append(b.text)
    parts = []
    if sections["schema"]:
        parts.append("Schema (term: domain → range):\n" + "\n".join(sections["schema"]))
    if sections["concept"]:
        parts.append("Concepts:\n" + "\n".join(sections["concept"]))
    parts += sections["example"] + sections["card"]
    parts += [b.text for b in sorted(kept, key=lambda x: order.get(x.name, 5)) if b.name in order]
    user = "\n\n".join(parts)
    stats = {"budget_tokens": budget, "est_tokens": est_tokens(system) + est_tokens(user),
             "share_of_window": round((est_tokens(system) + est_tokens(user)) / context_window, 3),
             "kept": [b.name for b in kept], "dropped": dropped, "mode": mode,
             "rule_blocks": len(rules)}
    return system, user, stats


# ------------------------------------------------------------------------------ 5 pointer + patch
def apply_patch(cat: Catalog, out: dict) -> tuple[str | None, list[str]]:
    """{"base": id, "edits": [...], "select": [...]} -> full query (fetched by pointer) with the edits applied."""
    base = cat.by_id.get(str(out.get("base", "")).strip())
    if not base or base.kind != "query" or not base.full:
        return None, [f"unknown base query {out.get('base')!r}; use one of the listed ids or write a new query"]
    q = re.sub(r"\n?\s*LIMIT\s+\d+\s*$", "", base.full.strip(), flags=re.I)
    problems = []
    for e in out.get("edits") or []:
        if not isinstance(e, dict):
            continue
        if "replace" in e:
            old, new = str(e["replace"]), str(e.get("with", ""))
            if old and old in q:
                q = q.replace(old, new)
            else:
                problems.append(f"edit replace: '{old}' is not in {base.id}")
        elif "add" in e:
            line = str(e["add"]).strip()
            i = q.rfind("}")
            q = q[:i].rstrip() + f"\n  {line}\n" + q[i:] if i > 0 else q
        elif "remove" in e:
            old = str(e["remove"]).strip()
            lines = [ln for ln in q.splitlines() if old not in ln]
            if len(lines) == len(q.splitlines()):
                problems.append(f"edit remove: '{old}' is not in {base.id}")
            q = "\n".join(lines)
    sel = out.get("select")
    if isinstance(sel, list) and sel:
        vs = " ".join(v if str(v).startswith("?") else f"?{v}" for v in sel)
        q = re.sub(r"(\bSELECT\s+(?:DISTINCT\s+|REDUCED\s+)?)(.*?)(\s*(?:WHERE|\{))", lambda m: m.group(1) + vs + m.group(3),
                   q, count=1, flags=re.I | re.S)
    return q, problems


# ------------------------------------------------------------------------------ 8 context binding
def bind_context(q: str, ctx: dict) -> tuple[str, dict]:
    """VALUES for the context variables the query uses, inserted at the top of WHERE."""
    vals, applied = [], {}
    if ctx.get("record") and "?record" in q:
        vals.append(f"VALUES ?record {{ <{ctx['record']}> }}")
        applied["record"] = ctx["record"]
    if ctx.get("site") and "?site" in q and str(ctx["site"]).startswith(("http", "urn")):
        vals.append(f"VALUES ?site {{ <{ctx['site']}> }}")
        applied["site"] = ctx["site"]
    if ctx.get("event") and "?eventCode" in q:
        vals.append(f'VALUES ?eventCode {{ "{ctx["event"]}" }}')
        applied["event"] = ctx["event"]
    if ctx.get("date") and "?date" in q and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(ctx["date"])):
        vals.append(f'VALUES ?date {{ "{ctx["date"]}"^^<http://www.w3.org/2001/XMLSchema#date> }}')
        applied["date"] = ctx["date"]
    bb = ctx.get("bbox")
    if bb and all(f"?{v}" in q for v in ("lat_min", "lat_max", "lon_min", "lon_max")):
        w, s, e, n = bb
        vals.append(f"VALUES (?lat_min ?lat_max ?lon_min ?lon_max) {{ ({s} {n} {w} {e}) }}")
        applied["bbox"] = bb
    if vals:
        m = re.search(r"\bWHERE\s*\{|\{", q, re.I)
        if m:
            q = q[:m.end()] + "\n  " + "\n  ".join(vals) + q[m.end():]
    return q, applied


def add_prefixes(q: str, prefixes: dict[str, str]) -> str:
    used = {p for p, _ in _PNAME.findall(q)}
    decl = [f"PREFIX {p}: <{prefixes[p]}>" for p in sorted(used) if p in prefixes
            and not re.search(rf"PREFIX\s+{p}:", q, re.I)]
    return ("\n".join(decl) + "\n" + q) if decl else q


# ------------------------------------------------------------------------------ 9 static check
_UPDATE = re.compile(r"\b(INSERT|DELETE|LOAD|CLEAR|DROP|CREATE|ADD|MOVE|COPY|WITH|SERVICE)\b", re.I)


def static_check(q: str, cat: Catalog, ctx: dict) -> list[str]:
    problems = []
    body = re.sub(r'"(?:[^"\\]|\\.)*"', '""', q or "")
    if not re.search(r"\b(SELECT|ASK)\b", body, re.I):
        problems.append("no SELECT (or ASK) query")
    if _UPDATE.search(re.sub(r"<[^>]*>", "", body)):
        problems.append("only read-only SELECT queries are allowed")
    if body.count("{") != body.count("}"):
        problems.append(f"unbalanced braces ({body.count('{')} '{{' vs {body.count('}')} '}}')")
    known = cat.known_terms()
    norm = lambda p, l: f"{'ffo' if p == 'ffonto' else 'ffv' if p == 'ffontov' else p}:{l}"  # noqa: E731
    unknown = sorted({norm(p, l) for p, l in _PNAME.findall(body) if p in ("ffo", "ffv", "ffonto", "ffontov")
                      and norm(p, l) not in known})
    for u in unknown[:6]:
        close = difflib.get_close_matches(u, sorted(known), n=2, cutoff=0.6)
        problems.append(f"unknown term {u}" + (f"; did you mean {' or '.join(close)}?" if close else ""))
    where = body[body.lower().find("where"):] if "where" in body.lower() else body
    for v in select_vars(body):
        if f"?{v}" not in where.split("{", 1)[-1] and not re.search(rf"\bAS\s+\?{v}\b", body, re.I):
            problems.append(f"?{v} is selected but never used in WHERE")
    if ctx.get("record") and "?record" not in body:
        problems.append("a record is selected: the query must use ?record")
    return problems


def parse_reply(text_or_obj) -> dict:
    if isinstance(text_or_obj, dict):
        return text_or_obj
    try:
        return json.loads(text_or_obj)
    except Exception:  # noqa: BLE001
        return {}


# ------------------------------------------------------------------------------ 7-10 the generator loop
async def generate(question: str, cat: Catalog, chat_json, run_query, ctx: dict, hints: list[str] | None = None,
                   intent: str | None = None, mode: str = "write", context_window: int = 8192,
                   budget_share: float = 0.35, max_repairs: int = 1, max_rows_record: int = 40) -> dict:
    """chat_json(system, user) -> dict  (LLM, sparql slot);  run_query(sparql) -> {ok, rows, errors}.
    Returns {ok, sparql, rows, attempts, prompt_stats, problems, mode_used}."""
    linked = link_schema(cat, question, hints or [], intent)
    feedback, attempts, last = None, [], None
    for attempt in range(max_repairs + 1):
        system, user, stats = build_prompt(question, linked, ctx, mode, context_window, budget_share, feedback)
        try:
            out = parse_reply(await chat_json(system, user))
        except Exception as e:  # noqa: BLE001
            out = {}
            stats["llm_error"] = e.__class__.__name__
        problems: list[str] = []
        used_mode = "write"
        if out.get("base") and mode == "patch":
            q, problems = apply_patch(cat, out)
            used_mode = f"patch:{out.get('base')}"
        else:
            q = str(out.get("sparql") or "").strip()
            if not q:
                problems = ["no query in the reply (expected JSON with \"sparql\")"]
        rows, exec_err = [], None
        if q:
            problems += static_check(q, cat, ctx)
        if q and not problems:
            bound, applied = bind_context(q, ctx)
            final = add_prefixes(bound, cat.prefixes)
            res = run_query(final)
            if hasattr(res, "__await__"):
                res = await res
            if not res.get("ok"):
                exec_err = "; ".join(res.get("errors") or ["query failed"])[:300]
                problems.append(f"GraphDB rejected it: {exec_err}")
            else:
                rows = res.get("rows") or []
                last = {"sparql": res.get("sparql") or final, "rows": rows, "applied": applied}
                too_many = (ctx.get("record") or ctx.get("date")) and len(rows) > max_rows_record
                if rows and not too_many:
                    attempts.append({"mode": used_mode, "problems": [], "n_rows": len(rows), **stats})
                    return {"ok": True, **last, "attempts": attempts, "prompt_stats": stats, "mode_used": used_mode,
                            "problems": []}
                problems.append("the query returned no rows: check property directions and use skos:broader* for "
                                "concept hierarchies" if not rows else
                                f"the query returned {len(rows)} rows for one record/date: restrict it to ?record/?date")
        attempts.append({"mode": used_mode, "problems": problems, **stats})
        feedback = "\n".join(f"- {p}" for p in problems[:8]) + (f"\nQuery was:\n{skeleton(q)}" if q else "")
    if last:            # ran, but empty or too large: report what it returned
        return {"ok": True, **last, "attempts": attempts, "prompt_stats": attempts[-1], "mode_used": attempts[-1]["mode"],
                "problems": attempts[-1]["problems"]}
    return {"ok": False, "sparql": None, "rows": [], "attempts": attempts, "prompt_stats": attempts[-1],
            "problems": attempts[-1]["problems"]}
