"""Command line: wfmas ask | hotspots | fwi | rules | test-cqs | shacl | key-status | ontology |
golden-import | golden-partb | eval-filter | eval-rules"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .config import get_settings


def _print(obj) -> None:
    print(json.dumps(obj, indent=2, default=str))


def cmd_ask(a) -> int:
    from .agents.state import Request
    from .orchestrator import build

    orch = build(transport=a.transport)
    req = Request(a.question, record=a.record, lat=a.lat, lon=a.lon, place=a.place, area=a.area, role=a.role)

    async def go():
        try:
            return await orch.ask(req)
        finally:
            await orch.bus.aclose()

    res = asyncio.run(go())
    print(res.answer_markdown or "(no answer)")
    print(f"\n-- intent {res.intent} | urgency {res.urgency} | {res.timings.get('total', 0):.1f}s | "
          f"{len(res.tool_calls)} tool calls | {len(res.llm_calls)} LLM calls")
    for e in res.evidence:
        print(f"[{e['id']}] {e['source']}")
    for i in res.issues:
        print(f"! {i}")
    if a.json:
        with open(a.json, "w") as f:
            f.write(res.to_json())
        print(f"full trace written to {a.json}")
    return 0


def cmd_hotspots(a) -> int:
    from .tools.toolkit import Toolkit

    out = Toolkit().firms_get_hotspots(area=a.area, lat=a.lat, lon=a.lon, radius_km=a.radius_km, days=a.days,
                                       persistence=not a.no_persistence, store=not a.no_store,
                                       max_items=a.max_items)
    if a.brief:
        out = {k: v for k, v in out.items() if k != "hotspots"}
    _print(out)
    return 0


def cmd_fwi(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().weather_fwi(a.lat, a.lon, store=not a.no_store))
    return 0


def cmd_rules(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().kg_run_rules())
    return 0


def cmd_key(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().firms_key_status())
    return 0


def cmd_test_cqs(a) -> int:
    from .tools.toolkit import Toolkit

    tk = Toolkit()
    failed = 0
    tested = 0
    for cq in tk.catalog.by_id.values():
        if not cq.expect:
            continue
        tested += 1
        out = tk.kg_run_cq(cq.id, cq.expect.get("params", {}))
        rows = out.get("rows", [])
        ok = out.get("ok") and len(rows) >= int(cq.expect.get("min_rows", 1))
        for var, needle in (cq.expect.get("contains") or {}).items():
            ok = ok and any(needle in str(r.get(var, "")) for r in rows)
        failed += not ok
        print(f"{'PASS' if ok else 'FAIL'} {cq.id} ({len(rows)} rows){'' if ok else ' ' + str(out.get('errors', ''))}")
    print(f"{tested - failed}/{tested} CQ tests passed")
    return 1 if failed else 0


def cmd_ontology(a) -> int:
    """Load / unload the live-module .ttl files into GraphDB, or clear the live data graphs."""
    from pathlib import Path

    from .kg.store import make_store

    s = get_settings()
    store = make_store(s)
    if a.action == "clear-live":
        for g in ("live", "inferred_live"):
            store.clear_graph(s.graph(g))
            print(f"cleared {s.graph(g)}")
        return 0
    src = Path(a.dir) if a.dir else s.root / "ontology"
    pairs = [(src / "ffonto-live.ttl", s.graph("ontology")), (src / "ffonto-live-vocab.ttl", s.graph("vocab"))]
    for f, graph in pairs:
        if not f.exists():
            print(f"skip {f}: not found")
            continue
        if a.action == "load":
            store.insert_turtle(f.read_text(encoding="utf-8"), graph)
            print(f"loaded {f.name} into {graph}")
            continue
        from rdflib import BNode, Graph

        g = Graph().parse(f, format="turtle")
        triples = [t for t in g if not any(isinstance(x, BNode) for x in t)]
        for i in range(0, len(triples), 500):
            body = "\n".join(f"{t[0].n3()} {t[1].n3()} {t[2].n3()} ." for t in triples[i:i + 500])
            store.update(f"DELETE DATA {{ GRAPH <{graph}> {{\n{body}\n}} }}")
        print(f"removed {len(triples)} triples of {f.name} from {graph}")
    return 0


def cmd_golden_import(a) -> int:
    """Part A of the golden set from ffonto-v2's labelled ForestFire-VQA questions."""
    import random

    from .kg.ffonto_bridge import FfontoBridge

    s = get_settings()
    b = FfontoBridge(s)
    if not b.configured:
        print("set FFONTO_V2_PATH (or ffonto_v2.path) to your ffonto-v2 folder first")
        return 1
    items = b.all_examples()
    if a.group_by == "source":      # strict: all questions about one record land in the same split
        from .evaluation.holdout import grouped_split

        dev = {i for i, r in enumerate(grouped_split(items, a.dev, a.seed)) if r["split"] == "dev"}
        n_dev = len(dev)
    else:
        rnd = random.Random(a.seed)
        order = list(range(len(items)))
        rnd.shuffle(order)
        n_dev = int(len(items) * a.dev)
        dev = set(order[:n_dev])
    out = s.path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for i, e in enumerate(items):
            oos = (e["label"] or "").upper() == "OOS"
            f.write(json.dumps({
                "id": f"A{i + 1:04d}", "part": "A", "question": e["question"],
                "gold_intent": e["intent"], "gold_cq": None if oos else e["label"],
                "gold_route": "rag" if oos else "kg", "modality": e.get("modality"),
                "gold_answer": e.get("answer") or "", "source": e.get("source") or "",
                "split": "dev" if i in dev else "test"}, ensure_ascii=False) + "\n")
    n_kg = sum(1 for e in items if (e["label"] or "").upper() != "OOS")
    print(f"wrote {len(items)} items ({n_kg} KG, {len(items) - n_kg} general knowledge; "
          f"{n_dev} dev / {len(items) - n_dev} test) to {out}")
    print("labels are silver (keyword rules + review in FFVQA_CQ_mapping.xlsx): review the confusion pairs "
          "after the first run, as docs/EVALUATION.md in ffonto-v2 says")
    return 0


def _save_report(text: str, name: str) -> None:
    from datetime import datetime

    s = get_settings()
    out = s.root / s.get("paths.runs_dir", "runs") / f"{datetime.now():%Y%m%d_%H%M%S}_{name}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print(text)
    print(f"saved to {out}")


def cmd_golden_resplit(a) -> int:
    from .evaluation.holdout import resplit

    s = get_settings()
    files = resplit(s.path(a.dataset), [int(x) for x in a.seeds.split(",")], a.dev, s.path(a.out_dir),
                    by_group=not a.no_group)
    for f in files:
        print(f"wrote {f}")
    return 0


def cmd_overlap(a) -> int:
    from pathlib import Path

    from .evaluation.holdout import overlap_report

    s = get_settings()
    _save_report(overlap_report(s.path(a.dataset), Path(a.run) if a.run else None), "overlap")
    return 0


def cmd_splits_summary(a) -> int:
    from pathlib import Path

    from .evaluation.holdout import splits_summary

    _save_report(splits_summary([Path(x) for x in a.runs]), "splits_summary")
    return 0


def cmd_depth_sweep(a) -> int:
    from .evaluation.sweeps import depth_sweep

    s = get_settings()
    out = depth_sweep(str(s.path(a.dataset)), a.split, a.example_pool, [int(x) for x in a.ks.split(",")],
                      a.model, limit=a.limit)
    print((out / "summary.md").read_text())
    print(f"results in {out} (chart: depth.svg)")
    return 0


def cmd_plot_tradeoff(a) -> int:
    from datetime import datetime
    from pathlib import Path

    from .evaluation.sweeps import tradeoff

    s = get_settings()
    md, svg = tradeoff([Path(x) for x in a.runs], a.metric, a.system, a.x)
    out = s.root / s.get("paths.runs_dir", "runs") / f"{datetime.now():%Y%m%d_%H%M%S}_tradeoff"
    out.mkdir(parents=True, exist_ok=True)
    (out / "tradeoff.md").write_text(md, encoding="utf-8")
    (out / "tradeoff.svg").write_text(svg, encoding="utf-8")
    print(md)
    print(f"chart: {out / 'tradeoff.svg'}")
    return 0


def cmd_grade(a) -> int:
    from pathlib import Path

    from .evaluation.e2e import grade_run

    s = get_settings()
    out = grade_run(s, Path(a.run), a.judge_model, s.path(a.dataset) if a.dataset else None)
    print((out / "summary.md").read_text())
    print(f"graded: {out / 'items.jsonl'} (ungraded copy: items_nojudge.jsonl); human_check.csv written")
    return 0


def cmd_rescore(a) -> int:
    from pathlib import Path

    from .evaluation.rescore import rescore

    s = get_settings()
    out = rescore(s, Path(a.run), s.path(a.dataset) if a.dataset else None, s.path(a.keyfacts) if a.keyfacts else None,
                  [x.strip() for x in a.judges.split(",")] if a.judges else None, a.rubric, a.rubric_all,
                  a.rejudge, a.rubric_model)
    print((out / "rescore.md").read_text())
    print(f"rescored rows: {out / 'items_rescored.jsonl'}")
    return 0


def cmd_expert_sheet(a) -> int:
    from pathlib import Path

    from .evaluation.rescore import expert_sheet

    sheet, key = expert_sheet(Path(a.run), a.n, all_questions=a.all)
    print(f"give the expert: {sheet}\nkeep (do not share): {key}")
    return 0


def cmd_expert_agreement(a) -> int:
    from pathlib import Path

    from .evaluation.rescore import expert_agreement

    run = Path(a.run)
    md = expert_agreement(run, Path(a.sheet) if a.sheet else run / "expert_sheet.csv",
                          Path(a.key) if a.key else run / "expert_key.csv")
    (run / "expert_agreement.md").write_text(md, encoding="utf-8")
    print(md)
    return 0


def cmd_keyfacts_draft(a) -> int:
    from .evaluation.rescore import keyfacts_draft

    s = get_settings()
    out = keyfacts_draft(s, s.path(a.dataset), a.split, s.path(a.out), a.model, a.limit)
    print(f"wrote {out}: check and edit the key_facts column (facts separated by ';'), put y in 'reviewed'")
    return 0


def cmd_analyze(a) -> int:
    from pathlib import Path

    from .evaluation.analysis import analyze

    out = analyze(Path(a.run), a.baseline)
    print((out / "analysis.md").read_text())
    print(f"also: {out / 'cases.md'} (worked cases), calibration.svg / band_matrix.svg when available")
    return 0


def cmd_delay_analysis(a) -> int:
    from pathlib import Path

    from .evaluation.analysis import delay_analysis, measure_firms_age, run_latency

    s = get_settings()
    measured = None
    if a.measure_area:
        measured = measure_firms_age(s, a.measure_area, sources=a.source.split(",") if a.source else None)
    ans = run_latency(Path(a.run)) if a.run else a.answer_s
    ages = [float(x) for x in a.data_age_h.split(",")]
    if measured:
        ages = sorted({round(measured["min_h"], 1), round(measured["median_h"], 1), *ages})
    _save_report(delay_analysis(ans, ages, [float(x) for x in a.winds.split(",")], a.ros_share, measured), "delay_analysis")
    return 0


def cmd_t2s_ablation(a) -> int:
    from .evaluation.t2s_ablation import t2s_ablation

    s = get_settings()
    out = t2s_ablation(s, s.path(a.dataset), a.split, a.configs.split(",") if a.configs else None, a.model, a.limit,
                       a.example_pool, a.k, a.hints, a.window, a.share)
    print((out / "summary.md").read_text())
    print(f"results in {out}")
    return 0


def cmd_golden_partb(a) -> int:
    """Part B of the golden set: synthetic live/geospatial scenarios + end-to-end questions."""
    from .evaluation.scenarios import Generator, Spec, write_partb

    s = get_settings()
    spec = Spec.from_settings(s)
    info = write_partb(Generator(a.seed, spec).generate(a.per_family), s.path(a.out_dir), spec, a.dev)
    _print(info)
    return 0


def cmd_eval_filter(a) -> int:
    from datetime import date as _date, timedelta as _td
    from pathlib import Path

    from .evaluation import live_eval as le

    s = get_settings()
    sweep = [int(x) for x in a.sweep.split(",")] if a.sweep else None
    if a.firms_csv or a.fetch_area:
        sources = (a.source or "VIIRS_SNPP_SP").split(",")
        if a.firms_csv:
            hs = le.load_firms_files(a.firms_csv, a.source)
            label = ", ".join(a.firms_csv)
            first = min(h.acq_datetime.date() for h in hs)
            score_from = _date.fromisoformat(a.score_from) if a.score_from else first + _td(days=a.warmup)
        else:
            from .live.firms import FirmsClient

            end = _date.fromisoformat(a.end)
            res = FirmsClient(s).get_area(a.fetch_area, days=a.days + a.warmup, sources=sources, end=end)
            hs = res.hotspots
            score_from = end - _td(days=a.days - 1)
            label = f"{'+'.join(sources)} {a.fetch_area}, {a.days} days to {a.end}"
        ov = {}
        if a.min_days is not None:
            ov["persistence_min_days"] = a.min_days
        if a.keep_low_confidence:
            ov["viirs_low_confidence_is_weak"] = False
        out = le.eval_filter_firms(s, hs, use_static=a.static, label=label, score_from=score_from,
                                   land_mask=a.land_mask, sweep=sweep, overrides=ov)
    else:
        out = le.eval_filter_scenarios(s, le.scenarios_or_default(s, a.scenarios))
    print((Path(out["out_dir"]) / "summary.md").read_text())
    print(f"results in {out['out_dir']}")
    return 0


def cmd_eval_rules(a) -> int:
    from pathlib import Path

    from .evaluation import live_eval as le

    s = get_settings()
    out = le.eval_rules(s, le.scenarios_or_default(s, a.scenarios), tuple(a.modes.split(",")))
    print((Path(out["out_dir"]) / "summary.md").read_text())
    print(f"results in {out['out_dir']}")
    return 0


def cmd_where(a) -> int:
    from .tools.toolkit import Toolkit

    _print(Toolkit().geo_describe(a.lat, a.lon, a.instrument))
    return 0


def cmd_enrich_sample(a) -> int:
    from datetime import date as _date
    from pathlib import Path

    from .evaluation import live_eval as le
    from .live.classify import HotspotClassifier
    from .live.firms import FirmsClient

    s = get_settings()
    end = _date.fromisoformat(a.end) if a.end else None
    res = FirmsClient(s).get_area(a.area, days=a.days, sources=a.source.split(",") if a.source else None, end=end)
    HotspotClassifier.from_settings(s).classify(res.hotspots)
    _print(le.enrich_sample(s, res.hotspots, a.n, Path(a.out)))
    return 0


def cmd_eval_enrich(a) -> int:
    from pathlib import Path

    from .evaluation import live_eval as le

    out = le.eval_enrich(get_settings(), Path(a.labels))
    print((Path(out["out_dir"]) / "summary.md").read_text())
    print(f"results in {out['out_dir']}")
    return 0


def cmd_e2e(a) -> int:
    from .evaluation.e2e import main_e2e

    s = get_settings()
    out = main_e2e(s, a.part.upper(), [x.strip() for x in a.systems.split(",")], a.dataset, a.split, a.limit,
                   not a.no_judge, a.include_rag, a.qtypes.split(",") if a.qtypes else None, a.judge_model,
                   a.eval_store, a.eval_repo, a.model, a.example_pool, a.k, not a.no_monitor, a.tag)
    print((out / "summary.md").read_text())
    print(f"results in {out}")
    return 0


def cmd_e2e_compare(a) -> int:
    from pathlib import Path

    from .evaluation.e2e import compare_runs

    print(compare_runs([Path(x) for x in a.runs], a.system))
    return 0


def cmd_e2e_agreement(a) -> int:
    from pathlib import Path

    from .evaluation.e2e import judge_agreement

    _print(judge_agreement(Path(a.file)))
    return 0


def cmd_shacl(a) -> int:
    """Validate the live + inferred-live graphs against ontology/shapes-live.ttl (needs pyshacl)."""
    import requests
    from pyshacl import validate
    from rdflib import Graph

    s = get_settings()
    g = Graph()
    if s.get("graphdb.backend") == "memory":
        print("shacl: memory backend holds no persistent data; use GraphDB")
        return 1
    ep = f"{s.get('graphdb.url').rstrip('/')}/repositories/{s.get('graphdb.repository')}/statements"
    for name in ("live", "inferred_live", "vocab"):
        r = requests.get(ep, params={"context": f"<{s.graph(name)}>"}, headers={"Accept": "text/turtle"}, timeout=120)
        r.raise_for_status()
        g.parse(data=r.text, format="turtle")
    conforms, _, text = validate(g, shacl_graph=str(s.root / "ontology" / "shapes-live.ttl"), inference="none")
    print(text)
    return 0 if conforms else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="wfmas")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("ask", help="ask the multi-agent system a question")
    p.add_argument("question")
    p.add_argument("--record")
    p.add_argument("--lat", type=float)
    p.add_argument("--lon", type=float)
    p.add_argument("--place")
    p.add_argument("--area", help="'w,s,e,n', 'world' or ISO3 country code")
    p.add_argument("--role", default="analyst", choices=["analyst", "incident_commander", "public"])
    p.add_argument("--transport", default="inprocess", choices=["inprocess", "mcp"])
    p.add_argument("--json", help="write the full trace (plan, evidence, calls) to this file")
    p.set_defaults(fn=cmd_ask)

    p = sub.add_parser("hotspots", help="fetch + label FIRMS hotspots (and store them in the live graph)")
    p.add_argument("--area", help="'w,s,e,n', 'world' or ISO3 (default: configured region)")
    p.add_argument("--lat", type=float)
    p.add_argument("--lon", type=float)
    p.add_argument("--radius-km", type=float, default=25)
    p.add_argument("--days", type=int, default=1)
    p.add_argument("--max-items", type=int, default=50)
    p.add_argument("--no-store", action="store_true")
    p.add_argument("--no-persistence", action="store_true")
    p.add_argument("--brief", action="store_true")
    p.set_defaults(fn=cmd_hotspots)

    p = sub.add_parser("fwi", help="compute today's FWI at a point")
    p.add_argument("--lat", type=float, required=True)
    p.add_argument("--lon", type=float, required=True)
    p.add_argument("--no-store", action="store_true")
    p.set_defaults(fn=cmd_fwi)

    sub.add_parser("rules", help="run live rules R09-R12").set_defaults(fn=cmd_rules)
    sub.add_parser("key-status", help="FIRMS MAP_KEY usage").set_defaults(fn=cmd_key)
    sub.add_parser("test-cqs", help="run CQ tests (entries with an expect block)").set_defaults(fn=cmd_test_cqs)
    sub.add_parser("shacl", help="validate live graphs with SHACL").set_defaults(fn=cmd_shacl)

    p = sub.add_parser("ontology", help="load/unload the live-module ontology in GraphDB, or clear live data")
    p.add_argument("action", choices=["load", "unload", "clear-live"])
    p.add_argument("--dir", help="folder with ffonto-live.ttl / ffonto-live-vocab.ttl (default: ontology/)")
    p.set_defaults(fn=cmd_ontology)

    p = sub.add_parser("golden-import", help="build golden Part A from ffonto-v2's labelled questions")
    p.add_argument("--out", default="eval/datasets/golden_partA.jsonl")
    p.add_argument("--dev", type=float, default=0.3, help="share of items in the dev split")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--group-by", choices=["none", "source"], default="none",
                   help="source = questions about the same image/clip/weather row stay in one split (recommended)")
    p.set_defaults(fn=cmd_golden_import)

    p = sub.add_parser("golden-resplit", help="write resampled, record-grouped dev/test splits of a golden set")
    p.add_argument("--dataset", default="eval/datasets/golden_partA.jsonl")
    p.add_argument("--seeds", default="1,2,3")
    p.add_argument("--dev", type=float, default=0.3)
    p.add_argument("--out-dir", default="eval/datasets/splits")
    p.add_argument("--no-group", action="store_true", help="split per question instead of per record")
    p.set_defaults(fn=cmd_golden_resplit)

    p = sub.add_parser("overlap", help="structural overlap: record leakage, CQs dev vs test, seen/unseen accuracy")
    p.add_argument("--dataset", default="eval/datasets/golden_partA.jsonl")
    p.add_argument("--run", help="planner run folder (runs/..._planner...) for seen/unseen accuracy")
    p.set_defaults(fn=cmd_overlap)

    p = sub.add_parser("splits-summary", help="planner metrics over several split runs: mean ± sd")
    p.add_argument("runs", nargs="+")
    p.set_defaults(fn=cmd_splits_summary)

    p = sub.add_parser("depth-sweep", help="planner CQ accuracy for several numbers of few-shot examples (k)")
    p.add_argument("--dataset", default="eval/datasets/golden_partA.jsonl")
    p.add_argument("--split", default="test", choices=["dev", "test", "all"])
    p.add_argument("--example-pool", default="dev", choices=["all", "dev"])
    p.add_argument("--ks", default="1,3,5,8,15")
    p.add_argument("--model", required=True, help="one Ollama tag, e.g. qwen3:8b")
    p.add_argument("--limit", type=int)
    p.set_defaults(fn=cmd_depth_sweep)

    p = sub.add_parser("plot-tradeoff", help="accuracy vs latency (or model size) chart from planner or e2e runs")
    p.add_argument("runs", nargs="+", help="run folders")
    p.add_argument("--metric", help="default: cq_correct (planner runs) / correct (e2e runs)")
    p.add_argument("--system", default="mas", help="e2e runs: which system to plot")
    p.add_argument("--x", default="latency", choices=["latency", "size"])
    p.set_defaults(fn=cmd_plot_tradeoff)

    p = sub.add_parser("golden-partb", help="build golden Part B: synthetic live scenarios + questions")
    p.add_argument("--out-dir", default="eval/datasets")
    p.add_argument("--per-family", type=int, default=40, help="scenarios per family (decoy gets half)")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--dev", type=float, default=0.3)
    p.set_defaults(fn=cmd_golden_partb)

    p = sub.add_parser("eval-filter", help="evaluate the hotspot filter (Part B, or real FIRMS SP data)")
    p.add_argument("--scenarios", help="default: eval/datasets/golden_partB_scenarios.jsonl")
    p.add_argument("--firms-csv", nargs="+", help="FIRMS standard-processing CSV file(s) with a `type` column")
    p.add_argument("--fetch-area", help="fetch SP data for 'w,s,e,n' instead (uses your MAP_KEY)")
    p.add_argument("--end", help="last day to fetch, YYYY-MM-DD (SP data lags about 2-3 months)")
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--source", help="VIIRS_SNPP_SP (default), VIIRS_NOAA20_SP, MODIS_SP; comma-separate several")
    p.add_argument("--warmup", type=int, default=30, help="extra days fetched before the scored period, used "
                   "only as history for the persistence check (default 30, as in the live system)")
    p.add_argument("--score-from", help="with --firms-csv: first scored day (default: first day + warmup)")
    p.add_argument("--static", action="store_true", help="also use data/static_sources.csv")
    p.add_argument("--land-mask", help="GeoJSON of land polygons (offshore check), e.g. ne_10m_land.geojson")
    p.add_argument("--sweep", help="persistence thresholds to compare, e.g. 3,4,5,6,8")
    p.add_argument("--min-days", type=int, help="persistence threshold for this run (default: settings.yaml)")
    p.add_argument("--keep-low-confidence", action="store_true",
                   help="treat VIIRS low-confidence detections as possible fires (recall over precision)")
    p.set_defaults(fn=cmd_eval_filter)

    p = sub.add_parser("eval-rules", help="evaluate rules R09-R12 on Part B scenarios")
    p.add_argument("--scenarios", help="default: eval/datasets/golden_partB_scenarios.jsonl")
    p.add_argument("--modes", default="oracle,pipeline,nofilter")
    p.set_defaults(fn=cmd_eval_rules)

    p = sub.add_parser("e2e", help="end-to-end evaluation: system vs baselines / ablations")
    p.add_argument("--part", default="B", choices=["A", "B", "a", "b"])
    p.add_argument("--systems", default="mas,single_agent,llm_only",
                   help="mas, single_agent, llm_only, plain_rag, ffonto (Part A), mas-no_iors, mas-no_verifier, "
                        "mas-no_crm, mas-no_ialt, mas-no_filter, mas-no_rules")
    p.add_argument("--dataset", help="default: eval/datasets/golden_part{A,B}.jsonl")
    p.add_argument("--split", default="test", choices=["dev", "test", "all"])
    p.add_argument("--limit", type=int, help="number of questions (stratified by question type)")
    p.add_argument("--qtypes", help="Part B only, e.g. L1,L2,L9")
    p.add_argument("--no-judge", action="store_true", help="score with the rule checks only (no LLM judge)")
    p.add_argument("--judge-model", help="Ollama tag for the judge (default: models.yaml slot 'judge')")
    p.add_argument("--model", help="Ollama tag used by MAS AND baselines (planner, sparql, synthesizer, verifier); "
                                    "run once per model, then compare with e2e-compare")
    p.add_argument("--include-rag", action="store_true", help="Part A: also the general-knowledge questions")
    p.add_argument("--eval-store", default="graphdb", choices=["graphdb", "memory"],
                   help="Part B scenario store: a separate GraphDB repository (default) or rdflib in memory")
    p.add_argument("--eval-repo", default="ffonto-eval", help="empty GraphDB repository for Part B (never your data repo)")
    p.add_argument("--example-pool", default="all", choices=["all", "dev"],
                   help="planner few-shot pool: dev = only dev-split questions of golden_partA (strict hold-out)")
    p.add_argument("--k", type=int, help="planner few-shot examples (default 8)")
    p.add_argument("--no-monitor", action="store_true", help="do not sample GPU power / memory (nvidia-smi)")
    p.add_argument("--tag", help="extra label for the run folder")
    p.set_defaults(fn=cmd_e2e)

    p = sub.add_parser("e2e-compare", help="compare e2e runs made with different --model values")
    p.add_argument("runs", nargs="+", help="run folders (runs/..._e2e_B_<model>)")
    p.add_argument("--system", default="mas")
    p.set_defaults(fn=cmd_e2e_compare)

    p = sub.add_parser("grade", help="grade a run made with --no-judge (two-pass: answers first, judge afterwards)")
    p.add_argument("run", help="e2e run folder")
    p.add_argument("--judge-model", required=True, help="e.g. gpt-oss:20b")
    p.add_argument("--dataset", help="golden set (default: from run.json)")
    p.set_defaults(fn=cmd_grade)

    p = sub.add_parser("rescore", help="re-score a saved e2e run: fact coverage, auto-fail, rubric, several judges")
    p.add_argument("run", help="e2e run folder")
    p.add_argument("--dataset", help="golden set the run used (default: from run.json)")
    p.add_argument("--keyfacts", help="Part A: reviewed key-facts CSV (wfmas keyfacts-draft)")
    p.add_argument("--judges", help="re-grade with these judges (strict prompt), e.g. gpt-oss:20b,gemma4:12b,qwen3:14b")
    p.add_argument("--rejudge", help="one judge model: strict re-grade used for 'strict_correct'")
    p.add_argument("--rubric", action="store_true", help="decision-support rubric for hazard-advice answers")
    p.add_argument("--rubric-all", action="store_true", help="rubric for every answer, not only hazard advice")
    p.add_argument("--rubric-model", help="model for the rubric (default: first of --judges / --rejudge / run judge)")
    p.set_defaults(fn=cmd_rescore)

    p = sub.add_parser("expert-sheet", help="blinded rating sheet for a domain expert (rubric columns)")
    p.add_argument("run")
    p.add_argument("-n", type=int, default=20, help="about this many answers (all systems for each question)")
    p.add_argument("--all", action="store_true", help="any question type, not only hazard advice")
    p.set_defaults(fn=cmd_expert_sheet)

    p = sub.add_parser("expert-agreement", help="expert ratings vs the LLM rubric judge")
    p.add_argument("run")
    p.add_argument("--sheet")
    p.add_argument("--key")
    p.set_defaults(fn=cmd_expert_agreement)

    p = sub.add_parser("keyfacts-draft", help="Part A: draft key facts per question with an LLM, for review")
    p.add_argument("--dataset", default="eval/datasets/golden_partA.jsonl")
    p.add_argument("--split", default="test", choices=["dev", "test", "all"])
    p.add_argument("--out", default="eval/datasets/keyfacts_partA.csv")
    p.add_argument("--model", required=True)
    p.add_argument("--limit", type=int)
    p.set_defaults(fn=cmd_keyfacts_draft)

    p = sub.add_parser("analyze", help="difficulty, effort vs quality, calibration, bands, tokens, worked cases")
    p.add_argument("run", help="e2e run folder (rescore it first for FCR and rubric bands)")
    p.add_argument("--baseline", help="system for the before/after band matrix (default single_agent)")
    p.set_defaults(fn=cmd_analyze)

    p = sub.add_parser("delay-analysis", help="how far a fire moves during satellite data age + answer time")
    p.add_argument("--run", help="e2e run folder: uses the MAS median answer time")
    p.add_argument("--answer-s", type=float, default=27.0, help="answer time if no --run (seconds)")
    p.add_argument("--data-age-h", default="1,3,6", help="FIRMS data ages to tabulate (hours)")
    p.add_argument("--winds", default="10,20,40,60", help="wind speeds (km/h)")
    p.add_argument("--ros-share", type=float, default=0.10, help="spread rate as a share of wind speed")
    p.add_argument("--measure-area", help="'w,s,e,n': also measure the age of current FIRMS NRT detections")
    p.add_argument("--source", help="FIRMS sources for --measure-area")
    p.set_defaults(fn=cmd_delay_analysis)

    p = sub.add_parser("t2s-ablation", help="text-to-SPARQL: zero-shot, naive (RAG), plus, plus minus each step")
    p.add_argument("--dataset", default="eval/datasets/golden_partA.jsonl")
    p.add_argument("--split", default="test", choices=["dev", "test", "all"])
    p.add_argument("--configs", help="subset, e.g. template_retrieval,plus,compact (default: all eleven)")
    p.add_argument("--model", help="SPARQL model (default: ffonto-v2 SPARQL_MODEL)")
    p.add_argument("--limit", type=int)
    p.add_argument("--example-pool", default="dev", choices=["all", "dev"])
    p.add_argument("--k", type=int, default=8, help="examples retrieved for the hints")
    p.add_argument("--hints", type=int, default=3, help="CQ queries shown as examples")
    p.add_argument("--window", type=int, help="context window in tokens (default llm.context_window = 8192)")
    p.add_argument("--share", type=float, help="prompt budget for compact (default t2s.budget_share = 0.35)")
    p.set_defaults(fn=cmd_t2s_ablation)

    p = sub.add_parser("e2e-agreement", help="judge vs your grades in human_check.csv (Cohen's kappa)")
    p.add_argument("file")
    p.set_defaults(fn=cmd_e2e_agreement)

    p = sub.add_parser("where", help="describe a point: protected area, district, nearest place, land cover")
    p.add_argument("--lat", type=float, required=True)
    p.add_argument("--lon", type=float, required=True)
    p.add_argument("--instrument", default="VIIRS")
    p.set_defaults(fn=cmd_where)

    p = sub.add_parser("enrich-sample", help="write a labelling sheet of enriched hotspots (fire-context evaluation)")
    p.add_argument("--area", default="79.5,5.8,82.0,9.9", help="'w,s,e,n' (use --area=... for negative values)")
    p.add_argument("--days", type=int, default=10)
    p.add_argument("--end", help="YYYY-MM-DD (default: today, NRT data)")
    p.add_argument("--source", help="FIRMS sources, comma-separated (default: settings)")
    p.add_argument("-n", type=int, default=100)
    p.add_argument("--out", default="eval/datasets/enrich_labels.csv")
    p.set_defaults(fn=cmd_enrich_sample)

    p = sub.add_parser("eval-enrich", help="score fire-context labels against your manual labels")
    p.add_argument("--labels", default="eval/datasets/enrich_labels.csv")
    p.set_defaults(fn=cmd_eval_enrich)

    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
