"""#13 Text-to-SPARQL step ablation (`wfmas t2s-ablation`).

Runs ffonto-v2's text-to-SPARQL on the Part A knowledge-graph questions whose record or weather day is in
GraphDB, in six configurations, on exactly the same questions:

  zero_shot          the model writes the whole query with no examples (no retrieval at all)
  naive              the model writes the whole query; the retrieved CQ queries are shown as examples (plain RAG)
  plus               context binding + schema linking + template adaptation + execution feedback
  plus-no_bind       plus without context binding (the model must bind ?record / ?date itself)
  plus-no_schema     plus without schema linking (no ontology concepts matched to the question)
  plus-no_template   plus without template adaptation (no nearest CQ query to edit)
  plus-no_feedback   plus without the regeneration on an empty / too large result
  template_retrieval no LLM at all: run the tested query of the nearest example's CQ (rule-based template)
  template_planner   the Wildfire-MAS path: the planner (LLM) picks the CQ, code runs the tested query
  compact            Wildfire-MAS compact generator: retrieved cards, pruned rules, compressed example,
                     pointer cards, prompt within 35 % of the context window, static check, one repair
  compact-patch      compact, but the model answers with a base query id + edits (pointer + patch)

Every LLM configuration also records the prompt size (estimated tokens, same estimator for all) and its
share of the context window, so accuracy can be compared with prompt cost.

The CQ hints come from the same retrieval as in the system: the CQ labels of the embedding-nearest labelled
questions (from the dev split with --example-pool dev). Scored against the gold CQ's rows:
  exec_ok      the query ran;   non_empty   it returned rows
  result P/R/F1  answer-set overlap with the gold rows (KGQA style);   exact   F1 = 1
  hint_hit     the gold CQ was among the hints (retrieval quality, same for every configuration)
"""
from __future__ import annotations

import importlib
import json
import random
import statistics
import time
from datetime import datetime
from pathlib import Path

from .metrics import bootstrap_ci, mcnemar

CONFIGS = {
    "zero_shot": ("naive", {}),
    "naive": ("naive", {}),
    "plus": ("plus", {}),
    "plus-no_bind": ("plus", {"T2S_BIND_CONTEXT": False}),
    "plus-no_schema": ("plus", {"T2S_SCHEMA_LINK": False}),
    "plus-no_template": ("plus", {"T2S_ADAPT_TEMPLATE": False}),
    "plus-no_feedback": ("plus", {"T2S_EXEC_FEEDBACK": False}),
    "template_retrieval": ("template", {}),
    "template_planner": ("template", {}),
    "compact": ("compact", {"mode": "write"}),
    "compact-patch": ("compact", {"mode": "patch"}),
}
DEFAULT_CONFIGS = ["template_retrieval", "template_planner", "zero_shot", "naive", "plus", "plus-no_bind",
                   "plus-no_schema", "plus-no_template", "plus-no_feedback", "compact", "compact-patch"]
FLAGS = ("T2S_BIND_CONTEXT", "T2S_SCHEMA_LINK", "T2S_ADAPT_TEMPLATE", "T2S_EXEC_FEEDBACK")


def _ci(v) -> str:
    v = [float(x) for x in v if x is not None]
    if not v:
        return "-"
    m, lo, hi = bootstrap_ci(v)
    return f"{m:.3f} [{lo:.3f}-{hi:.3f}]"


def t2s_ablation(settings, dataset: Path, split: str = "test", configs: list[str] | None = None,
                 model: str | None = None, limit: int | None = None, example_pool: str = "dev", k: int = 8,
                 hints: int = 3, context_window: int | None = None, budget_share: float | None = None,
                 log=print) -> Path:
    from ..kg.ffonto_bridge import FfontoBridge

    br = FfontoBridge(settings, model)
    if not (br.configured and br.available()):
        raise SystemExit("needs FFONTO_V2_PATH and GraphDB with your ffonto-v2 data")
    qa = br.qa
    config, cqs = qa["config"], qa["cqs"]
    pipeline = importlib.import_module("qa.pipeline")
    M = importlib.import_module("qa.metrics")
    ev = importlib.import_module("qa.evaluate")
    if model:
        config.SPARQL_MODEL = model
    items = [json.loads(x) for x in dataset.read_text(encoding="utf-8").splitlines() if x.strip()]
    allowed = {i["question"].strip().lower() for i in items if i.get("split") == "dev"} if example_pool == "dev" else None
    items = [i for i in items if (split == "all" or i.get("split") == split) and i.get("gold_route") == "kg"
             and i.get("gold_cq") in cqs.REGISTRY]
    lookup, dates = ev._record_lookup(), ev._weather_dates()
    chosen = []
    for it in items:
        e = {"question": it["question"], "answer": it.get("gold_answer", ""), "route": "kg", "cq": it["gold_cq"],
             "source": it.get("source"), "modality": it.get("modality")}
        rec, day = ev.match_context(e, lookup, dates)
        if rec or day:
            chosen.append((it, rec, day))
    if not chosen:
        raise SystemExit("no test question has its record or weather day in GraphDB")
    if limit:
        random.Random(3).shuffle(chosen)
        chosen = chosen[:limit]
    log(f"{len(chosen)} KG questions with data in GraphDB · SPARQL model {config.SPARQL_MODEL}")
    # gold rows and retrieved hints once per question (identical for every configuration)
    prepared = []
    for it, rec, day in chosen:
        try:
            gold = cqs.run_cq(it["gold_cq"], record=rec["iri"] if rec else None, date=day)["rows"]
        except Exception:  # noqa: BLE001
            gold = None
        near = br.nearest_examples(it["question"], k=k, exclude_self=True, allowed=allowed) or []
        hs = [e["label"] for e in near if e.get("label") and e["label"] in cqs.REGISTRY][:hints]
        prepared.append((it, rec, day, gold, hs))
    saved = {f: getattr(config, f) for f in FLAGS}
    window = int(context_window or settings.get("llm.context_window", 8192))
    share = float(budget_share or settings.get("t2s.budget_share", 0.35))
    try:
        llm_mod = importlib.import_module("qa.llm")
    except ImportError:
        llm_mod = None
    captured: list[int] = []
    orig_chat = getattr(llm_mod, "chat_json", None) if llm_mod else None

    def counting_chat(system, user, *a, **kw):           # measure ffonto-v2 prompts with the same estimator
        captured.append(len(str(system)) + len(str(user)))
        return orig_chat(system, user, *a, **kw)

    tk = planner = wllm = cat = None
    names = configs or DEFAULT_CONFIGS
    if any(CONFIGS[n][0] in ("compact", "template") for n in names):
        from ..llm import LLMClient
        from ..tools.toolkit import Toolkit

        m = model or config.SPARQL_MODEL
        wllm = LLMClient(settings, {"sparql": {"provider": "ollama", "model": m, "json": True},
                                    "planner": {"provider": "ollama", "model": m, "json": True}})
        tk = Toolkit(settings, llm=wllm)
    if any(CONFIGS[n][0] == "compact" for n in names):
        from ..kg.t2s_compact import Catalog

        cat = Catalog.from_dict(tk.kg_schema_catalog())
        log(f"catalog: {cat.stats()}")
    if "template_planner" in names:
        from ..agents.planner import Planner
        from ..kg.cq import CQCatalog
        from .harness import apply_planner_options

        apply_planner_options(settings, str(dataset), example_pool, k, hints)
        planner = Planner(wllm, CQCatalog.load(settings), settings, br)

    def run_one(name: str, it: dict, rec, day, hs: list[str]) -> dict:
        import asyncio

        kind, opt = CONFIGS[name]
        if kind == "template":
            cq = hs[0] if (name == "template_retrieval" and hs) else None
            actual = None
            if name == "template_planner":
                from ..agents.state import Request
                from ..llm import start_call_log

                log_ = start_call_log()
                cls = asyncio.run(planner.classify(Request(it["question"], record=rec["iri"] if rec else None)))
                cq = cls.get("cq")
                actual = max((c.prompt_tokens or 0 for c in log_), default=None)
            if not cq or cq not in cqs.REGISTRY:
                return {"sparql": None, "rows": [], "error": f"no core CQ chosen ({cq})", "cq_used": cq,
                        "prompt_tokens_actual": actual}
            res = cqs.run_cq(cq, record=rec["iri"] if rec else None, date=day)
            return {"sparql": res.get("query"), "rows": res.get("rows") or [], "error": None, "cq_used": cq,
                    "prompt_tokens_actual": actual}
        if kind == "compact":
            from ..kg.t2s_compact import generate

            async def chat(system, user):
                return await wllm.chat_json("sparql", system, user)

            from ..llm import start_call_log

            log_ = start_call_log()
            out = asyncio.run(generate(it["question"], cat, chat, tk.kg_run_sparql,
                                       {"record": rec["iri"] if rec else None, "date": day}, hints=hs,
                                       intent=it.get("gold_intent"), mode=opt["mode"], context_window=window,
                                       budget_share=share))
            st = out.get("prompt_stats") or {}
            return {"sparql": out.get("sparql"), "rows": out.get("rows") or [],
                    "error": None if out.get("ok") else "; ".join(out.get("problems") or [])[:200],
                    "prompt_tokens": st.get("est_tokens"), "attempts": len(out.get("attempts") or []),
                    "mode_used": out.get("mode_used"),
                    "prompt_tokens_actual": max((c.prompt_tokens or 0 for c in log_), default=None)}
        captured.clear()
        q, cols, rws, _ = pipeline.text_to_sparql(it["question"], rec["iri"] if rec else None,
                                                  [] if name == "zero_shot" else hs, date=day, event=None, mode=kind)
        return {"sparql": q, "rows": rws, "error": None,
                "prompt_tokens": int(max(captured) / 3.0) if captured else None, "attempts": len(captured)}

    out_dir = settings.root / settings.get("paths.runs_dir", "runs") / f"{datetime.now():%Y%m%d_%H%M%S}_t2s_ablation"
    out_dir.mkdir(parents=True, exist_ok=True)
    results: dict[str, list[dict]] = {}
    try:
        with (out_dir / "items.jsonl").open("w", encoding="utf-8") as f:
            if orig_chat is not None:
                llm_mod.chat_json = counting_chat
            for name in names:
                kind, off = CONFIGS[name]
                for fl in FLAGS:
                    setattr(config, fl, saved[fl] if kind != "plus" or fl not in off else off[fl])
                rows = []
                for i, (it, rec, day, gold, hs) in enumerate(prepared, 1):
                    t0 = time.perf_counter()
                    try:
                        o = run_one(name, it, rec, day, hs)
                        q, rws, err = o["sparql"], o["rows"], o["error"]
                    except Exception as ex:  # noqa: BLE001
                        o, q, rws, err = {}, None, [], f"{ex.__class__.__name__}: {str(ex)[:200]}"
                    pt = o.get("prompt_tokens")
                    r = {"config": name, "id": it["id"], "gold_cq": it["gold_cq"], "hints": hs,
                         "hint_hit": it["gold_cq"] in hs, "exec_ok": err is None and q is not None,
                         "non_empty": bool(rws), "n_rows": len(rws), "error": err, "sparql": q,
                         "seconds": round(time.perf_counter() - t0, 2), "prompt_tokens": pt,
                         "prompt_share": round(pt / window, 3) if pt else None, "attempts": o.get("attempts"),
                         "cq_used": o.get("cq_used"), "mode_used": o.get("mode_used"),
                         "prompt_tokens_actual": o.get("prompt_tokens_actual")}
                    if gold is not None:
                        p, rc, f1 = M.result_set_prf(rws, gold)
                        r.update(result_P=p, result_R=rc, result_F1=f1, exact=f1 == 1.0)
                    rows.append(r)
                    f.write(json.dumps(r, default=str) + "\n")
                    if i % 25 == 0:
                        log(f"  {name}: {i}/{len(prepared)}")
                results[name] = rows
    finally:
        for fl, v in saved.items():
            setattr(config, fl, v)
        if orig_chat is not None:
            llm_mod.chat_json = orig_chat
    lines = [f"# Text-to-SPARQL step ablation", "",
             f"{len(prepared)} Part A KG questions ({split}) with data in GraphDB · SPARQL model {config.SPARQL_MODEL} · "
             f"hints from {'dev-split' if allowed is not None else 'all'} examples (k={k}, {hints} hints) · "
             f"gold CQ among hints: {sum(1 for p in prepared if p[0]['gold_cq'] in p[4]) / len(prepared):.3f}", "",
             "| configuration | exec rate | non-empty | result P | result R | result F1 | exact match | "
             "prompt tokens (mean / max) | share of window (max) | p50 s |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    for name, rows in results.items():
        pts = [r["prompt_tokens"] for r in rows if r.get("prompt_tokens")]
        ptxt = f"{statistics.mean(pts):.0f} / {max(pts)}" if pts else "0 (no LLM)" if CONFIGS[name][0] == "template" \
            and name == "template_retrieval" else "-"
        shr = f"{max(pts) / window:.0%}" if pts else "-"
        lines.append(f"| {name} | {_ci([float(r['exec_ok']) for r in rows])} | {_ci([float(r['non_empty']) for r in rows])} | "
                     f"{_ci([r.get('result_P') for r in rows])} | {_ci([r.get('result_R') for r in rows])} | "
                     f"{_ci([r.get('result_F1') for r in rows])} | "
                     f"{_ci([float(r['exact']) for r in rows if 'exact' in r])} | {ptxt} | {shr} | "
                     f"{statistics.median([r['seconds'] for r in rows]):.2f} |")
    if "plus" in results:
        base = {r["id"]: bool(r.get("exact")) for r in results["plus"]}
        lines += ["", "McNemar on exact match vs plus (the full method):", ""]
        for name, rows in results.items():
            if name == "plus":
                continue
            other = {r["id"]: bool(r.get("exact")) for r in rows}
            ks = sorted(set(base) & set(other))
            t = mcnemar([base[x] for x in ks], [other[x] for x in ks])
            lines.append(f"- {name}: plus-only exact {t['b']}, {name}-only exact {t['c']}, p = {t['p']:.4f}")
    act = [(r["prompt_tokens"], r["prompt_tokens_actual"]) for rs in results.values() for r in rs
           if r.get("prompt_tokens") and r.get("prompt_tokens_actual")]
    if act:
        ratio = statistics.mean(a / e for e, a in act)
        lines += ["", f"Token estimator check (compact runs): Ollama's real prompt count = {ratio:.2f} × the estimate "
                      f"(n = {len(act)}); below 1 means the estimate is on the safe side."]
    lines += ["", "A step matters when switching it off lowers result F1 / exact match. zero_shot vs naive is the effect "
                  "of retrieved examples (prompting with retrieval); naive vs plus is the effect of the four plus steps "
                  "together; hint_hit is how often retrieval found the right CQ at all."]
    (out_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_dir
