"""Analyses of a saved end-to-end run (`wfmas analyze <run>`), no model calls.

  #29 difficulty tiers       results per easy / medium / hard, with steps and latency per tier
  #30 effort vs quality      Spearman correlation of steps, tool calls, LLM calls, tokens, IORS rounds with quality
  #31 confidence calibration MAS self-reported confidence vs observed score: ECE, over/under-confidence, diagram
  #32 before/after bands     rubric band of the baseline vs the MAS for the same question (needs rescore --rubric)
  #33 qualitative cases      worked examples per error type, from the saved traces (cases.md)
  #35 tokens                 per system, per role (planner, synthesizer, ...), prompt vs completion
  #36 resources              copied from resources.md when the run recorded it
  #47 delay analysis         separate: `wfmas delay-analysis` (satellite data age + answer time -> fire movement)
"""
from __future__ import annotations

import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from . import plots
from .e2e import GRADE
from .metrics import bootstrap_ci
from .rescore import BANDS, load_rows, spearman

# Part B question types -> difficulty (one fact / one agent; several facts or rules; hazards, conflicts, no location)
TIER_B = {"L1": "easy", "L2": "easy", "L6": "easy", "L12": "easy",
          "L3": "medium", "L4": "medium", "L5": "medium", "L7": "medium", "L11": "medium",
          "L8": "hard", "L9": "hard", "L10": "hard"}
# Part A: FFOnto answer layer of the gold CQ (FFVQA_CQ_mapping.xlsx, CQ Catalogue)
CQ_LAYER = {**{f"CQ{i:02d}": "A" for i in range(1, 8)}, "CQ07b": "A", **{f"CQ{i:02d}": "B" for i in (8, 9, 10)},
            **{f"CQ{i:02d}": "C" for i in range(11, 23)}, "CQ23": "D", "CQ24": "E", "CQ25": "E", "CQ26": "E"}
TIER_A = {"A": "easy", "B": "easy", "D": "easy", "C": "medium", "E": "hard", "OOS": "medium"}
DIRECT_A = {"CQ01", "CQ03", "CQ04", "CQ08", "CQ09", "CQ23"}           # KG – direct
RULE_A = {"CQ05", "CQ07", "CQ07b", "CQ10", "CQ13", "CQ17", "CQ19", "CQ21"}  # extraction/rule + rule


def tier(row: dict) -> str:
    if row.get("qtype"):
        return TIER_B.get(row["qtype"], "medium")
    cq = row.get("gold_cq") or "OOS"
    if cq in DIRECT_A:
        return "easy"
    if cq in RULE_A or CQ_LAYER.get(cq) == "E":
        return "hard"
    return TIER_A.get(CQ_LAYER.get(cq, "OOS"), "medium")


def quality(row: dict) -> float | None:
    """Score used by the analyses: FCR when re-scored, else judge grade, else rule check."""
    if row.get("fcr") is not None:
        return float(row["fcr"])
    if row.get("judge_grade") in GRADE:
        return GRADE[row["judge_grade"]]
    if row.get("rule_check") is not None:
        return float(bool(row["rule_check"]))
    return None


def _mean(v):
    v = [x for x in v if x is not None]
    return statistics.mean(v) if v else None


def _f(v, d=3):
    return "-" if v is None else (f"{v:.{d}f}" if isinstance(v, float) else str(v))


def effort(row: dict) -> dict:
    tr = row.get("trace") or {}
    return {"steps": row.get("n_steps") if row.get("n_steps") is not None else len(tr.get("steps") or []) or None,
            "tool_calls": row.get("tool_calls"), "llm_calls": row.get("llm_calls"), "tokens": row.get("tokens"),
            "iors_rounds": row.get("relaxations")}


def analyze(run: Path, baseline: str | None = None) -> Path:
    rows = load_rows(run)
    systems = list(dict.fromkeys(r["system"] for r in rows))
    by = defaultdict(list)
    for r in rows:
        r["_tier"], r["_q"] = tier(r), quality(r)
        by[r["system"]].append(r)
    qname = "FCR" if any(r.get("fcr") is not None for r in rows) else "judge score"
    L = [f"# Analysis of `{run.name}`", "", f"quality = {qname} (1 = all key facts / correct, 0.5 = partial)", ""]

    # #29 difficulty
    L += ["## Results by difficulty (#29)", "",
          "Part B: easy = one fact from one agent (L1, L2, L6, L12); medium = counts, categories, spreading, raised "
          "danger, trend (L3-L5, L7, L11); hard = hazards with actions, image-satellite conflict, no location (L8-L10). "
          "Part A: easy = direct KG lookups, medium = scene perception and documents, hard = rule-derived and "
          "cross-modal CQs.", "",
          "| system | tier | n | quality | correct | median steps | median tool calls | p50 latency s |", "|---|---|---|---|---|---|---|---|"]
    for s in systems:
        for t in ("easy", "medium", "hard"):
            rs = [r for r in by[s] if r["_tier"] == t]
            if not rs:
                continue
            st = [effort(r)["steps"] for r in rs if effort(r)["steps"] is not None]
            tc = [r.get("tool_calls") for r in rs if r.get("tool_calls") is not None]
            lat = [r.get("latency_s") or r.get("seconds") for r in rs if (r.get("latency_s") or r.get("seconds")) is not None]
            L.append(f"| {s} | {t} | {len(rs)} | {_f(_mean([r['_q'] for r in rs]))} | "
                     f"{_f(_mean([float(bool(r.get('correct'))) for r in rs]))} | "
                     f"{_f(statistics.median(st), 1) if st else '-'} | {_f(statistics.median(tc), 1) if tc else '-'} | "
                     f"{_f(statistics.median(lat), 1) if lat else '-'} |")

    # #30 effort vs quality
    L += ["", "## Effort vs quality (#30)", "",
          "Spearman ρ between effort and the quality score of each answer (negative = more effort on answers that "
          "end up worse, usually because hard questions need both).", "",
          "| system | steps | tool calls | LLM calls | tokens | IORS rounds | n |", "|---|---|---|---|---|---|---|"]
    for s in systems:
        rs = [r for r in by[s] if r["_q"] is not None]
        cells = []
        for k in ("steps", "tool_calls", "llm_calls", "tokens", "iors_rounds"):
            pairs = [(effort(r)[k], r["_q"]) for r in rs if effort(r)[k] is not None]
            rho = spearman([float(a) for a, _ in pairs], [b for _, b in pairs]) if len(pairs) >= 5 else None
            cells.append(_f(rho))
        L.append(f"| {s} | " + " | ".join(cells) + f" | {len(rs)} |")
    mas = [r for r in by.get("mas", []) if r["_q"] is not None]
    if mas:
        qt = sorted({r.get("qtype") or r["_tier"] for r in mas})
        L += ["", "Within question type (MAS; removes the 'hard questions need more steps' effect):", ""]
        for q in qt:
            rs = [r for r in mas if (r.get("qtype") or r["_tier"]) == q]
            pairs = [(effort(r)["tool_calls"], r["_q"]) for r in rs if effort(r)["tool_calls"] is not None]
            rho = spearman([float(a) for a, _ in pairs], [b for _, b in pairs]) if len(pairs) >= 5 else None
            if rho is not None:
                L.append(f"- {q}: tool calls vs quality ρ = {rho:.3f} (n = {len(pairs)})")

    # #31 calibration
    cal = [r for r in rows if r.get("confidence") is not None and r["_q"] is not None]
    svg_rel = None
    L += ["", "## Confidence calibration (#31)", ""]
    if cal:
        for s in sorted({r["system"] for r in cal}):
            rs = [r for r in cal if r["system"] == s]
            bins = []
            for i in range(5):
                lo, hi = i / 5, (i + 1) / 5
                b = [r for r in rs if lo <= r["confidence"] < hi or (i == 4 and r["confidence"] == 1.0)]
                bins.append({"lo": lo, "hi": hi, "n": len(b), "conf": _mean([r["confidence"] for r in b]) or (lo + hi) / 2,
                             "acc": _mean([r["_q"] for r in b]) or 0.0})
            ece = sum(b["n"] * abs(b["conf"] - b["acc"]) for b in bins if b["n"]) / len(rs)
            mc, mq = _mean([r["confidence"] for r in rs]), _mean([r["_q"] for r in rs])
            L += [f"- {s}: mean confidence {mc:.3f} vs mean {qname} {mq:.3f} → "
                  f"{'over' if mc > mq else 'under'}-confident by {abs(mc - mq):.3f}; ECE = {ece:.3f} (n = {len(rs)})", "",
                  "| confidence bin | n | mean confidence | mean " + qname + " |", "|---|---|---|---|"]
            L += [f"| {b['lo']:.1f}-{b['hi']:.1f} | {b['n']} | {b['conf']:.3f} | {b['acc']:.3f} |" for b in bins if b["n"]]
            if s == "mas" or svg_rel is None:
                svg_rel = plots.reliability(bins, f"Calibration · {s}")
        (run / "calibration.svg").write_text(svg_rel, encoding="utf-8")
        L += ["", "ECE = expected calibration error (0 = confidence matches the observed score). Chart: calibration.svg"]
    else:
        L.append("No confidence values in this run (needs a run made with this version: the synthesizer now reports one).")

    # #32 band matrix
    rub = {(r["id"], r["system"]): r.get("rubric_band") for r in rows if r.get("rubric_band")}
    L += ["", "## Before / after quality bands (#32)", ""]
    if rub:
        base = baseline or next((s for s in ("single_agent", "plain_rag", "llm_only") if s in systems and s != "mas"),
                                None)
        if base and "mas" in systems:
            names = [b for _, b in BANDS]
            counts = Counter()
            for (i, s), b in rub.items():
                if s == base and (i, "mas") in rub:
                    counts[(b, rub[(i, "mas")])] += 1
            rank = {b: k for k, b in enumerate(reversed(names))}
            up = sum(n for (a, b), n in counts.items() if rank[b] > rank[a])
            down = sum(n for (a, b), n in counts.items() if rank[b] < rank[a])
            same = sum(counts.values()) - up - down
            L += [f"{sum(counts.values())} questions rated for both {base} and mas: better band {up}, same {same}, "
                  f"worse {down}.", "", f"| {base} → mas | " + " | ".join(names) + " |", "|" + "---|" * (len(names) + 1)]
            for a in names:
                L.append(f"| {a} | " + " | ".join(str(counts.get((a, b), 0)) for b in names) + " |")
            (run / "band_matrix.svg").write_text(plots.heatmap(names, names, counts, f"Quality band: {base} → mas",
                                                               f"{base} band", "mas band"), encoding="utf-8")
            L.append("\nChart: band_matrix.svg")
        else:
            L.append("Needs a run with `mas` and a baseline system.")
    else:
        L.append("No rubric bands yet: run `wfmas rescore <run> --rubric` first.")

    # #35 tokens
    L += ["", "## Tokens (#35)", "", "| system | mean tokens | prompt | completion | by role (mean per answer) |",
          "|---|---|---|---|---|"]
    for s in systems:
        rs = by[s]
        roles = defaultdict(list)
        for r in rs:
            for k, v in (r.get("tokens_by_slot") or {}).items():
                roles[k].append(v)
        role_txt = ", ".join(f"{k} {statistics.mean(v):.0f}" for k, v in sorted(roles.items(), key=lambda kv: -statistics.mean(kv[1])))
        L.append(f"| {s} | {_f(_mean([r.get('tokens') for r in rs]), 0)} | {_f(_mean([r.get('prompt_tokens') for r in rs]), 0)} | "
                 f"{_f(_mean([r.get('completion_tokens') for r in rs]), 0)} | {role_txt or '-'} |")

    # prompt size per role vs the context window (30-40 % target)
    win = 8192
    meta = run / "run.json"
    if meta.exists():
        win = int(json.loads(meta.read_text()).get("context_window") or win)
    mp = defaultdict(list)
    for r in rows:
        for k, v in (r.get("max_prompt_by_slot") or {}).items():
            if v:
                mp[k].append(v)
    if mp:
        L += ["", f"Largest prompt per role (real Ollama counts) against the {win}-token window "
                  "(target: 30-40 %, never near 100 %):", "",
              "| role | median prompt | max prompt | max share of window | answers over 40 % |", "|---|---|---|---|---|"]
        for k, v in sorted(mp.items()):
            over = sum(1 for x in v if x > 0.4 * win)
            L.append(f"| {k} | {statistics.median(v):.0f} | {max(v)} | {max(v) / win:.0%} | {over} of {len(v)} |")

    # #36 resources
    res = run / "resources.md"
    L += ["", "## Resources (#36)", ""]
    L.append(res.read_text(encoding="utf-8").replace("# Resource use", "").strip() if res.exists()
             else "Not recorded (run made before this version, or with --no-monitor).")
    (run / "analysis.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    (run / "cases.md").write_text(cases(rows), encoding="utf-8")
    return run


# ------------------------------------------------------------------------------ #33 qualitative cases
def _case(r: dict, title: str) -> list[str]:
    tr = r.get("trace") or {}
    out = [f"### {title}: {r['id']} ({r['system']}, {r.get('qtype') or r.get('gold_cq') or ''})", "",
           f"**Question:** {r.get('question')}", "", f"**Reference:** {r.get('reference') or '-'}", "",
           f"**Answer:** {(r.get('answer') or '(empty)').strip()[:900]}", "",
           f"**Scores:** judge {r.get('judge_grade') or '-'}"
           + (f" ({r.get('judge_why')})" if r.get("judge_why") else "")
           + f" · rule check {r.get('rule_check')} · FCR {_f(r.get('fcr'))}"
           + (f" (missing: {', '.join(r.get('fcr_missing') or [])})" if r.get("fcr_missing") else "")
           + (f" · auto-fail: {'; '.join(r['auto_fail'])}" if r.get("auto_fail") else ""), ""]
    if r.get("attribution"):
        out += [f"**Attributed to:** {r['attribution']}", ""]
    if tr.get("plan_steps"):
        out += ["**Plan:** " + " → ".join(f"{a}{('(' + c + ')') if c else ''}" for a, c in tr["plan_steps"]), ""]
    for st in tr.get("steps") or []:
        note = "; ".join(st.get("notes") or [])[:220]
        out.append(f"- {st.get('agent')} {'ok' if st.get('ok') else 'FAILED: ' + str(st.get('error'))[:160]}"
                   + (f" — {note}" if note else ""))
    for c in tr.get("calls") or []:
        out.append(f"- tool {c.get('tool')} {'ok' if c.get('ok') else 'FAILED: ' + str(c.get('error'))[:160]}")
    if tr.get("live"):
        out.append(f"- live data seen: {json.dumps(tr['live'], default=str)[:300]}")
    return out + [""]


def cases(rows: list[dict], per_type: int = 2) -> str:
    L = ["# Worked cases (#33)", "",
         "Picked automatically from the run: wrong MAS answers per error type, cases where the MAS was right and the "
         "single agent wrong (and the reverse), and disagreements between FCR and the judge. Edit freely for the report.", ""]
    mas = [r for r in rows if r["system"] == "mas"]
    wrong = defaultdict(list)
    for r in mas:
        if not r.get("correct") and r.get("attribution"):
            wrong[r["attribution"].split(" (")[0]].append(r)
    L += ["## MAS errors by type", ""]
    if not wrong:
        L.append("No attributed MAS errors in this run.\n")
    for k, rs in sorted(wrong.items(), key=lambda kv: -len(kv[1])):
        L.append(f"**{k}**: {len(rs)} answers\n")
        for r in rs[:per_type]:
            L += _case(r, f"Error · {k}")
    other = {r["id"]: r for r in rows if r["system"] == "single_agent"}
    win = [r for r in mas if r.get("correct") and r["id"] in other and not other[r["id"]].get("correct")]
    loss = [r for r in mas if not r.get("correct") and r["id"] in other and other[r["id"]].get("correct")]
    if win or loss:
        L += ["## MAS vs single agent on the same question", "",
              f"MAS right / single agent wrong: {len(win)} · MAS wrong / single agent right: {len(loss)}", ""]
        for r in win[:2]:
            L += _case(r, "MAS right")
            L += _case(other[r["id"]], "single agent wrong")
        for r in loss[:2]:
            L += _case(r, "MAS wrong")
            L += _case(other[r["id"]], "single agent right")
    dis = [r for r in mas if r.get("fcr") is not None and r.get("judge_grade") in GRADE
           and abs(r["fcr"] - GRADE[r["judge_grade"]]) >= 0.75]
    if dis:
        L += ["## FCR and judge disagree", ""]
        for r in dis[:3]:
            L += _case(r, "Disagreement")
    return "\n".join(L) + "\n"


# ------------------------------------------------------------------------------ #47 delay analysis
def delay_analysis(answer_s: float | None, data_age_h: list[float], winds_kmh: list[float], ros_share: float = 0.10,
                   measured: dict | None = None, radius_km: float = 10.0) -> str:
    """How far a fire can move between the satellite overpass and the moment the answer is read.

    Rate of spread (ROS) uses the '10 % wind speed' rule of thumb for dry forest and shrub fuels (Cruz & Alexander
    2019, Annals of Forest Science 76:44), an upper estimate; fires in moist fuels move much less."""
    L = ["# Delay and position-drift analysis (#47)", "",
         f"Rate of spread = {ros_share:.0%} of the 10 m wind speed (rule of thumb for dry forest/shrub fuels; "
         "an upper bound for screening).", ""]
    if measured:
        L += [f"Measured age of FIRMS NRT detections right now ({measured['area']}, {measured['n']} detections, "
              f"{measured['source']}): freshest {measured['min_h']:.1f} h old, median {measured['median_h']:.1f} h, "
              f"90th percentile {measured['p90_h']:.1f} h. The freshest age is the best case at this moment "
              "(time since the last overpass plus processing); the median is what a typical detection in a one-day "
              "query looks like.", ""]
    a = (answer_s or 0) / 3600
    L += [f"Answer time: {answer_s if answer_s is not None else 0:.0f} s (median of the run) = {a * 60:.1f} min.", "",
          "| data age h | wind km/h | spread rate km/h | moved during data age km | moved during answer m | "
          "total km | share of the 10 km R09 radius |", "|---|---|---|---|---|---|---|"]
    for age in data_age_h:
        for w in winds_kmh:
            ros = ros_share * w
            d_age, d_ans = ros * age, ros * a
            tot = d_age + d_ans
            L.append(f"| {age:g} | {w:g} | {ros:.1f} | {d_age:.2f} | {d_ans * 1000:.0f} | {tot:.2f} | {tot / radius_km:.0%} |")
    L += ["", "Reading: the answer time adds metres; the satellite data age adds kilometres. A detection 'within 10 km' "
              "may be closer by the time the answer is read, so for a fast fire the system should be read as screening, "
              "not as a position fix. Mitigation: state the detection time in every answer (the system does), and "
              "widen the danger radius by spread rate × data age when wind is strong."]
    return "\n".join(L) + "\n"


def measure_firms_age(settings, area: str, days: int = 1, sources: list[str] | None = None) -> dict | None:
    from datetime import datetime, timezone

    from ..live.firms import FirmsClient

    res = FirmsClient(settings).get_area(area, days=days, sources=sources)
    now = datetime.now(timezone.utc)
    ages = sorted((now - h.acq_datetime).total_seconds() / 3600 for h in res.hotspots if h.acq_datetime)
    if not ages:
        return None
    return {"area": area, "n": len(ages), "source": ",".join(sources or ["default"]),
            "median_h": statistics.median(ages), "p90_h": ages[int(0.9 * (len(ages) - 1))], "min_h": ages[0]}


def run_latency(run: Path, system: str = "mas") -> float | None:
    rows = [r for r in load_rows(run) if r["system"] == system]
    lat = [r.get("latency_s") or r.get("seconds") for r in rows if (r.get("latency_s") or r.get("seconds"))]
    return statistics.median(lat) if lat else None


def ci(vals) -> str:
    v = [float(x) for x in vals if x is not None]
    if not v:
        return "-"
    m, lo, hi = bootstrap_ci(v)
    return f"{m:.3f} [{lo:.3f}-{hi:.3f}]"
