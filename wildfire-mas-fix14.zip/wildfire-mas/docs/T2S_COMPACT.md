# Compact text-to-SPARQL fallback

The compact generator is the Wildfire-MAS fallback for questions where no competency question (CQ) fits. It writes a correct, standard SPARQL query from a prompt that uses at most 35% of the model's context window, and in practice about 8%.

Code: `src/wildfire_mas/kg/t2s_compact.py` (the method), `tools/toolkit.py → kg_schema_catalog` (the catalog, also exposed as the MCP tool `graphdb.schema_catalog`), `agents/workers.py → _compact_text2sparql` (use in the KG agent), `evaluation/t2s_ablation.py` (evaluation).

---

## 1. Why

**What a correct query needs.** It needs the right classes, properties and concept IRIs, the context (record, date, site, area), and ideally a working query to adapt. All of that is large:

| Source | Size (estimated tokens) |
|---|---|
| All schema cards (31 classes, 143 properties) | ≈ 2,900 |
| All concept cards (374 SKOS concepts) | ≈ 5,800 |
| All tested queries in full (27 core) | ≈ 14,300 |
| **Everything** | **≈ 23,000** |

**Why not send it all.** Ollama's default window is 4,096 tokens. The ffonto-v2 "plus" prompt sends the whole schema summary plus up to 6,000 characters of example queries, which is estimated at ≈ 5,500–6,000 tokens. Above the window, Ollama silently cuts the *beginning* of the prompt: the instructions and the schema. Long prompts are also slower and less accurate, even when they fit.

**What this generator does instead.** It sends only what the question needs, in compact form, and never more than `t2s.budget_share` (35%) of the window:

| Example question | Prompt | Share of 8,192 |
|---|---|---|
| "Is any firefighter without a helmet in this image?" | ≈ 640 tokens | 7.8% |
| "What was the relative humidity on that day?" | ≈ 660 tokens | 8.1% |
| "Which hotspots with FRP above 20 MW are inside a protected area?" | ≈ 650 tokens | 8.0% |

These are estimates with the real FFOnto ontology, vocabulary and queries. The evaluation also records Ollama's real counts.

The 35% is a ceiling, not a target. Adding unrelated cards only adds noise. The headroom is there for questions that need more cards, and for the repair round.

---

## 2. Components: what, how, why

### C1. Structure-aware chunking (the catalog)

**What.** Each knowledge source is split into **cards**, one per logical unit:

| Card | Example | Built from |
|---|---|---|
| Class | `ffo:ImageRecord ⊂ ffo:Record – image record` | `owl:Class` in the ontology graph |
| Property | `ffo:hasDetection: ffo:AudioRecord \| ffo:ImageRecord → ffo:Detection` | `owl:ObjectProperty` / `owl:DatatypeProperty` with domain and range, including `owl:unionOf` lists |
| Concept | `ffv:Helmet "helmet" ⊂ ffv:PPE` | `skos:Concept` with prefLabel, altLabels, broader |
| Query | `CQ17 · Which required PPE is missing… · returns ?item ?d · uses ffo:detects, ffo:hasDetection, ffv:PPE` | The 27 tested ffonto-v2 queries and the 11 live CQ templates |

**How.** Three SPARQL queries read the ontology and vocab graphs in GraphDB, so the catalog always matches what is actually loaded, including the live module. The tested queries come from ffonto-v2 and `cq/live_cqs.yaml`. In live templates, the `{{param}}` placeholders become `?param` variables, the same names that code binds later. The catalog is built once per process and cached.

**Why.** A whole class, property, concept or query is always a usable unit. Splitting by size, as for prose, would cut a property away from its domain and range.

### C2. Retrieval and schema linking (no LLM)

**What.** For each question, this step chooses up to 3 candidate queries, about 14 schema cards and 8 concept cards.

**How.**
- *Lexical retrieval:* question words are reduced to 5-letter stems, without stop words, and matched against each card's words. camelCase names are split, so `hasDetection` matches "detection".
- *Hints:* the planner's CQ hints, from its retrieved examples, are boosted in their order.
- *Intent pruning:* live CQs that never serve the question's intent are skipped.
- *Expansion:* the terms used by the best query are always included. Then 1-hop expansion adds the domain and range classes of linked properties, and the properties of linked classes that also match a question word.

**Why.** This is schema linking, the step that decides which part of the ontology the query can use. It is deterministic and explainable (each card is chosen for a visible reason). It also needs no extra model call, which keeps latency and cost flat.

### C3. Dynamic pruning of instructions

**What.** The prompt contains only the rule blocks that apply:

| Block | Included when |
|---|---|
| Base rules + output contract | Always |
| "Start from `?record` (bound for you)" | A record is selected |
| "Compare with `?date`" | A date is given |
| "Use `?eventCode`" / "use `?site`" | An event or site is given |
| Live-data pattern (hotspot, lat/long, time, `?lat_min…?lon_max`) | A location is known or hotspot terms were linked |
| "Use `skos:broader*`" | A linked concept has a parent |

**Why.** Instructions that don't apply cost tokens and can mislead. For example, a "use ?record" rule on a question without a record leads to a wrong query.

### C4. Deterministic compression

**What and how.**
- *Query skeleton:* the best query is shown without PREFIX lines, comments, label-only `OPTIONAL` blocks or LIMIT, with whitespace collapsed. This is about 25–60% shorter.
- *Schema and concepts:* one-line cards instead of Turtle.
- *Prefixes:* not in the prompt; code adds them after generation (`add_prefixes`).

**Why.** Compression by code is lossless for the query's meaning. An LLM summary of a query or schema could drop or invent a term, and one wrong term breaks the query.

### C5. Memory pointers (and pointer + patch)

**What.** The other candidate queries enter the prompt only as **cards**: an id and one line. Their full text stays in the catalog, outside the prompt. In `patch` mode, the model may answer with a pointer and edits:

```json
{"base": "CQ17", "edits": [{"replace": "ffontov:PPE", "with": "ffontov:Helmet"}, {"add": "FILTER(BOUND(?d))"}], "select": ["?item"]}
```

Code fetches the full CQ17 by that id and applies the edits.

**Why.** The prompt carries references instead of payloads, and the model edits a tested query instead of rewriting it, so its output is short and the result is a known-good query plus small changes. This extends the main principle of Wildfire-MAS, "the LLM chooses, code builds", to the fallback path.

### C6. Token budget with priorities

**What.** A prompt budget equal to `budget_share × context_window` (default 35% of 8,192 = 2,867 tokens).

**How.** The prompt is made of blocks, each with a priority:

| Priority | Block |
|---|---|
| 0 (always) | Question, repair feedback |
| 1 | The best query's skeleton |
| 2 | The top 6 schema cards |
| 3 | The top 4 concept cards |
| 4–5 | Further schema and concept cards |
| 6 | Pointer cards of other queries |

Blocks are added in priority order (relevance order within a priority) until the next one would exceed the budget. Cards are never cut in the middle. Token counts are estimated conservatively (3 characters per token for SPARQL and IRIs). The evaluation reports Ollama's real count next to the estimate, to check the estimator. Every call logs the estimated size, its share of the window, and which blocks were kept and dropped.

**Why.** The prompt can never overflow, and when something must go, it's the least useful part.

### C7. One LLM call (sparql slot)

The model gets a system prompt (the pruned rules and the output contract) and a user prompt (the cards, the skeleton and the question). It answers in JSON mode: `{"sparql": …}`, or in patch mode `{"base", "edits", "select"}`.

**This is the only place an LLM is used in this mechanism**, plus at most one repair call. Retrieval, linking, pruning, compression, budgeting, binding, checking and execution are all code.

### C8. Context binding by code

**What.** If the query uses `?record`, `?site`, `?eventCode`, `?date` or the four bounding-box variables, code inserts `VALUES` lines at the top of `WHERE` with the real IRI, code, date or numbers.

**Why.** The model never writes an IRI, event code or coordinate it could get wrong. It only has to use the variable names it was told.

### C9. Static check before execution

The query is checked before it is executed, which gives exact feedback without a round-trip to GraphDB:
- it is a SELECT (or ASK);
- it has no update keyword or SERVICE;
- its braces are balanced;
- every `ffo:` / `ffv:` term exists, with the closest real term suggested when one doesn't ("unknown term ffo:hasDetecton; did you mean ffo:hasDetection?");
- every selected variable is used;
- it uses `?record` when a record is selected.

### C10. Execution and one repair

The query runs through the guarded tool `graphdb.run_sparql` (read-only, LIMIT, timeout, ontology terms only). If the static check, GraphDB, an empty result, or too many rows (more than 40 for one record or date) shows a problem, the model gets **one** repair round with the exact problems and its previous query. The repair prompt stays within the same budget.

---

## 3. Where it sits in Wildfire-MAS

1. **Planner (LLM call 1):** intent, slots, and the CQ choice from a menu of 37.
2. **KG agent:** if a CQ was chosen, it runs the tested query (template path, no LLM). If **no CQ fits**, it uses the compact generator (LLM call 2, + at most 1 repair).
3. **Evidence ledger:** rows plus the SPARQL used.
4. **Synthesizer (LLM call 3):** its evidence is now also packed within `synthesis.budget_share` (40%) of the window. Safety-critical evidence is always kept.

The fallback engine is chosen in `settings.yaml` (all keys optional; the defaults are in code):

```yaml
llm:
  context_window: 8192          # must match OLLAMA_CONTEXT_LENGTH
t2s:
  engine: compact               # compact | ffonto (ffonto-v2 "plus") | builtin
  mode: write                   # write | patch (pointer + patch)
  budget_share: 0.35            # prompt ceiling as a share of the window
  max_repairs: 1
  second_chance: false          # true: if compact fails, try ffonto-v2 "plus" once
synthesis:
  budget_share: 0.40
```

---

## 4. How it is evaluated

```bash
wfmas t2s-ablation --model qwen2.5:14b --example-pool dev
```

It runs eleven configurations on the same Part A KG test questions:

| Configuration | Who picks the query | Who writes the SPARQL |
|---|---|---|
| `template_retrieval` | Nothing: the CQ label of the nearest example | Code (tested query) |
| `template_planner` | The planner (LLM) | Code (tested query); this is the main Wildfire-MAS path |
| `zero_shot` | n/a | LLM, no examples |
| `naive` | n/a | LLM, retrieved queries as examples |
| `plus` | n/a | ffonto-v2 "plus" |
| `plus-no_bind` / `plus-no_schema` / `plus-no_template` / `plus-no_feedback` | n/a | ffonto-v2 "plus" with one step off |
| `compact` | n/a | This generator |
| `compact-patch` | n/a | This generator, pointer + patch |

For each configuration, the report gives:
- execution rate, non-empty rate, result precision, recall and F1, and exact match (with 95% CI);
- **prompt tokens (mean / max) and share of the window**;
- median time;
- McNemar tests against `plus`;
- the estimator check (Ollama's real count ÷ the estimate).

This table tests the claim: **a prompt about 8–10× smaller than sending everything, without losing accuracy.** Report it whichever way it comes out; it is a finding either way.
