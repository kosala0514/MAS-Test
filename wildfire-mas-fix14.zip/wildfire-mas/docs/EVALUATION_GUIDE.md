# Wildfire-MAS evaluation guide

This guide covers the 22 evaluation additions (#6–#47) together with the evaluations you already have. It lists the commands in the order to run them, what each one produces, and where to find the numbers for your report.

Everything runs on your own machine, where Ollama, GraphDB and ffonto-v2 are. All commands are run from the `wildfire-mas` project folder. Results go into `runs/<date>_<time>_<name>/`.

---

## 0. One-time setup (15 minutes)

**0.1 Install the update.** Unzip `wildfire-mas-fix13.zip` over your project folder, so it replaces the files with the same names. It does **not** contain `config/settings.yaml` or `config/models.yaml`, so your edits to those files are kept. Then:

```bash
pip install -e .
wfmas --help        # the list now includes rescore, analyze, depth-sweep, t2s-ablation, ...
```

**0.2 Check the services.**

```bash
ollama list                                   # models you can use
curl -s http://localhost:7200/rest/repositories   # GraphDB: must list ffonto and ffonto-eval
echo $FFONTO_V2_PATH                          # Windows PowerShell: echo $env:FFONTO_V2_PATH
```

**0.3 Point every model slot at an installed model.** Open `config/models.yaml`. A slot that names a model you have not pulled makes that step fail. `--model` replaces planner, sparql, synthesizer, verifier and rag_grader for a run, but the defaults should still work. With qwen2.5:14b as the system model:

```yaml
slots:
  planner:       {provider: ollama, model: "qwen2.5:14b", json: true}
  sparql:        {provider: ollama, model: "qwen2.5:14b"}
  synthesizer:   {provider: ollama, model: "qwen2.5:14b", json: true}
  verifier:      {provider: ollama, model: "qwen2.5:14b", json: true}
  rag_grader:    {provider: ollama, model: "qwen2.5:14b", json: true}
  scene_graph:   {provider: ollama, model: "qwen2.5vl:7b", json: true, vision: true}
  figure_reader: {provider: ollama, model: "qwen2.5vl:7b", json: true, vision: true}
  judge:         {provider: ollama, model: "gpt-oss:20b", json: true}
```

**0.4 Choose your models and keep them fixed for the whole study.**

| Role | Model | Why |
|---|---|---|
| Model under test (main runs) | `qwen3:8b` (or your planner winner) | Fast enough for 240-question runs |
| Judge | `gpt-oss:20b` | A different family from the answer model, and **left out of the model comparison** |
| Extra judges (#24) | `gemma4:12b`, `llama3.1:8b` | Different families again |
| Models compared (#8) | `llama3.1:8b`, `qwen3:8b`, `qwen3:14b`, `gemma4:12b`, `deepseek-r1:14b` | Everything installed except the judge |
| Vision | `qwen2.5vl:7b` | Images only; not in the text comparisons |

> Rule: a model never grades its own answers. The commands warn you if it happens.

**Your setup (checked):** RTX 4070 Ti SUPER, 16 GB. qwen3:8b runs 100% on the GPU (5.6 GB), and so does gpt-oss:20b (12 GB), but they don't fit together. That's why Phase 4 answers first and grades afterwards (`--no-judge`, then `wfmas grade`). Before a comparison run, check with `ollama ps` that each compared model shows `100% GPU` on its own.

**The commands below use `qwen3:8b`.** If you chose `qwen2.5:14b` as the model under test (as in 0.3), write that instead everywhere; run folders are then named `..._qwen2.5-14b_...`.

**0.5 Give Ollama an 8,192-token window (once).** Ollama's default is 4,096 tokens. When a prompt is longer, Ollama silently cuts its *beginning*, which is where the instructions and schema are. Wildfire-MAS now keeps every prompt within 35–40% of an 8,192 window (`llm.context_window`), so the server must use that size:

```bash
journalctl -u ollama --since "2026-10-20" | grep -ci "truncat"     # >0 = earlier prompts were cut
sudo systemctl edit ollama          # add the two lines below, save, close
#   [Service]
#   Environment="OLLAMA_CONTEXT_LENGTH=8192"
sudo systemctl restart ollama
ollama run qwen2.5:14b "hi" >/dev/null; ollama ps                    # CONTEXT column: 8192
```

Don't restart Ollama while a run is going; wait until it finishes. A larger window changes nothing for prompts that already fit; it only stops the cutting.

**What changed in the system itself:**
- **Synthesizer confidence:** the synthesizer now also returns a 0–1 confidence (#31).
- **Compact fallback:** when no CQ fits, the KG agent uses the new compact text-to-SPARQL generator (`docs/T2S_COMPACT.md`).
- **Evidence budget:** the synthesizer's evidence is now packed within 40% of the window.

None of this changes the planner, so the planner results stay valid. Use runs made with this version for all end-to-end and text-to-SPARQL numbers, and don't mix them with the earlier smoke test. That changes its prompt slightly, so use runs made with this version for the final numbers. Don't mix them with the earlier smoke test.

---

## Phase 1: Clean data splits (#37, #41, #39)

**Why:** in the current Part A file, about 60% of test questions are about an image, audio clip or weather row that also has questions in the dev split. The planner could therefore see near-copies of test questions as few-shot examples. Fix this first, because every planner number depends on it.

**1.1 See the problem (#41).**

```bash
wfmas overlap --dataset eval/datasets/golden_partA.jsonl
```

This writes `runs/..._overlap.md`. Note the line *"test questions whose record also has dev questions"*: that is your leakage.

**1.2 Rebuild Part A with a record-grouped split (#37).**

```bash
copy eval\datasets\golden_partA.jsonl eval\datasets\golden_partA_old.jsonl    # Windows (Linux/macOS: cp)
wfmas golden-import --group-by source --dev 0.3 --seed 42
wfmas overlap --dataset eval/datasets/golden_partA.jsonl
```

The second report should say **records in both splits: 0**. The split also puts at least one record of every competency question (CQ) into dev, so the planner has an example of each. The one exception is a CQ that only occurs in a single record: it is listed in the report, and you should mention it.

**1.3 Rerun the planner with strict hold-out.** Few-shot examples now come only from the dev split. Run all 7 models, as before:

```bash
wfmas-eval --slot planner --dataset eval/datasets/golden_partA.jsonl --split test --example-pool dev \
  --models llama3.1:8b,qwen3:8b,qwen3:14b,gemma4:12b,gpt-oss:20b,deepseek-r1:14b,phi4:14b
```

Leave out any model you no longer have installed. Time: about 10–70 minutes per model.

Output in `runs/..._planner_pool-dev/`:
- `summary.md`: CQ accuracy, intent accuracy and route accuracy with 95% CI, latency, tokens, McNemar tests.
- `items.jsonl`: every prediction.
- `run.json`: the settings used.

**1.4 Seen vs unseen patterns (#41).**

```bash
wfmas overlap --dataset eval/datasets/golden_partA.jsonl --run runs/<date>_planner_pool-dev
```

For each model, this reports how often the gold CQ was among the retrieved examples ("seen"), and the CQ accuracy for seen and unseen questions. **Report both accuracies.**

**1.5 Several splits (#39).** This checks that the planner result isn't luck of one split.

```bash
wfmas golden-resplit --seeds 1,2,3                       # eval/datasets/splits/golden_partA_s1.jsonl ... s3
wfmas-eval --slot planner --dataset eval/datasets/splits/golden_partA_s1.jsonl --split test --example-pool dev --models qwen3:8b,gemma4:12b --tag s1
wfmas-eval --slot planner --dataset eval/datasets/splits/golden_partA_s2.jsonl --split test --example-pool dev --models qwen3:8b,gemma4:12b --tag s2
wfmas-eval --slot planner --dataset eval/datasets/splits/golden_partA_s3.jsonl --split test --example-pool dev --models qwen3:8b,gemma4:12b --tag s3
wfmas splits-summary runs/<date>_planner_s1_pool-dev runs/<date>_planner_s2_pool-dev runs/<date>_planner_s3_pool-dev
```

This gives the **mean ± SD (min–max)** of each planner metric across splits. For Part B, generate 2 more scenario seeds and run the MAS on each (Phase 4):

```bash
wfmas golden-partb --seed 8 --out-dir eval/datasets/partB_seed8
wfmas golden-partb --seed 9 --out-dir eval/datasets/partB_seed9
```

---

## Phase 2: Retrieval and model-size sweeps (#14, #9, #10)

**2.1 Retrieval depth (#14).** One model, with k = 1, 3, 5, 8 and 15 few-shot examples:

```bash
wfmas depth-sweep --model qwen3:8b --ks 1,3,5,8,15 --example-pool dev
```

Output in `runs/..._depth_qwen3-8b/`:
- `summary.md`: CQ accuracy [CI], intent accuracy, how often the gold CQ was among the examples, latency and tokens, for each k.
- `depth.svg`: the line chart.

Time: about 5 × 15–40 minutes.

**2.2 Model size (#9).** One family, three sizes:

```bash
ollama pull qwen3:4b
wfmas-eval --slot planner --dataset eval/datasets/golden_partA.jsonl --split test --example-pool dev --models qwen3:4b,qwen3:8b,qwen3:14b --tag size
wfmas plot-tradeoff runs/<date>_planner_size_pool-dev --x size
```

**2.3 Accuracy vs time chart (#10).** Use the 7-model run from 1.3:

```bash
wfmas plot-tradeoff runs/<date>_planner_pool-dev
```

This writes `runs/..._tradeoff/tradeoff.svg` (CQ accuracy with CI against median latency, log scale) and `tradeoff.md`. It also works on end-to-end runs (Phase 4.4).

---

## Phase 3: Text-to-SPARQL ablation (#13)

This needs GraphDB with your ffonto-v2 data and `FFONTO_V2_PATH`.

```bash
wfmas t2s-ablation --model qwen3:8b --example-pool dev
```

It runs eleven configurations on the same Part A KG test questions:

| Configuration | Who picks the query | Who writes the SPARQL |
|---|---|---|
| `template_retrieval` | Nothing: the nearest example's CQ | Code (tested query); no LLM |
| `template_planner` | The planner (LLM) | Code (tested query); the main Wildfire-MAS path |
| `zero_shot` | n/a | LLM, no examples |
| `naive` | n/a | LLM, retrieved CQ queries as examples |
| `plus` | n/a | ffonto-v2 "plus" |
| `plus-no_bind`, `plus-no_schema`, `plus-no_template`, `plus-no_feedback` | n/a | "plus" with one step off |
| `compact` | n/a | Wildfire-MAS compact generator (within 35% of the window) |
| `compact-patch` | n/a | Compact, pointer + patch |

Output in `runs/..._t2s_ablation/summary.md`:
- execution rate, non-empty rate, result P / R / F1 and exact match, each with CI;
- **prompt tokens (mean / max) and the largest share of the context window**;
- McNemar tests against `plus`;
- how often retrieval found the right CQ;
- Ollama's real prompt count against the estimate.

The two template rows answer "rule-based template vs LLM-written SPARQL". `plus` vs `compact` answers "does a prompt about 8× smaller lose accuracy?". How the generator works: `docs/T2S_COMPACT.md`.

Time: about 11 × 20–60 minutes; leave it overnight. Use `--limit 100` for a first look.

---

## Phase 4: End-to-end runs (#6, #8, #31, #35, #36)

**Two passes on a 16 GB GPU.** qwen3:8b (5.6 GB) and gpt-oss:20b (12 GB) each fit on your RTX 4070 Ti SUPER, but not together (17.6 GB). With the judge on during a run, Ollama would swap the two models for almost every question. So every end-to-end run below takes two passes:

1. **Answers only**, with `--no-judge`: only the answer model is loaded.
2. **Grading** right after the run, in one pass with the judge:
   ```bash
   wfmas grade runs/<the run folder> --judge-model gpt-oss:20b
   ```

`grade` fills in the judge grades, `correct` and the error attribution, then rewrites `summary.md` and writes `human_check.csv`. The result is the same as a run with the judge on. The ungraded answers are kept in `items_nojudge.jsonl`. Always run `grade` before `rescore`, `analyze` or `e2e-compare`. Grading takes about 2–4 s per answer.

Every e2e run now also records:
- the model's confidence (#31);
- tokens per role, split into prompt and completion (#35);
- IORS rounds and steps;
- GPU power, energy and memory, models in memory, model sizes and throughput (#36). This is `resources.md`; GPU figures need an NVIDIA GPU with `nvidia-smi`.

**4.1 Main comparison, Part B (#6 plain-RAG baseline).**

```bash
wfmas e2e --part B --systems mas,plain_rag,single_agent,llm_only --limit 240 --model qwen3:8b --no-judge --tag main
wfmas grade runs/<date>_e2e_B_qwen3-8b_main --judge-model gpt-oss:20b
```

`plain_rag` (B3) retrieves once with fixed settings (hotspots within 10 km over 1 day, FWI, record facts, 3 passages) and makes one LLM call. It has no planner, IORS, rules, CRM or verifier. Time: about 4 hours.

Output in `runs/..._e2e_B_qwen3-8b_main/`:

| File | Contents |
|---|---|
| `summary.md` | correct, rule check, hazard recall, cited hazard recall, grounded, latency, tool/LLM calls, tokens, McNemar, results per question type, error attribution |
| `items.jsonl` | every answer with its trace |
| `human_check.csv` | 100 answers for your own grading (Phase 7) |
| `resources.md` / `resources.json` | throughput, energy, GPU memory, models in memory and their sizes |
| `run.json` | settings, start and end time, throughput |

**4.2 Ablations.**

```bash
wfmas e2e --part B --systems mas,mas-no_iors,mas-no_crm,mas-no_ialt,mas-no_verifier,mas-no_filter,mas-no_rules --limit 120 --model qwen3:8b --no-judge --tag ablation
wfmas grade runs/<date>_e2e_B_qwen3-8b_ablation --judge-model gpt-oss:20b
```

Time: about 7 × 1 hour.

**4.3 Part A end to end.** Uses the strict pool.

```bash
wfmas e2e --part A --systems mas,ffonto,plain_rag,single_agent --limit 150 --model qwen3:8b --no-judge --example-pool dev --tag partA
wfmas grade runs/<date>_e2e_A_qwen3-8b_partA --judge-model gpt-oss:20b
```

Two Part A details:
- **Same model for B0:** the `ffonto` system (B0) answers with ffonto-v2's own model setting, `LLM_MODEL`, not `--model`. Set `LLM_MODEL=qwen3:8b` before the run (`export LLM_MODEL=qwen3:8b`) so B0 answers with the same model as the others.
- **Same judge as Part B:** with `--no-judge` followed by `wfmas grade`, every Part A system is graded by gpt-oss:20b with the same prompt as Part B.

**4.4 Model comparison inside the full system (#8).** Each model runs every text role, and the judge stays gpt-oss:20b.

Linux/macOS:
```bash
for m in llama3.1:8b qwen3:8b qwen3:14b gemma4:12b deepseek-r1:14b; do
  wfmas e2e --part B --systems mas --limit 240 --model $m --no-judge --tag models
done
```
Windows PowerShell:
```powershell
foreach ($m in "llama3.1:8b","qwen3:8b","qwen3:14b","gemma4:12b","deepseek-r1:14b") {
  wfmas e2e --part B --systems mas --limit 240 --model $m --no-judge --tag models }
```
Then grade each run, and compare them:
```bash
for d in runs/*_e2e_B_*_models; do wfmas grade $d --judge-model gpt-oss:20b; done
wfmas e2e-compare runs/*_e2e_B_*_models
wfmas plot-tradeoff runs/*_e2e_B_*_models
```

`e2e-compare` gives the table with McNemar tests and Holm correction. `plot-tradeoff` gives the accuracy vs latency chart for the full system. Time: about 2 hours per model; deepseek-r1 takes longer.

PowerShell does not expand `*` for programs. List the folders explicitly:
```powershell
$runs = (Get-ChildItem runs -Directory -Filter "*_e2e_B_*_models").FullName
foreach ($d in $runs) { wfmas grade $d --judge-model gpt-oss:20b }
wfmas e2e-compare $runs
wfmas plot-tradeoff $runs
```

> Check each `resources.md`: if a model's "on GPU" size is smaller than its "size in memory", part of it ran on the CPU, so its latency is not comparable.

**4.5 Part B on more seeds (#39).**

```bash
wfmas e2e --part B --systems mas,single_agent --limit 120 --dataset eval/datasets/partB_seed8/golden_partB.jsonl --model qwen3:8b --no-judge --tag seed8
wfmas grade runs/<date>_e2e_B_qwen3-8b_seed8 --judge-model gpt-oss:20b
```

Repeat with `partB_seed9`. Report the MAS – single-agent difference for each seed.

---

## Phase 5: Re-score the saved answers (#18, #20, #22, #24)

These steps don't rerun the systems. They read the saved answers in `items.jsonl` and write `items_rescored.jsonl` and `rescore.md` into the same run folder.

**5.1 Part B main run: fact coverage, automatic fails, rubric and three judges.**

```bash
wfmas rescore runs/<date>_e2e_B_qwen3-8b_main --judges gpt-oss:20b,gemma4:12b,llama3.1:8b --rubric --rubric-model gpt-oss:20b
```

| What | What it means |
|---|---|
| **FCR (#18)** | Share of key facts in each answer. Numbers count within ±5%; yes/no facts, danger class, hazards and an action are also checked. Reported with CI, the share of answers with all facts, and McNemar. |
| **Automatic fail rules (#20)** | yes/no inverted; a hazard the rules did not derive; generic answer; empty answer; declining although the data was there. Gives `strict_correct` = judge correct and no automatic fail. |
| **Several judges (#24)** | Correct rate per judge, spread, pairwise Cohen's κ, Fleiss' κ, and agreement with the run's own judge. |
| **Rubric (#22)** | For the hazard-advice answers (L9): relevance, actionability, safety, completeness and conciseness → 0–100, with bands Excellent / Adequate / Poor / Fail, per system. |

Also included: the correlation between FCR and the judge, with the cases where they disagree. Time: about 20–40 minutes per judge for 960 answers.

Add `--rejudge gpt-oss:20b` to re-grade with the stricter prompt and use it for `strict_correct`.

**5.2 Part A fact coverage.** This needs key facts, which you review once.

```bash
wfmas keyfacts-draft --model gpt-oss:20b                 # eval/datasets/keyfacts_partA.csv
```

Open the CSV and check each `key_facts` cell; facts are separated by `;`. Put `y` in the `reviewed` column. About 2–3 hours for 700 questions, or review only the 150 used in 4.3. Then:

```bash
wfmas rescore runs/<date>_e2e_A_qwen3-8b_partA --keyfacts eval/datasets/keyfacts_partA.csv --judges gpt-oss:20b,gemma4:12b
```

**5.3 Re-score the ablation run as well.** This gives FCR per ablation.

```bash
wfmas rescore runs/<date>_e2e_B_qwen3-8b_ablation --rubric --rubric-model gpt-oss:20b
```

---

## Phase 6: Analyses (#29–#33, #35, #36, #47)

**6.1 One command per run.** Run it after `rescore`, so it can use FCR and rubric bands.

```bash
wfmas analyze runs/<date>_e2e_B_qwen3-8b_main
```

| Item | What `analysis.md` contains |
|---|---|
| **#29 Difficulty** | Results for easy, medium and hard questions: quality, correct, median steps, tool calls, latency |
| **#30 Effort vs quality** | Spearman ρ of steps, tool calls, LLM calls, tokens and IORS rounds against quality, overall and within each question type |
| **#31 Calibration** | Mean confidence vs mean FCR; over- or under-confidence; ECE; table by confidence bin, plus `calibration.svg` |
| **#32 Band matrix** | Single agent → MAS rubric band for each question (better / same / worse), plus `band_matrix.svg` |
| **#35 Tokens** | Mean tokens per system; prompt vs completion; by role |
| **#36 Resources** | Copied from `resources.md` |
| **#33 Worked cases** | In `cases.md`: wrong MAS answers by error type, MAS vs single agent on the same question, and FCR–judge disagreements, each with the plan, steps, notes and tool calls. Choose 4–6 for the report. |

**6.2 Delay analysis (#47).**

```bash
wfmas delay-analysis --run runs/<date>_e2e_B_qwen3-8b_main --measure-area 79.5,5.8,82.0,9.9
```

`--measure-area` fetches the current FIRMS detections for Sri Lanka with your MAP_KEY and measures how old they are. The table shows how far a fire moves during data age plus answer time, at winds of 10–60 km/h, using the 10%-of-wind-speed rule (Cruz & Alexander 2019, *Annals of Forest Science* 76:44), and compares that with the 10 km R09 radius. Without a MAP_KEY, leave out `--measure-area`; it then uses ages of 1, 3 and 6 hours.

---

## Phase 7: Human checks (#27)

**7.1 Your grades: is the LLM judge trustworthy?** Open `human_check.csv` from the main run. Fill `human_grade` (correct / partial / wrong / no_answer) for the 100 answers, without looking at `judge_grade` first (about 2 hours). Then:

```bash
wfmas e2e-agreement runs/<date>_e2e_B_qwen3-8b_main/human_check.csv
```

This reports agreement and Cohen's κ (4 grades, and correct vs not). Target κ ≥ 0.6.

**7.2 Expert rating.** For example, a Forest Department or DMC officer.

```bash
wfmas expert-sheet runs/<date>_e2e_B_qwen3-8b_main -n 20
```

- Send `expert_sheet.csv` to the expert. It shows answers from all systems, shuffled, with no system names. The expert scores relevance, actionability, safety, completeness and conciseness from 1 to 10, plus fail (y) and a comment.
- Keep `expert_key.csv` yourself and don't share it.

When the sheet comes back, save it into the run folder and run:

```bash
wfmas expert-agreement runs/<date>_e2e_B_qwen3-8b_main
```

This gives the expert's mean score per system, and the expert vs LLM rubric comparison: Spearman ρ, κ on bands, and the difference per dimension. Start asking for an expert early; their time is the slowest part of the whole plan.

---

## Phase 8: Where each result comes from

| # | Result | Command | File |
|---|---|---|---|
| 37 | Leakage before/after; strict planner accuracy | `overlap`, `golden-import --group-by source`, `wfmas-eval --example-pool dev` | `*_overlap.md`, `*_planner_pool-dev/summary.md` |
| 41 | Seen vs unseen CQ accuracy | `overlap --run` | `*_overlap.md` |
| 39 | Mean ± SD over splits; Part B seeds | `golden-resplit`, `splits-summary`, `golden-partb --seed` | `*_splits_summary.md`, seed run summaries |
| 14 | CQ accuracy vs k | `depth-sweep` | `*_depth_*/summary.md`, `depth.svg` |
| 9 | Accuracy vs model size | planner sweep + `plot-tradeoff --x size` | `tradeoff.md/.svg` |
| 10 | Accuracy vs latency | `plot-tradeoff` | `tradeoff.md/.svg` |
| 13 | Text-to-SPARQL step ablation | `t2s-ablation` | `*_t2s_ablation/summary.md` |
| 6 | Plain-RAG baseline | `e2e --systems ...,plain_rag` | `summary.md` |
| 8 | Models inside the full system | `e2e --model` × 5, `e2e-compare` | compare output, `tradeoff.svg` |
| 31 | Calibration | `e2e` (automatic) + `analyze` | `analysis.md`, `calibration.svg` |
| 35 | Tokens | `e2e` (automatic) + `analyze` | `summary.md`, `analysis.md` |
| 36 | Throughput, energy, memory, storage | `e2e` (automatic) | `resources.md` |
| 18 | Fact Coverage Rate | `rescore` (+ `keyfacts-draft` for Part A) | `rescore.md` |
| 20 | Automatic fails, strict correct | `rescore` | `rescore.md` |
| 22 | Rubric 0–100 with bands | `rescore --rubric` | `rescore.md` |
| 24 | Several judges, κ | `rescore --judges` | `rescore.md` |
| 27 | Your κ; expert vs LLM | `e2e-agreement`, `expert-sheet`, `expert-agreement` | console, `expert_agreement.md` |
| 29 | Difficulty tiers | `analyze` | `analysis.md` |
| 30 | Effort vs quality | `analyze` | `analysis.md` |
| 32 | Before/after band matrix | `rescore --rubric` + `analyze` | `analysis.md`, `band_matrix.svg` |
| 33 | Worked cases | `analyze` | `cases.md` |
| 47 | Delay / drift | `delay-analysis` | `*_delay_analysis.md` |

**Suggested schedule** (about one week; long runs go overnight):

| Day | What |
|---|---|
| 1 | Phase 0, Phase 1.1–1.4 (planner run overnight) |
| 2 | Phase 1.5, Phase 2 (overnight), start Phase 3 |
| 3 | Phase 4.1 main run + 4.2 ablations (overnight) |
| 4–5 | Phase 4.4 model comparison (two nights) |
| 6 | Phase 5 re-scoring, Phase 6 analyses, Phase 7.1 your grades |
| 7 | Phase 4.3/4.5 if time allows; collect results; expert sheet out |

**If something fails**
- *"model … not usable"*: the model isn't pulled or Ollama isn't running. Run `ollama list`, then `ollama pull <tag>`.
- *Many errors in a summary*: read the section "Most frequent step / tool errors" at the end of `summary.md`. These are setup problems, usually GraphDB or a model slot pointing at a missing model.
- *A run stopped halfway*: rerun the same command. Runs are independent, and each one writes its own folder.
- *"--example-pool dev needs …"*: run `wfmas golden-import --group-by source` first.
- *No GPU figures in `resources.md`*: there is no NVIDIA GPU or `nvidia-smi`. Throughput, memory and storage are still reported.
