"""Compact text-to-SPARQL fallback: catalog cards, retrieval, pruning, compression, budget, patch, binding,
static check, repair loop, and the KG agent using it."""
import asyncio
import json

from fakes import ScriptedBus

from wildfire_mas.kg import t2s_compact as tc

FFO = "http://purl.org/ffonto#"
FFV = "http://purl.org/ffonto/vocab#"
PX = {"ffo": FFO, "ffv": FFV, "ffonto": FFO, "ffontov": FFV}

CQ17 = f"""PREFIX ffonto: <{FFO}>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
# required PPE that is missing
SELECT ?item ?d WHERE {{
  ?record ffonto:hasDetection ?d .
  ?d ffonto:detects ?item .
  ?item skos:broader* ffontov:PPE .
  OPTIONAL {{ ?item rdfs:label ?lab }}
}} LIMIT 100"""
CQL01 = f"""SELECT ?h ?lat ?lon WHERE {{ ?h a <{FFO}SatelliteHotspot> ; <{FFO}latitude> ?lat .
  FILTER(?lat >= {{{{lat_min}}}}) }}"""


def _catalog(extra_props: int = 0):
    classes = [{"c": FFO + "ImageRecord", "label": "image record", "sup": FFO + "Record"},
               {"c": FFO + "Record", "label": "record"}, {"c": FFO + "Detection", "label": "detection"},
               {"c": FFO + "SatelliteHotspot", "label": "satellite hotspot"}]
    props = [{"p": FFO + "hasDetection", "domain": FFO + "ImageRecord", "range": FFO + "Detection"},
             {"p": FFO + "hasDetection", "domain": FFO + "AudioRecord", "range": FFO + "Detection"},
             {"p": FFO + "detects", "domain": FFO + "Detection", "range": "http://www.w3.org/2004/02/skos/core#Concept"},
             {"p": FFO + "latitude", "label": "latitude"}]
    props += [{"p": FFO + f"filler{i}Property", "label": f"filler property {i}", "domain": FFO + "Record"}
              for i in range(extra_props)]
    concepts = [{"c": FFV + "PPE", "pref": "personal protective equipment", "alt": "PPE"},
                {"c": FFV + "Helmet", "pref": "helmet", "broader": FFV + "PPE"},
                {"c": FFV + "Smoke", "pref": "smoke", "alt": "plume"}]
    queries = [{"id": "CQ17", "question": "Which required PPE is missing for the people in the record?", "sparql": CQ17,
                "examples": ["Is anyone without a helmet?"]},
               {"id": "CQL01", "question": "Which satellite hotspots are near a location?", "sparql": CQL01,
                "intents": ["situational_awareness"]}]
    return tc.build_catalog(classes, props, concepts, queries, PX, [FFO + "SomeIndividual"])


def test_catalog_cards_and_compression():
    cat = _catalog()
    by = cat.by_id
    assert by["ffo:hasDetection"].text == "ffo:hasDetection: ffo:AudioRecord | ffo:ImageRecord → ffo:Detection"
    assert by["ffo:ImageRecord"].text.startswith("ffo:ImageRecord ⊂ ffo:Record")
    assert by["ffv:Helmet"].text == 'ffv:Helmet "helmet" ⊂ ffv:PPE'
    assert by["CQ17"].links == ["ffo:detects", "ffo:hasDetection", "ffv:PPE"]
    assert "ffo:SomeIndividual" in cat.known_terms()
    sk = tc.skeleton(CQ17)
    assert "PREFIX" not in sk and "LIMIT" not in sk and "#" not in sk and "rdfs:label" not in sk
    assert tc.est_tokens(sk) < tc.est_tokens(CQ17) * 0.75
    assert tc.select_vars(CQ17) == ["item", "d"]
    assert tc.Catalog.from_dict(json.loads(json.dumps(cat.to_dict()))).known_terms() == cat.known_terms()


def test_linking_prefers_hints_and_expands_one_hop():
    cat = _catalog()
    linked = tc.link_schema(cat, "Is anyone in the selected record missing a helmet?", ["CQ17"], "data_lookup")
    assert linked["queries"][0].id == "CQ17"
    assert "CQL01" not in [c.id for c in linked["queries"]]          # pruned: live CQ does not serve data_lookup
    ids = [c.id for c in linked["schema"]]
    assert {"ffo:hasDetection", "ffo:detects"} <= set(ids) and "ffo:Detection" in ids    # terms of CQ17 + 1 hop
    assert linked["concepts"][0].id == "ffv:Helmet"


def test_prompt_stays_within_budget_and_drops_low_priority_first():
    cat = _catalog(extra_props=300)
    linked = tc.link_schema(cat, "Which filler property and detection does the record have?", ["CQ17"],
                            max_schema=200)
    sys_, user, st = tc.build_prompt("q?", linked, {"record": "urn:r"}, context_window=8192, budget_share=0.35)
    assert st["est_tokens"] <= st["budget_tokens"] and st["share_of_window"] <= 0.35
    assert st["dropped"] and "question" in st["kept"] and "example:CQ17" in st["kept"]
    assert tc.RULES_RECORD in sys_ and tc.RULES_DATE not in sys_                      # pruned rule blocks
    small = tc.build_prompt("q?", linked, {}, context_window=2048, budget_share=0.30)[2]
    assert small["est_tokens"] <= 0.30 * 2048 + 1 and len(small["dropped"]) > len(st["dropped"])


def test_static_check_patch_and_binding():
    cat = _catalog()
    probs = tc.static_check("SELECT ?x ?y WHERE { ?record ffo:hasDetecton ?x }", cat, {"record": "urn:r"})
    assert any("did you mean ffo:hasDetection" in p for p in probs) and any("?y is selected" in p for p in probs)
    assert any("must use ?record" in p for p in tc.static_check("SELECT ?x WHERE { ?a ffo:detects ?x }", cat,
                                                                   {"record": "urn:r"}))
    assert tc.static_check("DELETE WHERE { ?a ?b ?c }", cat, {})
    q, probs = tc.apply_patch(cat, {"base": "CQ17", "edits": [{"replace": "ffontov:PPE", "with": "ffontov:Helmet"},
                                                              {"add": "FILTER(BOUND(?d))"}, {"remove": "OPTIONAL"}],
                                    "select": ["item"]})
    assert not probs and "ffontov:Helmet" in q and "FILTER(BOUND(?d))" in q and "OPTIONAL" not in q
    assert q.split("WHERE")[0].strip().endswith("?item")
    assert tc.apply_patch(cat, {"base": "CQ99"})[0] is None
    b, applied = tc.bind_context("SELECT ?h WHERE { ?h ffo:latitude ?lat . FILTER(?lat >= ?lat_min && ?lat <= ?lat_max "
                                 "&& ?lon >= ?lon_min && ?lon <= ?lon_max) ?record ffo:x ?h }",
                                 {"record": "urn:r", "bbox": (80.0, 7.0, 81.0, 8.0)})
    assert "VALUES ?record { <urn:r> }" in b and "VALUES (?lat_min ?lat_max ?lon_min ?lon_max) { (7.0 8.0 80.0 81.0) }" in b
    assert set(applied) == {"record", "bbox"}
    assert tc.add_prefixes("SELECT ?x WHERE { ?x ffonto:a ffv:B }", cat.prefixes).startswith("PREFIX ffonto:")


def test_generator_repairs_once_and_patch_mode():
    cat = _catalog()
    replies = [{"sparql": "SELECT ?item WHERE { ?record ffo:hasDetecton ?d . ?d ffo:detects ?item }"},
               {"sparql": "SELECT ?item WHERE { ?record ffo:hasDetection ?d . ?d ffo:detects ?item }"}]
    prompts, ran = [], []

    async def chat(system, user):
        prompts.append(user)
        return replies.pop(0)

    def run(q):
        ran.append(q)
        return {"ok": True, "rows": [{"item": FFV + "Helmet"}], "sparql": q}

    out = asyncio.run(tc.generate("Is a helmet visible in the record?", cat, chat, run, {"record": "urn:r"},
                                  hints=["CQ17"]))
    assert out["ok"] and len(out["attempts"]) == 2 and "did you mean ffo:hasDetection" in prompts[1]
    assert len(ran) == 1 and "VALUES ?record { <urn:r> }" in ran[0] and "PREFIX ffo:" in ran[0]
    assert out["prompt_stats"]["share_of_window"] <= 0.35

    async def chat_patch(system, user):
        assert "pointer only" in user or "Closest tested query" in user
        return {"base": "CQ17", "edits": [{"replace": "ffontov:PPE", "with": "ffontov:Helmet"}]}

    out = asyncio.run(tc.generate("Is a helmet visible?", cat, chat_patch, run, {"record": "urn:r"}, hints=["CQ17"],
                                  mode="patch"))
    assert out["ok"] and out["mode_used"] == "patch:CQ17" and "ffontov:Helmet" in out["sparql"]

    async def empty(system, user):
        return {"sparql": "SELECT ?item WHERE { ?record ffo:hasDetection ?d . ?d ffo:detects ?item }"}

    out = asyncio.run(tc.generate("q", cat, empty, lambda q: {"ok": True, "rows": []}, {"record": "urn:r"}))
    assert out["ok"] and out["rows"] == [] and "no rows" in out["problems"][0] and len(out["attempts"]) == 2


def test_kg_agent_uses_compact_fallback(settings):
    from wildfire_mas.agents.state import EvidenceLedger, PlanStep, Request
    from wildfire_mas.agents.workers import Deps, kg_agent
    from wildfire_mas.kg.cq import CQCatalog
    from wildfire_mas.llm import ScriptedLLM

    cat = _catalog()
    seen = {}

    def run_sparql(args):
        seen["q"] = args["query"]
        return {"ok": True, "rows": [{"item": "helmet"}], "sparql": args["query"]}

    bus = ScriptedBus({"kg.schema_catalog": cat.to_dict(), "kg.run_sparql": run_sparql})
    llm = ScriptedLLM(settings, {"sparql": lambda m: json.dumps(
        {"sparql": "SELECT ?item WHERE { ?record ffo:hasDetection ?d . ?d ffo:detects ?item }"})})
    d = Deps(bus, llm, settings, CQCatalog.load(settings), {})
    step = PlanStep(id="s1", agent="kg", task="t", params={"cq": None, "question": "Is a helmet visible?",
                                                          "hints": ["CQ17"], "intent": "data_lookup"})
    led = EvidenceLedger()
    r = asyncio.run(kg_agent(step, Request("Is a helmet visible?", record="urn:r"), {}, led, d))
    assert r.ok and led.items[0].source == "compact text-to-SPARQL" and "VALUES ?record" in seen["q"]
    assert any(n.startswith("T2S ") for n in r.notes) and any("of 8192" in n for n in r.notes)


def test_toolkit_builds_catalog_from_the_graph(settings):
    from fakes import RoutingStore

    from wildfire_mas.tools.toolkit import Toolkit

    store = RoutingStore([("owl:Class", [{"c": FFO + "SatelliteHotspot", "label": "satellite hotspot"}]),
                          ("owl:ObjectProperty", [{"p": FFO + "acquiredAt", "domain": FFO + "SatelliteHotspot"}]),
                          ("skos:Concept", [{"c": FFV + "Smoke", "pref": "smoke"}])])
    tk = Toolkit(settings)
    tk.__dict__["store"] = store
    out = tk.kg_schema_catalog()
    cat = tc.Catalog.from_dict(out)
    assert {"ffo:SatelliteHotspot", "ffo:acquiredAt", "ffv:Smoke"} <= cat.known_terms()
    live = [c for c in cat.cards if c.kind == "query" and c.id.startswith("CQL")]
    assert len(live) == 11 and not any("{{" in (c.full or "") for c in live)
    assert out["stats"]["cards"]["query"] >= 11 and tk.kg_schema_catalog() is out          # cached
