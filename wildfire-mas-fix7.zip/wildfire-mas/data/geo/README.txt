Put enrichment layers here (see README: hotspot enrichment). Large files are not committed.
