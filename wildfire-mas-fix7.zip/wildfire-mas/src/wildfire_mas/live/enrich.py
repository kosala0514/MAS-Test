"""Hotspot enrichment: where is it, what is burning there, and is it likely a wildfire?

FIRMS gives a point (the centre of a ~375 m VIIRS / ~1 km MODIS pixel), a time and a fire
intensity. It does not say which forest, district or village that is, or whether the land is
forest or a paddy field. This module adds that from offline map layers (downloaded once; no
API calls while answering a question):

  layer                 typical source (free)                          gives
  protected_areas       WDPA (protectedplanet.net) or OSM export        "Knuckles Forest Reserve" (designation)
  forests               Forest Department reserves / OSM landuse=forest "… Forest Reserve"
  admin                 GADM / HDX boundaries                           province, district (, DS division)
  places                GeoNames country file (e.g. LK.txt) or a CSV    "4.2 km NE of Ella"
  land_cover            ESA WorldCover 10 m GeoTIFF tiles (rasterio)    shares of tree cover, grassland, cropland …
                        or a GeoJSON of land-cover polygons
  elevation             any DEM GeoTIFF (e.g. SRTM)                     metres above sea level

Every layer is optional. The *fire context* is then decided from the evidence, with reasons:

  wildfire_likely              inside a protected area / forest reserve, or mostly wildland cover
                               (tree, shrub, grass, wetland, mangrove)
  agricultural_burning_likely  mostly cropland
  settlement_fire_likely       a large share of built-up land
  mixed_land_cover             none of the above dominates
  unknown_land_cover           no land-cover layer configured / point outside it
  not_vegetation_fire          the hotspot filter already says it is not a vegetation fire

This is a *likelihood with reasons*, not ground truth: satellite pixels cannot see who lit a fire.
"""
from __future__ import annotations

import csv
import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .geo import haversine_km, point_in_polygon

WORLDCOVER = {10: "tree_cover", 20: "shrubland", 30: "grassland", 40: "cropland", 50: "built_up",
              60: "bare_sparse", 70: "snow_ice", 80: "water", 90: "herbaceous_wetland", 95: "mangroves",
              100: "moss_lichen"}
WILDLAND = {"tree_cover", "shrubland", "grassland", "herbaceous_wetland", "mangroves", "moss_lichen"}
CONTEXTS = ("wildfire_likely", "agricultural_burning_likely", "settlement_fire_likely", "mixed_land_cover",
            "unknown_land_cover", "not_vegetation_fire")
PIXEL_M = {"VIIRS": 375, "MODIS": 1000, "LANDSAT": 30}
DIRS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:60] or "unnamed"


def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2, dl = math.radians(lat1), math.radians(lat2), math.radians(lon2 - lon1)
    x = math.sin(dl) * math.cos(p2)
    y = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(x, y)) + 360) % 360


def compass(deg: float) -> str:
    return DIRS[int((deg + 22.5) // 45) % 8]


# ------------------------------------------------------------------------------ polygon layers
@dataclass
class _Feature:
    props: dict
    polys: list[list[list]]       # each polygon: [outer ring, hole, hole, ...] as [[lon, lat], ...]
    bbox: tuple[float, float, float, float]
    area: float                   # bbox area, used to prefer the most specific of nested matches


class PolygonLayer:
    """GeoJSON polygons with a 1-degree grid index; `find` returns the most specific feature."""

    def __init__(self, features: list[_Feature]):
        self.features = features
        self.grid: dict[tuple[int, int], list[int]] = defaultdict(list)
        for i, f in enumerate(features):
            w, s, e, n = f.bbox
            for gy in range(math.floor(s), math.floor(n) + 1):
                for gx in range(math.floor(w), math.floor(e) + 1):
                    self.grid[(gy, gx)].append(i)

    @classmethod
    def load(cls, path: Path) -> "PolygonLayer":
        gj = json.loads(Path(path).read_text(encoding="utf-8"))
        feats = gj.get("features", [gj]) if gj.get("type") == "FeatureCollection" else [gj]
        out = []
        for f in feats:
            geom = f.get("geometry", f)
            if not geom:
                continue
            polys = [geom["coordinates"]] if geom["type"] == "Polygon" else \
                geom["coordinates"] if geom["type"] == "MultiPolygon" else []
            polys = [p for p in polys if p and p[0]]
            if not polys:
                continue
            xs = [pt[0] for p in polys for pt in p[0]]
            ys = [pt[1] for p in polys for pt in p[0]]
            bbox = (min(xs), min(ys), max(xs), max(ys))
            out.append(_Feature(f.get("properties") or {}, polys, bbox, (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])))
        return cls(out)

    def find(self, lat: float, lon: float) -> dict | None:
        best: _Feature | None = None
        for i in self.grid.get((math.floor(lat), math.floor(lon)), ()):
            f = self.features[i]
            w, s, e, n = f.bbox
            if not (w <= lon <= e and s <= lat <= n):
                continue
            for poly in f.polys:
                if point_in_polygon(lat, lon, poly[0]) and not any(point_in_polygon(lat, lon, h) for h in poly[1:]):
                    if best is None or f.area < best.area:
                        best = f
                    break
        return best.props if best else None


def _field(props: dict, names: list[str]) -> str | None:
    for n in names:
        v = props.get(n)
        if v not in (None, ""):
            return str(v)
    return None


# ------------------------------------------------------------------------------ places
class PlaceIndex:
    """Nearest named place. Reads a GeoNames country dump (tab-separated, feature class P) or a
    CSV with name,lat,lon[,population]."""

    def __init__(self, places: list[tuple[str, float, float, int]]):
        self.places = places
        self.grid: dict[tuple[int, int], list[int]] = defaultdict(list)
        for i, (_, la, lo, _) in enumerate(places):
            self.grid[(math.floor(la * 2), math.floor(lo * 2))].append(i)

    @classmethod
    def load(cls, path: Path, min_population: int = 0) -> "PlaceIndex":
        rows: list[tuple[str, float, float, int]] = []
        text = Path(path).read_text(encoding="utf-8")
        if "\t" in text.splitlines()[0]:      # GeoNames: 0 id, 1 name, 4 lat, 5 lon, 6 class, 14 population
            for line in text.splitlines():
                c = line.split("\t")
                if len(c) > 14 and c[6] == "P":
                    pop = int(c[14] or 0)
                    if pop >= min_population:
                        rows.append((c[1], float(c[4]), float(c[5]), pop))
        else:
            for r in csv.DictReader(x for x in text.splitlines() if x.strip() and not x.startswith("#")):
                rows.append((r["name"], float(r["lat"]), float(r["lon"]), int(r.get("population") or 0)))
        return cls(rows)

    def nearest(self, lat: float, lon: float, max_km: float = 50.0) -> dict | None:
        gy, gx = math.floor(lat * 2), math.floor(lon * 2)
        best = None
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                for i in self.grid.get((gy + dy, gx + dx), ()):
                    name, la, lo, pop = self.places[i]
                    d = haversine_km(lat, lon, la, lo)
                    if d <= max_km and (best is None or d < best[0]):
                        best = (d, name, la, lo)
        if best is None:
            return None
        d, name, la, lo = best
        direction = compass(bearing_deg(la, lo, lat, lon))
        text = f"{d:.1f} km {direction} of {name}" if d >= 0.5 else f"at {name}"
        return {"name": name, "km": round(d, 1), "direction": direction, "text": text}


# ------------------------------------------------------------------------------ land cover / elevation
class RasterSampler:
    """ESA WorldCover (or any categorical / DEM GeoTIFF). Needs `rasterio` (pip install rasterio).
    `path` may be one file or a folder of tiles; the tile containing the point is used."""

    def __init__(self, path: Path):
        import rasterio  # noqa: F401  (fail early with a clear message if missing)

        p = Path(path)
        self.files = sorted(p.glob("*.tif")) if p.is_dir() else [p]
        self._open: dict[Path, Any] = {}
        self._bounds: dict[Path, Any] = {}

    def _ds(self, lat: float, lon: float):
        import rasterio

        for f in self.files:
            if f not in self._bounds:
                with rasterio.open(f) as ds:
                    self._bounds[f] = ds.bounds
            b = self._bounds[f]
            if b.left <= lon < b.right and b.bottom < lat <= b.top:
                if f not in self._open:
                    self._open[f] = rasterio.open(f)
                return self._open[f]
        return None

    def window(self, lat: float, lon: float, radius_m: float):
        from rasterio.windows import from_bounds

        ds = self._ds(lat, lon)
        if ds is None:
            return None
        dlat = radius_m / 111_320
        dlon = radius_m / (111_320 * max(0.01, math.cos(math.radians(lat))))
        win = from_bounds(lon - dlon, lat - dlat, lon + dlon, lat + dlat, transform=ds.transform)
        return ds.read(1, window=win, boundless=True, fill_value=0)

    def shares(self, lat: float, lon: float, radius_m: float) -> dict[str, float] | None:
        arr = self.window(lat, lon, radius_m)
        if arr is None or arr.size == 0:
            return None
        vals, counts = __import__("numpy").unique(arr, return_counts=True)
        tot = sum(int(c) for v, c in zip(vals, counts) if int(v) in WORLDCOVER)
        if not tot:
            return None
        return {WORLDCOVER[int(v)]: round(int(c) / tot, 3) for v, c in zip(vals, counts) if int(v) in WORLDCOVER}

    def value(self, lat: float, lon: float) -> float | None:
        arr = self.window(lat, lon, 45)   # a few DEM pixels around the point
        if arr is None or arr.size == 0:
            return None
        return float(arr[arr.shape[0] // 2, arr.shape[1] // 2])


class VectorLandCover:
    """Land cover from polygons (e.g. an OSM landuse export): samples a 5 x 5 grid over the pixel."""

    def __init__(self, layer: PolygonLayer, class_field: str, mapping: dict[str, str]):
        self.layer, self.field, self.mapping = layer, class_field, mapping

    def shares(self, lat: float, lon: float, radius_m: float) -> dict[str, float] | None:
        dlat = radius_m / 111_320
        dlon = radius_m / (111_320 * max(0.01, math.cos(math.radians(lat))))
        c: Counter = Counter()
        for i in range(5):
            for j in range(5):
                p = self.layer.find(lat - dlat + i * dlat / 2, lon - dlon + j * dlon / 2)
                if p:
                    raw = str(p.get(self.field, "")).lower()
                    c[self.mapping.get(raw, raw)] += 1
        n = sum(c.values())
        return {k: round(v / n, 3) for k, v in c.items()} if n else None


# ------------------------------------------------------------------------------ enricher
class HotspotEnricher:
    def __init__(self, cfg: dict, protected=None, forests=None, admin=None, places=None, land_cover=None,
                 elevation=None, warnings: list[str] | None = None):
        self.cfg = cfg
        self.protected, self.forests, self.admin = protected, forests, admin
        self.places, self.land_cover, self.elevation = places, land_cover, elevation
        self.warnings = warnings or []

    @property
    def configured(self) -> bool:
        return any(x is not None for x in (self.protected, self.forests, self.admin, self.places,
                                           self.land_cover, self.elevation))

    @classmethod
    def from_settings(cls, settings) -> "HotspotEnricher":
        cfg = settings.get("enrichment") or {}
        warn: list[str] = []

        def path(key):
            v = cfg.get(key)
            p = settings.path(v) if v else None
            if v and not (p and p.exists()):
                warn.append(f"enrichment.{key}: {v} not found")
                return None
            return p

        def poly(key):
            p = path(key)
            try:
                return PolygonLayer.load(p) if p else None
            except Exception as e:  # noqa: BLE001
                warn.append(f"enrichment.{key}: {e}")
                return None

        lc = None
        p = path("land_cover")
        if p:
            if p.is_dir() or p.suffix.lower() in (".tif", ".tiff"):
                try:
                    lc = RasterSampler(p)
                except ImportError:
                    warn.append("enrichment.land_cover is a GeoTIFF but rasterio is not installed (pip install rasterio)")
            else:
                lc = VectorLandCover(PolygonLayer.load(p), cfg.get("land_cover_class_field", "landuse"),
                                     cfg.get("land_cover_mapping") or {})
        el = None
        p = path("elevation")
        if p:
            try:
                el = RasterSampler(p)
            except ImportError:
                warn.append("enrichment.elevation needs rasterio (pip install rasterio)")
        pl = path("places")
        return cls(cfg, poly("protected_areas"), poly("forests"), poly("admin"),
                   PlaceIndex.load(pl, int(cfg.get("places_min_population", 0))) if pl else None,
                   lc, el, warn)

    # -- one point -------------------------------------------------------------------
    def describe_point(self, lat: float, lon: float, instrument: str | None = None) -> dict:
        cfg = self.cfg
        inst = (instrument or "VIIRS").upper()
        pix = next((m for k, m in PIXEL_M.items() if k in inst), 375)
        e: dict[str, Any] = {"lat": lat, "lon": lon, "uncertainty_m": pix}
        if self.protected:
            p = self.protected.find(lat, lon)
            if p:
                e["protected_area"] = {"name": _field(p, cfg.get("protected_name_fields", ["NAME", "name", "ORIG_NAME"])) or "unnamed",
                                       "designation": _field(p, cfg.get("protected_designation_fields",
                                                                        ["DESIG_ENG", "DESIG", "designation", "protect_class"]))}
        if self.forests:
            p = self.forests.find(lat, lon)
            if p:
                e["forest"] = {"name": _field(p, cfg.get("forest_name_fields", ["NAME", "name"])) or "unnamed forest"}
        if self.admin:
            p = self.admin.find(lat, lon)
            if p:
                fields = cfg.get("admin_fields", {"province": ["NAME_1", "ADM1_EN"], "district": ["NAME_2", "ADM2_EN"],
                                                  "division": ["NAME_3", "ADM3_EN"]})
                e["admin"] = {k: v for k, names in fields.items() if (v := _field(p, names))}
        if self.places:
            n = self.places.nearest(lat, lon, float(cfg.get("places_max_km", 50)))
            if n:
                e["place"] = n
        if self.land_cover:
            radius = float(cfg.get("land_cover_radius_m") or pix / 2)
            try:
                sh = self.land_cover.shares(lat, lon, radius)
            except Exception as ex:  # noqa: BLE001
                sh = None
                self.warnings.append(f"land cover lookup failed: {ex}")
            if sh:
                e["land_cover"] = {"dominant": max(sh, key=sh.get), "shares": sh,
                                   "wildland_share": round(sum(v for k, v in sh.items() if k in WILDLAND), 3)}
        if self.elevation:
            try:
                v = self.elevation.value(lat, lon)
                if v is not None and -500 < v < 9000:
                    e["elevation_m"] = round(v)
            except Exception:  # noqa: BLE001
                pass
        return e

    def context(self, e: dict, category: str | None) -> tuple[str, list[str]]:
        cfg = self.cfg
        if category and category != "likely_vegetation_fire":
            return "not_vegetation_fire", [f"hotspot filter: {category.replace('_', ' ')}"]
        reasons = []
        pa, fo, lc = e.get("protected_area"), e.get("forest"), e.get("land_cover")
        if pa:
            reasons.append(f"inside protected area {pa['name']}" + (f" ({pa['designation']})" if pa.get("designation") else ""))
        if fo:
            reasons.append(f"inside forest {fo['name']}")
        if lc:
            sh = lc["shares"]
            top = ", ".join(f"{k.replace('_', ' ')} {v:.0%}" for k, v in sorted(sh.items(), key=lambda x: -x[1])[:3])
            reasons.append(f"land cover around the detection: {top}")
            built, crop, wild = sh.get("built_up", 0), sh.get("cropland", 0), lc["wildland_share"]
            if built >= float(cfg.get("built_up_min_share", 0.3)) and not (pa or fo):
                return "settlement_fire_likely", reasons
            if pa or fo or wild >= float(cfg.get("wildland_min_share", 0.5)):
                return "wildfire_likely", reasons
            if crop >= float(cfg.get("cropland_min_share", 0.5)):
                return "agricultural_burning_likely", reasons
            return "mixed_land_cover", reasons
        if pa or fo:
            return "wildfire_likely", reasons
        return "unknown_land_cover", reasons or ["no land-cover layer for this location"]

    @staticmethod
    def summary(e: dict) -> str:
        parts = []
        if e.get("protected_area"):
            parts.append(f"in {e['protected_area']['name']}")
        elif e.get("forest"):
            parts.append(f"in {e['forest']['name']}")
        if e.get("place"):
            parts.append(e["place"]["text"])
        adm = e.get("admin") or {}
        if adm.get("district"):
            parts.append(f"{adm['district']} District" + (f", {adm['province']}" if adm.get("province") else ""))
        if e.get("land_cover"):
            parts.append(f"{e['land_cover']['dominant'].replace('_', ' ')}")
        if e.get("elevation_m") is not None:
            parts.append(f"{e['elevation_m']} m a.s.l.")
        ctx = e.get("context", "").replace("_", " ")
        return (f"{ctx}: " if ctx else "") + "; ".join(parts) + f" (position ±{e['uncertainty_m']} m)"

    def enrich(self, h) -> dict:
        e = self.describe_point(h.latitude, h.longitude, h.instrument)
        e["context"], e["context_reasons"] = self.context(e, h.category)
        e["summary"] = self.summary(e)
        h.enrichment = e
        return e

    def enrich_all(self, hotspots) -> Counter:
        return Counter(self.enrich(h)["context"] for h in hotspots)
