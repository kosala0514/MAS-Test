# wildfire-mas

Multi-agent wildfire screening on top of the FFOnto knowledge graph: a planner, an
orchestrator (LangGraph), worker agents that call tools only through MCP, live NASA FIRMS
hotspots and fire weather, rules R09–R12, and a synthesizer + verifier that cite every
claim. The LLM plans and words the answer; the facts come from the KG, the rules, live
sources, or cited documents.

```
question ─► PLANNER ─► plan (typed DAG) ─► ORCHESTRATOR (LangGraph: parallel waves, timeouts)
              intent, urgency,                │
              slots (few-shot)    ┌───────────┼─────────────┬──────────────┬─────────────┐
                                  ▼           ▼             ▼              ▼             ▼
                               resolve    live_data       risk            kg            rag
                               record→    FIRMS + FWI    rules R09–R12   CQs + IORS,   BM25/bge-m3,
                               site/point (IORS radius)  hazards         NL→SPARQL     CRAG, figures
                                  │           │             │              │             │
                                  └─── MCP: graphdb-mcp · firms-mcp · weather-mcp · rag-mcp ───┘
                                                                │
                     evidence ledger (KG1, LIVE2, R09-1, D3, F1, O1 …) ─► SYNTHESIZER (CRM schema per intent)
                                                                         ─► VERIFIER (cites, safety recall) ─► answer
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,validate]"
cp .env.example .env            # put FIRMS_MAP_KEY, GraphDB URL/repo here
ollama pull qwen2.5:14b && ollama pull qwen2.5:7b && ollama pull qwen2.5vl:7b
pytest                          # 24 offline tests, no network or GPU needed
```

Load the new ontology files into GraphDB (after aligning them, see below):

| File | Named graph |
|---|---|
| `ontology/ffonto-live.ttl` | `.../graph/ontology` |
| `ontology/ffonto-live-vocab.ttl` | `.../graph/vocab` |

Then:

```bash
wfmas key-status                                     # check the MAP_KEY
wfmas hotspots --brief                               # Sri Lanka (default), last 24 h, stored in the live graph
wfmas hotspots --area world --days 1 --no-persistence --brief
wfmas hotspots --area PRT --days 3 --brief           # any ISO3 country
wfmas fwi --lat 7.29 --lon 80.63                     # FWI + danger class, Kandy
wfmas rules                                          # R09–R12 → inferred-live graph
wfmas ask "Are there any fires near Kandy right now?" --role incident_commander --json trace.json
wfmas ask "What hazards are present and what should we do?" --record https://w3id.org/ffonto/data/image/img_081
wfmas ask "How does FWI relate to fire spread?"
wfmas ask "..." --transport mcp                      # same, but every tool call goes over MCP stdio
wfmas test-cqs                                       # CQ tests (entries with an `expect` block)
wfmas shacl                                          # SHACL check of the live graphs
streamlit run app/streamlit_mas.py                   # minimal UI with map, plan, evidence
```

## Before first real run: align with your FFOnto (checklist)

The new module uses placeholder IRIs and a few placeholder property names. Search for
`ALIGN` in the repo.

1. **Namespaces**: set `ontology.base`, `ontology.vocab`, `ontology.data` and the graph IRIs
   in `config/settings.yaml`. Queries in `cq/` and `rules/` are rewritten at load time.
2. **Overlapping terms** in `ontology/ffonto-live.ttl`: if FFOnto already has a generic
   claim class, `confidence`, `sourceModel`, or hazard→action property, map or remove
   the duplicate here. Then rerun ROBOT, HermiT and OOPS!.
3. **Site location**: `rules/inputs_sites.rq` accepts `ffo:latitude/longitude` or a
   GeoSPARQL WKT point. Make sure your `ffo:Site` instances have one of them.
4. **Record → site/event link**: `cq/live_cqs.yaml` CQL05 uses `ffo:atSite` / `ffo:aboutEvent`.
5. **Image claims for R12**: `rules/inputs_images.rq` uses placeholder names for the CLIP
   fire score, threshold and capture time. Until this is aligned R12 is skipped with a warning.
6. **Your 27 CQs**: add them as `cq/core_cqs.yaml` (format in `cq/README.md`) so the KG
   agent and the planner can use them. Your 59 CQ tests can move to `expect` blocks.
7. **Your RAG index**: set `rag.backend: custom` and point `rag.custom_class` at a class
   with `search(query, k) -> list[dict]` wrapping your bge-m3 index. The JSONL in `data/`
   is a placeholder with four demo chunks.
8. Copy your FFOnto `.ttl` files into `ontology/` too, so the SPARQL guard knows every
   term even if GraphDB is offline (with GraphDB online it reads them from the repository).

## NASA FIRMS: what is and is not a wildfire

FIRMS reports thermal anomalies. `live/classify.py` keeps every detection but labels it,
and only `likely_vegetation_fire` counts as wildfire evidence in rules and answers:

| Check | Category |
|---|---|
| FIRMS `type` column (standard-processing products only): 1 / 2 / 3 | volcanic / static land source / offshore |
| Within 1 km of an entry in `data/static_sources.csv` | static land source or volcanic |
| Outside `land_mask_file` (optional GeoJSON) | offshore |
| Same ~400 m cell detected on ≥ 8 distinct days in 30 | persistent static source (flares, plants) |
| VIIRS confidence `l`, or MODIS confidence < 30 | low confidence |
| none of the above | likely vegetation fire (may still be agricultural burning) |

NRT products have no `type` column, so the persistence check does most of the work. It
costs one extra 30-day request per call (cached 15 minutes; your key allows 5,000
transactions per 10 minutes). Add verified static sources for Sri Lanka to
`data/static_sources.csv` to tighten it further.

The MAP_KEY is read from `.env` and never written to logs, caches, snapshots or the KG.
Set `firms.record_dir` to save every response, and `firms.replay_dir` to replay them, so
evaluation runs are reproducible.

## Where each technique lives

| Technique | Code |
|---|---|
| Planner (intent, urgency, slots, typed plan DAG, template or LLM plans) | `agents/planner.py`, `agents/state.py` |
| Orchestrator (LangGraph; same nodes run without it) | `orchestrator.py` |
| MCP servers / client bus | `mcp_servers/*`, `tools/bus.py` |
| IORS: radius/day ladder for FIRMS, CQ relaxation, CRAG re-query, early stop | `agents/workers.py` |
| CRM: response schema per intent, evidence→section mapping, safety override | `agents/synthesis.py`, `agents/prompts.py` |
| IALT: intent/urgency/role-conditioned prompts | `agents/prompts.py` |
| Verifier (cites exist, every claim cited, every hazard reported; optional LLM check) | `agents/synthesis.py` |
| SPARQL guard (read-only, LIMIT, ontology terms only, no SERVICE) | `kg/guard.py` |
| Rules R09–R12 | `kg/rules_live.py`, `rules/*.rq` |
| FWI (Van Wagner 1987, latitude-adjusted day lengths) | `live/fwi.py` |

## Comparing models

Each LLM job is a slot in `config/models.yaml` (planner, sparql, synthesizer, verifier,
rag_grader, scene_graph, figure_reader). The harness changes the model in one slot and
keeps the others at baseline:

```bash
wfmas-eval --slot planner --pool text --dataset eval/datasets/intent.jsonl --repeats 3
wfmas-eval --slot synthesizer --models qwen2.5:14b,llama3.1:8b,gemma4:12b --dataset eval/datasets/synth.jsonl
wfmas-eval --slot scene_graph --pool vision --dataset eval/datasets/scene.jsonl
wfmas-eval --slot sparql --pool text --dataset eval/datasets/sparql.jsonl     # needs GraphDB
wfmas-eval --slot e2e --models qwen2.5:14b,qwen3:14b --dataset eval/datasets/e2e.jsonl
```

Each run writes `runs/<time>_<slot>/items.jsonl`, `summary.csv` and `summary.md`: mean and
95% bootstrap CI per metric, p50/p95 latency, tokens per item, and exact McNemar tests
against the best model. The datasets in `eval/datasets/` are format examples; replace them
with your labelled sets (see `eval/datasets/README.md`). Check model tags in your Ollama
library before running; DeepSeek-VL2 and InternVL3 run through vLLM.

## Status

Tested offline here (24 tests): FWI against published reference values, FIRMS CSV
parsing for VIIRS/MODIS/SP formats, hotspot classification, RDF lifting, SPARQL guard,
CQ rendering, rules R09–R12, orchestrator end to end with scripted tools and model
(including verifier-driven rewrite, LLM failure fallback, failed-step handling), the MCP
servers over the real protocol (in-process and stdio), and the evaluation harness.

Not yet run against live services: FIRMS, Open-Meteo, GraphDB, Ollama. The sandbox this
was built in could not reach them. Expect small fixes on first contact, most likely in
the alignment points above.
