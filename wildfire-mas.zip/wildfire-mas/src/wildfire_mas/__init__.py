"""Ontology-grounded multi-agent system for wildfire screening."""

__version__ = "0.1.0"
