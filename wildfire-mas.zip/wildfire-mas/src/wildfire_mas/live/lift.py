"""Lift live data (FIRMS hotspots, weather, FWI) into FFOnto RDF.

Layers follow FFOnto:
  DATA   ffo:SatelliteHotspot, ffo:LiveWeatherObservation, ffo:FWIAssessment
  CLAIMS ffo:HotspotDetectionClaim (FIRMS confidence + our classification)
  PROV   prov:Activity per fetch (endpoint stored with the MAP_KEY redacted)
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone

from ..config import Settings
from ..kg.turtle import Lit, TurtleDoc
from .firms import FirmsResult, Hotspot
from .geo import wkt_point
from .weather import FWIReport, WeatherNow

GEO_WKT = "http://www.opengis.net/ont/geosparql#wktLiteral"

CATEGORY_CONCEPT = {
    "likely_vegetation_fire": "ffv:LikelyVegetationFire",
    "low_confidence": "ffv:LowConfidenceDetection",
    "persistent_static_source": "ffv:PersistentStaticHeatSource",
    "static_land_source": "ffv:StaticLandHeatSource",
    "volcanic": "ffv:VolcanicHeatSource",
    "offshore": "ffv:OffshoreHeatSource",
}


def _fl(v):
    """Numeric measurements are typed xsd:decimal consistently (ints from JSON too)."""
    return None if v is None else float(v)


def _h(*parts: object) -> str:
    return hashlib.sha1("|".join(map(str, parts)).encode()).hexdigest()[:16]


class LiveLifter:
    def __init__(self, settings: Settings):
        self.s = settings
        self.data = settings.ns["data"]

    def doc(self) -> TurtleDoc:
        return TurtleDoc({"ffo": self.s.ns["ffo"], "ffv": self.s.ns["ffv"], "data": self.data})

    def _geom(self, d: TurtleDoc, subj: str, lat: float, lon: float) -> None:
        g = subj + "/geom" if subj.startswith("http") else subj + "_geom"
        d.add_iri(subj, "geo:hasGeometry", g)
        d.add_iri(g, "a", "geo:Geometry")
        d.add(g, "geo:asWKT", Lit(wkt_point(lat, lon), GEO_WKT))
        d.add(subj, "ffo:latitude", round(lat, 6))
        d.add(subj, "ffo:longitude", round(lon, 6))

    def fetch_activity(self, d: TurtleDoc, kind: str, endpoint: str, product: str | None = None) -> str:
        now = datetime.now(timezone.utc)
        act = f"{self.data}fetch/{_h(kind, endpoint, now.isoformat())}"
        d.add_iri(act, "a", "prov:Activity")
        d.add(act, "prov:startedAtTime", now)
        d.add(act, "ffo:sourceEndpoint", endpoint)
        d.add(act, "ffo:sourceKind", kind)
        if product:
            d.add(act, "ffo:sourceProduct", product)
        return act

    def hotspots(self, res: FirmsResult, d: TurtleDoc | None = None) -> TurtleDoc:
        d = d or self.doc()
        act = self.fetch_activity(d, "NASA FIRMS", "; ".join(res.urls_redacted), ",".join(res.sources))
        for h in res.hotspots:
            self.hotspot(d, h, act)
        return d

    def hotspot(self, d: TurtleDoc, h: Hotspot, activity: str) -> str:
        s = f"{self.data}hotspot/{h.key}"
        d.add_iri(s, "a", "ffo:SatelliteHotspot")
        d.add(s, "ffo:acquiredAt", h.acq_datetime)
        self._geom(d, s, h.latitude, h.longitude)
        d.add(s, "ffo:fromProduct", h.source)
        d.add(s, "ffo:satellite", h.satellite)
        d.add(s, "ffo:instrument", h.instrument)
        d.add(s, "ffo:frpMW", h.frp)
        d.add(s, "ffo:brightnessK", h.brightness)
        d.add(s, "ffo:brightness2K", h.brightness_2)
        d.add(s, "ffo:dayNight", h.daynight)
        d.add(s, "ffo:firmsConfidence", h.confidence_raw)
        if h.fire_type is not None:
            d.add(s, "ffo:firmsType", h.fire_type)
        d.add_iri(s, "prov:wasGeneratedBy", activity)
        # CLAIMS layer: the detection as a model claim with confidence + our classification
        c = f"{self.data}claim/hotspot/{h.key}"
        d.add_iri(c, "a", "ffo:HotspotDetectionClaim")
        d.add_iri(c, "ffo:aboutRecord", s)
        d.add(c, "ffo:confidence", round(h.confidence_score, 3))
        d.add(c, "ffo:sourceModel", f"FIRMS {h.source}")
        if h.category:
            d.add_iri(c, "ffo:detectionCategory", CATEGORY_CONCEPT[h.category])
            d.add(c, "ffo:isWildfireEvidence", bool(h.wildfire_evidence))
            d.add_all(c, "ffo:classificationReason", h.reasons)
        d.add_iri(c, "prov:wasGeneratedBy", activity)
        return s

    def weather(self, w: WeatherNow, site: str | None = None, d: TurtleDoc | None = None) -> TurtleDoc:
        d = d or self.doc()
        act = self.fetch_activity(d, "Open-Meteo current", "https://api.open-meteo.com/v1/forecast")
        s = f"{self.data}liveweather/{_h(w.lat, w.lon, w.time_local)}"
        d.add_iri(s, "a", "ffo:LiveWeatherObservation")
        d.add(s, "ffo:observedAtLocal", w.time_local)
        d.add(s, "ffo:timezone", w.timezone)
        self._geom(d, s, w.lat, w.lon)
        d.add(s, "ffo:temperatureC", _fl(w.temp_c))
        d.add(s, "ffo:relativeHumidityPct", _fl(w.rh_pct))
        d.add(s, "ffo:windSpeedKmh", _fl(w.wind_kmh))
        d.add(s, "ffo:precipitationMm", _fl(w.precip_mm))
        d.add_iri(s, "ffo:forSite", site)
        d.add_iri(s, "prov:wasGeneratedBy", act)
        return d

    def fwi(self, r: FWIReport, site: str | None = None, d: TurtleDoc | None = None) -> TurtleDoc:
        d = d or self.doc()
        act = self.fetch_activity(d, "FWI computation", r.source)
        prev = None
        for day in r.trend:
            s = f"{self.data}fwi/{_h(r.lat, r.lon, day.date)}"
            d.add_iri(s, "a", "ffo:FWIAssessment")
            d.add(s, "ffo:forDate", Lit(day.date, "http://www.w3.org/2001/XMLSchema#date"))
            self._geom(d, s, r.lat, r.lon)
            for k in ("ffmc", "dmc", "dc", "isi", "bui"):
                d.add(s, f"ffo:{k}", _fl(getattr(day, k)))
            d.add(s, "ffo:fwiValue", _fl(day.fwi))
            d.add(s, "ffo:noonTemperatureC", _fl(day.temp))
            d.add(s, "ffo:noonRelativeHumidityPct", _fl(day.rh))
            d.add(s, "ffo:noonWindSpeedKmh", _fl(day.wind))
            d.add(s, "ffo:rain24hMm", _fl(day.rain))
            d.add_iri(s, "ffo:forSite", site)
            d.add_iri(s, "ffo:previousAssessment", prev)
            d.add_iri(s, "prov:wasGeneratedBy", act)
            prev = s
        d.add_iri(prev, "ffo:dangerClass", f"ffv:{r.danger}")  # latest day
        return d
