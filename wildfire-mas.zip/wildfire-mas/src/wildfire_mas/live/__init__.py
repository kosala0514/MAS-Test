"""Live data: NASA FIRMS hotspots, weather, FWI, and lifting to RDF."""
