"""Tool layer. Agents only call tools by name through a ToolBus; the same tool
implementations are served over MCP (wildfire_mas.mcp_servers) or called in-process."""
