"""Knowledge-graph access: GraphDB client, SPARQL guard, CQ catalog, rules."""
