"""Per-slot model comparison harness (planner, sparql, synthesizer, scene_graph, figure_reader, e2e)."""
