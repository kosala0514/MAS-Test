"""Planner agent: intent + urgency + slots (LLM, few-shot), then a typed, validated plan.

planner_mode=template  deterministic plan templates per intent (default; reproducible)
planner_mode=llm       the LLM writes the plan; it is validated against the Plan schema and
                       replaced by the template plan if invalid (recorded in the trace)
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..kg.cq import CQCatalog
from ..llm import LLMClient
from ..rag import tokenize
from .prompts import PLANNER_LLM_PLAN, PLANNER_SYSTEM
from .state import INTENTS, Plan, PlanStep, Request

_KEYWORDS = [
    ("chitchat", r"^\s*(hi|hello|hey|thanks|thank you|help|who are you)\b"),
    ("hazard_advice", r"\b(hazard|danger(ous)?|what should (we|i|crews?)|safe|ppe|evacuat|risk to|protect)\b"),
    ("trend", r"\b(trend|increas|decreas|chang|over the (last|past)|growing|forecast|next \d+ days)\b"),
    ("situational_awareness", r"\b(fire[s]? (near|around|in)|active fire|hotspot|burning|now|currently|today|latest)\b"),
    ("data_lookup", r"\b(score|threshold|value of|what (is|was) the|how many|list|which records?)\b"),
    ("explanation", r"\b(what is|explain|how does|why|definition|meaning)\b"),
]


def heuristic_intent(q: str) -> str:
    for intent, pat in _KEYWORDS:
        if re.search(pat, q, re.I):
            return intent
    return "explanation"


def _coords(q: str) -> tuple[float, float] | None:
    m = re.search(r"(-?\d{1,2}\.\d+)\s*[,; ]\s*(-?\d{1,3}\.\d+)", q)
    return (float(m.group(1)), float(m.group(2))) if m else None


class Planner:
    def __init__(self, llm: LLMClient, catalog: CQCatalog, settings):
        self.llm = llm
        self.catalog = catalog
        self.s = settings
        self.mode = settings.get("orchestrator.planner_mode", "template")
        self.fewshot = self._load_fewshot(settings.path(settings.get("paths.fewshot_file")))

    @staticmethod
    def _load_fewshot(path: Path | None) -> list[dict]:
        if not path or not path.exists():
            return []
        return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

    def _examples(self, q: str, k: int = 8) -> list[dict]:
        qt = set(tokenize(q))
        scored = sorted(self.fewshot, key=lambda e: -len(qt & set(tokenize(e["question"]))) /
                        (len(qt | set(tokenize(e["question"]))) or 1))
        return scored[:k]

    async def classify(self, req: Request) -> dict:
        examples = self._examples(req.question)
        ex_txt = "\n".join(json.dumps({"q": e["question"], "intent": e["intent"], "cq": e.get("cq")})
                           for e in examples)
        user = (f"Competency questions:\n{self.catalog.menu()}\n\nLabelled examples:\n{ex_txt}\n\n"
                f"Selected record: {req.record or 'none'}\nQuestion: {req.question}")
        try:
            out = await self.llm.chat_json("planner", PLANNER_SYSTEM, user)
            if out.get("intent") not in INTENTS:
                raise ValueError(f"bad intent {out.get('intent')}")
            out["_source"] = "llm"
        except Exception as e:  # noqa: BLE001 - planner must never block the pipeline
            out = {"intent": heuristic_intent(req.question), "urgency": "normal", "topic": req.question,
                   "_source": f"heuristic ({e.__class__.__name__})"}
        c = _coords(req.question)
        if c and out.get("lat") is None:
            out["lat"], out["lon"] = c
        if out.get("cq") and out["cq"] not in self.catalog.by_id:
            out["cq"] = None
        out.setdefault("urgency", "normal")
        out.setdefault("topic", req.question)
        return out

    async def plan(self, req: Request) -> tuple[Plan, dict]:
        cls = await self.classify(req)
        plan = self.template(cls["intent"], cls, req)
        if self.mode == "llm" and cls["intent"] != "chitchat":
            try:
                out = await self.llm.chat_json(
                    "planner", PLANNER_SYSTEM,
                    f"{PLANNER_LLM_PLAN}\nIntent: {cls['intent']}\nCQs:\n{self.catalog.menu()}\n"
                    f"Question: {req.question}")
                plan = Plan(intent=cls["intent"], urgency=cls.get("urgency", "normal"),
                            steps=[PlanStep(**s) for s in out["steps"]], synthesis=out.get("synthesis", ""))
                cls["_plan_source"] = "llm"
            except Exception as e:  # noqa: BLE001
                cls["_plan_source"] = f"template (llm plan rejected: {str(e)[:120]})"
        else:
            cls["_plan_source"] = "template"
        return plan, cls

    # ------------------------------------------------------------------ templates
    def template(self, intent: str, cls: dict, req: Request) -> Plan:
        urg = cls.get("urgency", "normal")
        days = int(cls.get("days") or (5 if intent == "trend" else 2))
        topic = cls.get("topic") or req.question
        has_loc = bool(req.record or req.lat is not None or req.place or cls.get("place")
                       or cls.get("lat") is not None or req.area)
        steps: list[PlanStep] = []

        def add(agent, task, params=None, after=None, optional=False):
            sid = f"s{len(steps) + 1}"
            steps.append(PlanStep(id=sid, agent=agent, task=task, params=params or {},
                                  after=after or [], optional=optional))
            return sid

        if intent == "chitchat":
            return Plan(intent="chitchat", urgency="low", steps=[], synthesis="reply briefly")

        if intent == "explanation":
            add("rag", "find passages, tables and figures", {"query": topic})
            return Plan(intent=intent, urgency=urg, steps=steps,
                        synthesis="explain using documents and ontology facts; cite figures")

        if intent == "data_lookup":
            after = []
            if has_loc:
                after = [add("resolve", "resolve record / place to site and coordinates",
                             {"place": cls.get("place"), "lat": cls.get("lat"), "lon": cls.get("lon")})]
            cq = cls.get("cq")
            add("kg", f"answer with {cq or 'best CQ or guarded SPARQL'}", {"cq": cq, "question": req.question}, after)
            return Plan(intent=intent, urgency=urg, steps=steps, synthesis="the requested value(s) with context")

        # situational_awareness / hazard_advice / trend: live pipeline
        res = add("resolve", "resolve record / place to site and coordinates",
                  {"place": cls.get("place"), "lat": cls.get("lat"), "lon": cls.get("lon")})
        hs = add("live_data", "FIRMS hotspots around the location", {"kind": "hotspots", "days": days}, [res])
        fw = add("live_data", "current weather and FWI at the location", {"kind": "fwi"}, [res], optional=True)
        rk = add("risk", "run rules R09-R12 and collect hazards for the site", {}, [hs, fw])
        add("kg", "live hazards and mitigating actions for the site", {"cq": "CQL02"}, [rk], optional=True)
        if intent == "trend":
            add("kg", "FWI trend at the site", {"cq": "CQL03"}, [rk], optional=True)
            add("kg", "live fire events near the site and growth", {"cq": "CQL04"}, [rk], optional=True)
        if intent == "situational_awareness":
            add("kg", "live fire events near the site", {"cq": "CQL04"}, [rk], optional=True)
        if req.record:
            # existing core CQs about the selected record (e.g. your CQ24/25)
            for cq in self.catalog.for_intent("hazard_advice" if intent == "hazard_advice" else intent):
                if cq.id.startswith("CQL") or set(cq.params) - {"record"}:
                    continue
                add("kg", f"{cq.id} for the selected record", {"cq": cq.id}, [res], optional=True)
        if intent == "hazard_advice":
            add("rag", "guidance documents for the hazards", {"query": topic, "after_hazards": True}, [rk],
                optional=True)
        synth = {"situational_awareness": "situation, danger level, hazards, actions; cite all",
                 "hazard_advice": "hazards with actions first; cite all",
                 "trend": "current value, trend direction and meaning; cite all"}[intent]
        return Plan(intent=intent, urgency=urg, steps=steps, synthesis=synth)
