"""Agents: planner, resolve, live-data, KG, risk, RAG, synthesizer, verifier."""
