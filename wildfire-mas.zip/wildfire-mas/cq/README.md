# CQ catalog

Every `*.yaml` file in this folder is loaded into one catalog. The KG agent fills a CQ's
tested SPARQL template with typed parameters, runs it through the guard, and checks
sufficiency (`required_vars`, `min_rows`). If evidence is insufficient it walks the
`relax` ladder (IORS) before falling back to LLM-written SPARQL.

## Adding your existing 27 CQs

Create `core_cqs.yaml` with one entry per CQ. Example (adapt names to your FFOnto):

```yaml
- id: CQ24
  question: "Which hazards were derived for the event of a selected record?"
  intents: [hazard_advice, situational_awareness]
  params:
    record: {type: iri}
  required_vars: [hazard]
  sparql: |
    PREFIX ffo: <https://w3id.org/ffonto#>
    SELECT ?hazard ?evidence WHERE {
      {{record}} ffo:aboutEvent ?event .
      ?h ffo:affectsEvent ?event ; ffo:hazardType ?hazard .
      OPTIONAL { ?h ffo:supportedBy ?evidence }
    }
```

Parameter types: `iri` (wrapped in `<>`, validated), `float`, `int`, `string`
(escaped literal), `datetime` (typed `xsd:dateTime`). Two derived parameters are
always available: `since` (now minus `days`) and the bbox `lat_min/lat_max/lon_min/lon_max`
(computed from `lat`, `lon`, `radius_km` when those are given).

Namespaces written as `https://w3id.org/ffonto#` / `https://w3id.org/ffonto/vocab#`
are replaced at load time with the IRIs in `config/settings.yaml`.

Keep your CQ tests: `wfmas test-cqs` runs every CQ that has an `expect` block, e.g.

```yaml
  expect: {params: {record: "https://.../img_081"}, min_rows: 1, contains: {hazard: "ExplosionHazard"}}
```
